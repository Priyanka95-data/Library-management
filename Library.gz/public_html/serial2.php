<HTML>
         <HEAD><TITLE>Making entry for Serials.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

         <DIV ALIGN = CENTER> <H1>Enter Into Books Database </H1></DIV>
         <FORM ACTION=serialdisplay5.php METHOD=POST>
         <HR><DIV ALIGN=CENTER>
	 <H3>
         Use "#" sign to separate the names where ever multiple entries are required
         </H3></DIV>
	 <HR>
            
         <BR>
         <b>Bibliographic Level * :</b>
            <SELECT NAME="bibliographic_level_desc1">
             <OPTION>Monograph
             <OPTION>Serial
             <OPTION>Component Part
             <OPTION>Multivolume
             <OPTION>Made-up Collection
            </SELECT><BR>
         <b>Location * :</b>
            <INPUT NAME="location1" TYPE="text" SIZE="15" MAXLENGTH = "15">

          <b>Date Of Entry * :</b> 
          <SELECT NAME="date_of_entry_mm1" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>             
          <SELECT NAME="date_of_entry_dd1" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="date_of_entry_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR>
          <b>Language * :</b> 
             <INPUT NAME="language_code1" TYPE="text" SIZE="50" VALUE="English" >

          <b>Script * :</b>           
            <SELECT NAME="script1">
               <OPTION>Roman
               <OPTION>Cyrillic
               <OPTION>Japanese-script unspecified
               <OPTION>Japanese-kanji 
               <OPTION>Chinese
               <OPTION>Arabic
               <OPTION>Greek
               <OPTION>Hebrew
               <OPTION>Thai
               <OPTION>Devanagari
               <OPTION>Korean
               <OPTION>Tamil
               <OPTION>Other
               </SELECT><BR>

           <b>Translation * :</b> 
             <INPUT NAME="translation_code1" TYPE="text" SIZE="20" VALUE="English"> <BR><BR>

           <b>Physical Medium * :</b>    
              <UL> 
                <LI><INPUT TYPE="checkbox" NAME="paper1" VALUE="paper"> Paper
                <LI><INPUT TYPE="checkbox" NAME="magnetic1" VALUE="magnetic"> Magnetic
                <LI><INPUT TYPE="checkbox" NAME="film1" VALUE="film"> Film
                <LI><INPUT TYPE="checkbox" NAME="laser1" VALUE="laser"> Laser/Optical
                <LI><INPUT TYPE="checkbox" NAME="braille1" VALUE="braille"> Braille
                <LI><INPUT TYPE="checkbox" NAME="other1" VALUE="other"> Other
              </UL>
            <b>ISSN * :</b> 
             <INPUT NAME="issn1" TYPE="text" SIZE="20" > <BR><BR>
            <b> Coden * :</b> 
             <INPUT NAME="coden1" TYPE="text" SIZE="20" > <BR><BR>
            <b>Title * :</b>
                <INPUT NAME="title_sr1" TYPE="text" SIZE="50"><BR>
            <b>Abbreviated Title * :</b>
                <INPUT NAME="abbreviated_title_sr1" TYPE="text" SIZE="50"><BR>
            <b>Language * :</b>
                <INPUT NAME="language_code_title_sr1" TYPE="text" SIZE="30" VALUE="English" ><BR>
            <b> Key Title * :</b>
                <INPUT NAME="key_title1" TYPE="text" SIZE="50"><BR>
            <b>Abbreviated Title * :</b>
                <INPUT NAME="abbreviated_title_kt1" TYPE="text" SIZE="50"><BR>
            <b>Language * :</b>
                <INPUT NAME="language_code_title_kt1" TYPE="text" SIZE="30" VALUE="English" ><BR>
               <b> Edition Statement * :</b>
                <INPUT NAME="edition_statt_sr1" TYPE="text" SIZE="30" > <BR>
               <b>Language  *:</b>
                <INPUT NAME="language_code_edition_statt_sr1" TYPE="text" SIZE="30" VALUE="English" > <BR>
        
            <b>Date Of Publication * :</b>
            <SELECT NAME="date_of_publication_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>             
         <SELECT NAME="date_of_publication_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	  <INPUT NAME="date_of_publication_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR>                  
             <b>Subject Descriptor * :</b>
                  <INPUT NAME="subject_desc1" TYPE="text" SIZE="50"><BR>
             <b>Accession No. * :</b>
                  <INPUT NAME="acc_no1" TYPE="text" SIZE="50"><BR><BR> 
 <BR> <HR><BR>


             <b>   Parallel Title : </b>
               <INPUT NAME="parallel_title1" TYPE="text" SIZE="50" ><BR>
              <b> Language :</b>
                <INPUT NAME="language_code_parallel_title1" TYPE="text" SIZE="30" ><BR>

             <b>  Other Title :</b>
                <INPUT NAME="other_title1" TYPE="text" SIZE="50" ><BR>
              <b> Uniform Title :</b>
                <INPUT NAME="uniform_title1" TYPE="text" SIZE="50" > <BR>
               <b>Language :</b>
                <INPUT NAME="language_code_uniform_title1" TYPE="text" SIZE="30" > <BR>


            <b>   PLACE AND NAME OF PUBLISHER :
                  <BR>
                Name :</b>
                  <INPUT NAME="publisher_name1" TYPE="text" SIZE="50" > <BR> 
                <b>Place :</b>
                  <INPUT NAME="place_of_publisher1" TYPE="text" SIZE="50" > <BR> 
                <b>Address :</b>
                  <INPUT NAME="address_of_publisher1" TYPE="text" SIZE="50" > <BR>  
                <b>Country :</b>
                  <INPUT NAME="country_of_publisher1" TYPE="text" SIZE="50" > <BR> <BR>
               <b> PLACE AND NAME OF DISTRIBUTOR :
                  <BR>
                Name :</b>
                  <INPUT NAME="name_of_distributor1" TYPE="text" SIZE="50" > <BR> 
                <b>Place :</b>
                  <INPUT NAME="place_of_distributor1" TYPE="text" SIZE="50" > <BR> 
                <b>Address :</b>
                  <INPUT NAME="address_of_distributor1" TYPE="text" SIZE="50" > <BR>  
                <b>Country :</b>
                  <INPUT NAME="country_of_distributor1" TYPE="text" SIZE="50" > <BR> <BR>
                <b>INVOICE DETAILS :<BR>
                Name Of Vendor :</b>
                  <INPUT NAME="name_of_vendor1" TYPE="text" SIZE="50"><BR>
                <b> City :</b>
                  <INPUT NAME="city1" TYPE="text" SIZE="50"><BR>
                <b>Invoice No. : </b>
                  <INPUT NAME="invoice_no1" TYPE="text" SIZE="30"><BR>
                <b>Date Of Invoice : </b>
                <SELECT NAME="date_of_invoice_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>             
         <SELECT NAME="date_of_invoice_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	  <INPUT NAME="date_of_invoice_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR>
                <b>Amount Paid : </b>
                  <INPUT NAME="amt_paid1" TYPE="text" SIZE="30"><BR>
                <b>Name Of Grant :</b>
                   <INPUT NAME="name_of_grant1" TYPE="text" SIZE="50"><BR>
                <b>Note <i>(Enter Keywords)</i>: </b>
                  <INPUT NAME="note1" TYPE="text" SIZE="50"><BR>                   
                <b>Note On Bibliographic :</b>
                  <INPUT NAME="bibliographic_note1" TYPE="text" SIZE="50"><BR>

                <b>Frequency :</b>
            <SELECT NAME="frequency">
               <OPTION VALUE="a">Annual
               <OPTION VALUE="bi-m">Every two months
               <OPTION VALUE="bi-w">Biweekly
               <OPTION VALUE="d">Daily
               <OPTION VALUE="fr-n">Fortnightly
               <OPTION VALUE="irr">Irregularly
               <OPTION VALUE="w">Weekly
               <OPTION VALUE="m">Monthly
               <OPTION VALUE="q">Quarterly
               <OPTION VALUE="s-a">Twice annually
               <OPTION VALUE="s-m">Twice monthly
               <OPTION VALUE="s-w">Twice weekly
               <OPTION VALUE="3/m">3 times a month
               <OPTION VALUE="3/yr">3 times a year
               </SELECT><BR>
              <b>Date Of Frequency : </b>
                <SELECT NAME="date_of_fre_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>             
         <SELECT NAME="date_of_fre_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	  <INPUT NAME="date_of_fre_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR>






                <b>CLASSIFICATION SCHEME NOTATION <BR>
                Notation :</b>
                  <INPUT NAME="notation1" TYPE="text" SIZE="30"><BR>
                <b>Edition_no : </b>
                  <INPUT NAME="edition_no1" TYPE="text" SIZE="50"><BR>    
               <b> Identification Of Classification Code ;</b>
                  <INPUT NAME="identification1" TYPE="text" SIZE="50"><BR>
                <b>Classification Scheme Code :</b>
                  <SELECT NAME="c_s_c_desc1">
                   <OPTION>Dewey Decimal            
                   <OPTION>Colon Classification
                   <OPTION>Library Of Congress
                   <OPTION>Universal Decimal
                  </SELECT><BR>
		  <HR><DIV ALIGN=RIGHT>
		      <H4>"*" indiactes compulsory fields</H4>
		  </DIV><HR> 
		  <DIV ALIGN=CENTER>
                    <INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>
                  </FORM> <BR>
		  <FORM ACTION=book4.html> 
		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>
      </BODY>
</HTML> 
                 





