<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

	<HR>
	<BR><BR>
<?php
	include "header.inc";
	include "common.php";
	if(authenticate_user($name,$password,$option){
?>
<h1 ALIGN=CENTER>
	Data Successfully Inserted.	
	</h1>

	<?php

        	$database = pg_connect("dbname=lms user=pro password=pro");

$temp='n';

        	$result = pg_Exec($database,
        	"begin work;"); 

        	$result = pg_Exec($database,
        	"INSERT INTO language_id values (nextval('language_id_seq'),language_code('$language_code'),script('$script'),language_code('$translation_code'))"); 


if($uniform_title != '')
{
              $result = pg_Exec($database,
                 "INSERT INTO uniform_title values('$uniform_title',language_code('$language_code_uniform_title'))");
}
else
{
 $uniform_title='DEFAULT';
}

if($parallel_title != '')
{

              $result = pg_Exec($database,
                 "INSERT INTO map_parallel_title VALUES(nextval('parallel_title_seq'))");  


$t=$parallel_title;

$t2=$language_code_parallel_title;





	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);





              $result = pg_Exec($database,
                 "INSERT INTO parallel_title values(currval('parallel_title_seq'),'$te','null',language_code('$te2'),'za')");

    $result=pg_Exec($database,"SELECT currval('parallel_title_seq') from parallel_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $parallel_title12=pg_Result($result,$i,0);
                
        }

              
 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);



              $result = pg_Exec($database,
                 "INSERT INTO parallel_title values(currval('parallel_title_seq'),'$te','null',language_code('$te2'),'za')");




}  //while
}  //if
else
{
  $parallel_title12=0;
}



if($other_title != '')
{
     $result = pg_Exec($database,
                 "INSERT INTO map_other_title VALUES(nextval('other_title_seq'))");  
       


$t=$other_title;


	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
  
             $result = pg_Exec($database,
                 "insert into other_title values(currval('other_title_seq'),'$te','0','NUL')");

    $result=pg_Exec($database,"SELECT currval('other_title_seq') from other_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $other_title12=pg_Result($result,$i,0);
                
        }
              

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

             $result = pg_Exec($database,
                 "insert into other_title values(currval('other_title_seq'),'$te','0','NUL')");

}  //while
}
else
{
  $other_title12=0;
}


if($notation != '' && $edition_no != '')
{ 
  $result = pg_Exec($database,
                  "insert into classification_scheme_notation values('$notation','$edition_no','$identification','$c_s_c_desc')");
}
else
{
 $notation='DEFAULT';
 $identification='NULL';
}
 

if($name_of_distributor != '')
{
  $result = pg_Exec($database,
           "INSERT INTO map_distribution values( nextval('place_and_distribution_seq'))");

$t=$place_of_distributor;
$t1=$name_of_distributor;
$t2=$address_of_distributor;
$t3=$country_of_distributor;

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


 $result = pg_Exec($database,
                 "insert into place_and_distribution values(currval('place_and_distribution_seq'),'$te','$te1','$te2',country('$te3'))");    

    $result=pg_Exec($database,"SELECT currval('place_and_distribution_seq') from place_and_distribution ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $name_of_distributor12=pg_Result($result,$i,0);
                
        }

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


 $result = pg_Exec($database,
                 "insert into place_and_distribution values( currval('place_and_distribution_seq'),'$te','$te1','$te2',country('$te3'))");    
}
}
else
{
 $name_of_distributor12=0;
}




 $result = pg_Exec($database,
                 "insert into title_sr values('$title_sr','$abbreviated_title_sr',language_code('$language_code_title_sr'))");


$invoice=0;



//    $result=pg_Exec($database,"SELECT invoice_no from invoice_details where invoice_no = $invoice_no  ");
        
//        for($i=0; $i<pg_NumRows($result);$i++) {
  //              $invoice=pg_Result($result,$i,0);

    //    }
if($invoice != 0){

 $result = pg_Exec($database,
                 "insert into invoice_details values('$invoice_no','10/10/1010','0','grant')");
}


if($publisher_name != " ")
{
     $result = pg_Exec($database,
                 "INSERT INTO map_publisher VALUES(nextval('publisher_name_seq'))");  




    $result=pg_Exec($database,"SELECT currval('publisher_name_seq') from map_publisher ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
      
		$publisher_name12=pg_Result($result,$i,0);
        }


$t1=$place_of_publisher;
$t=$publisher_name;
$t2=$address_of_publisher;
$t3=$country_of_publisher;



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);

$result = pg_Exec($database,
                "insert into place_and_publisher values(currval('publisher_name_seq'),'$te','$te1','$te2',country('$te3'))");  


 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


$result = pg_Exec($database,
                "insert into place_and_publisher values(currval('publisher_name_seq'),'$te','$te1','$te2',country('$te3'))");  


}

}
else
{

$publisher_name12=0;
}





if($edition_statt_sr != '')
{
  $result = pg_Exec($database,
   "insert into edition_statt_sr values('$edition_statt_sr',language_code('$language_code_edition_statt_sr'))");
}




          $result = pg_Exec($database,
          "INSERT INTO map_physical_medium VALUES(nextval('physical_medium_seq'))");  



if($paper1 == "paper")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$paper1'))");  
}



if($film1 == "film")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$film1'))");  
}


if($magnetic1 == "magnetic")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$magnetic1'))");  
}


if($laser1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$laser1'))");  
}


if($other1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$other1'))");  
}



if($braille1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$braille1'))");  
}




if($date_of_fre != '10/10/1010')
{
 $result = pg_Exec($database,
             "INSERT INTO serial_frequency values(frequency('$frequency'),'$date_of_fre')");
}
else
{
  $frequency='an';
}
 $result = pg_Exec($database,
            "insert into map_key_title values(nextval('key_title_seq'))");

 $result = pg_Exec($database,
             "INSERT INTO key_title values(currval('key_title_seq'),'$key_title','$abbreviated_title_kt',language_code('$language_code_title_kt'))");


    $result=pg_Exec($database,"SELECT currval('key_title_seq') from key_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
      
		$key_title12=pg_Result($result,$i,0);
        }




 $result = pg_Exec($database,
               "insert into common_to_three values(nextval('record_id_seq'),'$location','$date_of_entry',currval('language_id_seq'),currval('physical_medium_seq'),'$parallel_title12','$other_title12','$publisher_name12','$date_of_publication','$note','$notation','$identification','$subject_desc','$name')");



// $result = pg_Exec($database,
  //             "insert into common_to_three values(nextval('record_id_seq'),'$location','$date_of_entry',currval('language_id_seq'),currval('physical_medium_seq'),'$parallel_title12','$other_title12','$publisher_name12','$date_of_publication','$note','$notation','$identification','$subject_desc','$name')");

 $result = pg_Exec($database,
               "insert into common_to_books_and_serial values(currval('record_id_seq'),bibliographic_level('$bibliographic_level_desc'),'$uniform_title','$name_of_distributor12','$invoice_no','$bibliographic_note')");


 $result = pg_Exec($database,
               "insert into serials values(currval('record_id_seq'),$issn,'$coden','$title_sr','$key_title12','$edition_statt_sr',frequency('$frequency'),'$date_of_fre')");

$t=$acc_no;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into rec_acc values('$te',currval('record_id_seq'))");


}


$t=$reference;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into reference_book values('$te','r')");


}

$t=$study;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into reference_book values('$te','s')");


}





$temp='y';
        	$result = pg_Exec($database,
        	"commit work;"); 



if($temp=='y')
{
echo("<H2>Data has been sucessfully inserted into the database.</H2><BR>"); 
	echo("<FORM ACTION=serial.php>");
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM><HR>");

	echo("<FORM ACTION=serialremarks.php>");
	echo("<INPUT NAME='Remarks' TYPE=submit VALUE='Remarks'><BR>");
	echo("</FORM><HR>");
}
}
else
{
Header("Location:http://$HTTP_HOST/~pro/authfail.html");
}
?>
        </FORM>
        </BODY>
</HTML> 
      







