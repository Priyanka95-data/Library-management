<HTML>
<HEAD><TITLE> Acquisition Clerk's Homepage</TITLE></HEAD>
<BODY BGCOLOR="#999999" TEXT="#000000">
<BR><HR><H1 ALIGN = CENTER>Acquisition Clerk's Homepage</H1><BR><HR>

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

 $clerk_id='foo';
?>
      <TABLE ALIGN=CENTER width='50%'>
    
    <TR><TD>
    <FORM ACTION=order.php METHOD=POST> 
	<b>Place Orders:</b></TD><TD>
	<?php  echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");?>
	<INPUT TYPE=SUBMIT NAME='Order Book' VALUE='Order Book'>
	</FORM>
	</TD></TR><TR><TD>

	<FORM ACTION=book.php METHOD=POST> 
	<b>Add Books:</b></TD><TD>
	<?php echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$name'>"); 
	$clerk_id=$name; ?>
	<INPUT TYPE=SUBMIT NAME='Add Books' VALUE='Add Books'>
	</FORM>
	</TD></TR><TR><TD>

	<FORM ACTION=serial.php METHOD=POST> 
	<b>Add Serials:</b></TD><TD>
	<?php echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$name'>"); 
	$clerk_id=$name; ?>
	<INPUT TYPE=SUBMIT NAME='Add Serials' VALUE='Add Serials'>
	</FORM>
	</TD></TR><TR><TD>

	<FORM ACTION=thesis.php METHOD=POST> 
	<b>Add Theses:</b></TD><TD>
	<?php echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$name'>"); 
	$clerk_id=$name; ?>
	<INPUT TYPE=SUBMIT NAME='Add Theses' VALUE='Add Theses'>
	</FORM>
	</TD></TR><TR><TD>

	<FORM ACTION=updatebooks.php METHOD=POST> 
	<b>Make Changes to Books:</b></TD><TD>
	<?php echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$name'>"); 
	$clerk_id=$name; ?>
	<INPUT TYPE=SUBMIT NAME='Make Changes' VALUE='Make Changes'>
	</FORM>
	</TD></TR><TR><TD>

	<FORM ACTION=remarks.php METHOD=POST> 
	<b>Add Remarks</b></TD><TD>
	<?php  echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>"); ?>
	<INPUT TYPE=SUBMIT NAME='Add Remarks' VALUE='Add Remarks'>
	</FORM>
	</TD></TR><TR><TD>

    <FORM ACTION = getprofile.php METHOD=POST>
    <b>Update Profile</b></TD><TD>
    <?php echo("<INPUT TYPE=hidden NAME=nametochange VALUE='$name'>"); ?>
    <INPUT TYPE=hidden NAME=group VALUE='Acquisition+Clerk'>
    <INPUT TYPE=SUBMIT NAME='Update Profile' VALUE='Update Profile'>
    </FORM></TD></TR>

</TABLE>

	<BR><HR><DIV ALIGN=RIGHT>
	<A HREF=logout.php><b>Logout</b></A>
	</DIV>

<?php


}else{
header("Location:http://$HTTP_HOST/~pro/error3.html");
}
?>
</BODY>
</HTML>
	
