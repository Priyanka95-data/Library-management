<HTML>
<HEAD><TITLE>List Of All Books</TITLE></HEAD>

<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

<?php
include("header.inc");
include("common.php");



    //        $database=pg_connect("dbname=lms user=postgres");      


    $res=query("SELECT rec_acc.acc_no, common_to_books_and_thesis.person1,common_to_books_and_thesis.title_bk,common_to_three.subject_desc,common_to_three.date_of_entry FROM rec_acc, common_to_books_and_thesis, common_to_three WHERE common_to_books_and_thesis.record_id=rec_acc.record_id AND common_to_three.record_id=rec_acc.record_id GROUP BY rec_acc.acc_no, common_to_three.subject_desc, common_to_books_and_thesis.title_bk,common_to_three.date_of_entry, common_to_books_and_thesis.person1"); 


    if(pg_numrows($res) == 0 ) {
        echo("<H1 ALIGN=CENTER>No books found<H1>");
    }else {
$test = 0;

        for($i=0; $i<pg_numrows($res);$i++) 
            {
                $r0=pg_result($res,$i,0); //acc_no
                $r1=pg_result($res,$i,1); //person1
                $r2=pg_result($res,$i,2); //title_bk
                $r3=pg_result($res,$i,3); //notation
                $r4=pg_result($res,$i,4); //notation

                
            
                //get details of author of book using person1
                $res1=query("SELECT primary_element, " .
                               "secondary_element, additional_element " .
                               "FROM name_of_person WHERE person1='$r1' ");
                $r1="";
                
            for($j=0; $j<pg_NumRows($res1);$j++) 
                {
                        $s1=pg_Result($res1,$j,0); //primary_el
                        $s2=pg_Result($res1,$j,1); //sec_el
                        $s3=pg_Result($res1,$j,2); //addtnl_el
                        $r1 = $r1 . $s1 . " " . $s2 . " " . $s3 . "#";
                }




    $res2=pg_Exec("SELECT (CAST('$r4' ".
               "AS DATE) - CAST('$o' AS DATE))");
    
    for($k=0 ; $k<pg_NumRows($res2);$k++)
        {
            $t1= pg_Result($res2,$k,0);
            
        }

    $res3=pg_Exec("SELECT (CAST('$t' ".
               "AS DATE) - CAST('$r4' AS DATE))");
    
    for($k=0 ; $k<pg_NumRows($res3);$k++)
        {
            $t2= pg_Result($res3,$k,0);
            
        }


    

          if($t1 >= 0 && $t2 >= 0)
{

                $res2=query("SELECT mem_still_exist_or_no from reference_book where acc_no = '$r0' ");

                
            for($j=0; $j<pg_NumRows($res2);$j++) 
                {
                        $t1=pg_Result($res2,$j,0);
                }

             if( $t1 == 'r')
{  
                $t1 = 'z';
		$test = $test + 1;
} 
}                            
            }

    }
    

echo("<BR><BR><BR><DIV ALIGN=CENTER><b>Total No. Of Books : $test</b> </DIV>"); 
?>

</BODY>
</HTML>








