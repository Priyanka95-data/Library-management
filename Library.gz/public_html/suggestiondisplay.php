<HTML>
<HEAD><TITLE>Authentication of a member.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
	$database=pg_connect("dbname=lms user=postgres");
	$result=pg_Exec($database,"SELECT mem_id,mem_passwd from member where mem_id='$mem_id' and mem_passwd ='$passwd'");
	for($i=0; $i<pg_NumRows($result);$i++) {
		$result1=pg_Result($result,$i,0);
		$result2=pg_Result($result,$i,1);
	}
if($result1 != '' && $result2 != '')
{
   echo("<FORM ACTION=suggestiondatabase.php>");
    echo("<INPUT TYPE=hidden VALUE='$mem_id ' NAME=mem_id >");
    echo("<INPUT TYPE=hidden VALUE='$passwd ' NAME=passwd >");
   echo("<b> Name of book *</b> :");
    echo("<INPUT TYPE=TEXT  NAME=name ><BR>");
   echo("<b> Author of book *</b> :");
    echo("<INPUT TYPE=TEXT  NAME=author >");
   echo("<b> Publisher of book </b> :");
    echo("<INPUT TYPE=TEXT  NAME=publisher >");
   echo("<HR><BR>");
        echo ("<INPUT NAME=back TYPE=submit VALUE=Enter>");
        echo("</FORM>");
}
else
{
echo("<BR><BR><BR> <DIV ALIGN=CENTER><H2> Wrong Password Or Member Id.</H2> </DIV>" ); 
 echo("<HR><DIV ALIGN=CENTER><A HREF=suggestion.php>GO BACK</A></DIV>");

} 
?>
</BODY>
</HTML>