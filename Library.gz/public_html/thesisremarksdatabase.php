<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
include("header.inc");
include("common.php");
if(authenticate_user($name,$password,$option){
?>

	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
<H2>Data has been sucessfully inserted into the database.</H2>
	</DIV>

	<?php


        	$database = pg_connect("dbname=lms user=pro password=pro");


        	$result = pg_Exec($database,
     "insert into remarks values('$acc_no','$remarks')");


echo("<BR>"); 
	echo("<FORM ACTION=thesis.php>");
?>
	<DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>
<?
	echo("<INPUT NAME='Book' TYPE=submit VALUE='Book'><BR>");

?>	
	</DIV>
<?



	echo("</FORM><BR><BR>");

	echo("<FORM ACTION=thesisremarks.php>");
?>
	<DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>
<?
	echo("<INPUT NAME='Remarks' TYPE=submit VALUE='Remarks'><BR>");


?>	
	</DIV>

<?

	echo("</FORM><HR>");
}
else{
Header("Location:http://$HTTP_HOST/~pro/authfail.html");
}
 ?>

        </BODY>
</HTML> 
