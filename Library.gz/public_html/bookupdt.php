<HTML>
<HEAD><TITLE>This Is The Update Page For Books</TITLE>
<SCRIPT LANGUAGE="JavaScript">
<!-- check for name field
-->
</SCRIPT></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316431">
<hr>
<?php
session_start();
session_register("title_bk");
session_register("record_id");
session_register("language_id");
session_register("physical_medium");
session_register("parallel_title_id");
session_register("other_title_id");
session_register("publisher_name_id");
session_register("notation");
session_register("identification");
session_register("type_of_material");
session_register("title_bk_id");
session_register("person1");
session_register("invoice_no");
session_register("name_of_corporate_body_id");
session_register("preliminary");
session_register("textual");
session_register("uniform_title");
session_register("place_and_distribution");
session_register("isbn_id");
session_register("edition_statt_bk");
session_register("part_statt_id");
session_register("issn");
session_register("part_statt_id_sr_stt");
session_register("preliminary_pt_stt");
session_register("textual_pt_stt");
session_register("preliminary_sr_stt");
session_register("edition_statt");	
session_register("physical_medium_id");
	include "header.inc";
	include "common.php";
	if(authenticate_user($name,$password,$option)){
echo("<H1 ALIGN=CENTER><FONT COLOR=BROWN>This Page Allows To Update Existing Book</FONT></H1>");
$database=pg_pconnect("dbname=lms user=pro password=pro");
$result=pg_Exec($database,"SELECT record_id from rec_acc WHERE ".
"acc_no='$acc_no'");
$acc_no1 =$acc_no;

for($i=0;$i<pg_NumRows($result);$i++)
{
  $record_id=pg_Result($result,$i,0);
}
if(!$record_id){
  echo("<HR><BR>");
  echo("<h1 ALIGN=CENTER>The Book <FONT COLOR=RED>doesn't</FONT> Exist.</h1>");
  echo("<BR><HR><TABLE WIDTH=100% ALIGN=CENTER><TR><TD>");
  echo("<A HREF=acqclerkentry.php>Home Page</A></TD><TD>");
  echo("<A HREF=updatebooks.php><i>Re-Enter</i></A></TD><TD>&nbsp");
  for($i=1;$i<21;$i++){
    echo("&nbsp&nbsp&nbsp&nbsp&nbsp");}
  echo("<A HREF=logout.php>Logout</A></TD></TR></TABLE>");
  exit();
}
$result=pg_Exec($database,"SELECT acc_no from rec_acc WHERE ".
"record_id='$record_id'");
$acc_no='';
for($i=0;$i<pg_NumRows($result);$i++)
{
  $accno=pg_Result($result,$i,0);
  $acc_no[$i] =$accno;
}
$result=pg_Exec($database,"SELECT * from common_to_three WHERE ".
		"record_id='$record_id'");
for($i=0;$i<pg_NumRows($result);$i++)
{	
  $location =pg_Result($result,$i,1);          
  $date_of_entry=pg_Result($result,$i,2);      
  $language_id  =pg_Result($result,$i,3);      
  $physical_medium_id =pg_Result($result,$i,4);   
  $parallel_title_id=pg_Result($result,$i,5);  
  $other_title_id=pg_Result($result,$i,6);      
  $publisher_name_id =pg_Result($result,$i,7); 
  $date_of_publication=pg_Result($result,$i,8);
  $note=pg_Result($result,$i,9);  	           
  $notation =pg_Result($result,$i,10);          
  $identification =pg_Result($result,$i,11);        
  $subject_desc=pg_Result($result,$i,12);       
  $acq_clerk=pg_Result($result,$i,13);       
}
$result=pg_Exec($database,"SELECT * from physical_medium_m WHERE ".
"physical_medium_id='$physical_medium_id'");
for($i=0;$i<pg_NumRows($result);$i++)
{
  $physical_medium1=pg_Result($result,$i,1); 
  $physical_medium[$i] = $physical_medium1;
}	
$result=pg_Exec($database,"SELECT * FROM common_to_books_and_thesis ".
		"WHERE record_id='$record_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 	 	$type_of_material=pg_Result($result,$i,1);          
 		$document_no =pg_Result($result,$i,2);           
 		$title_bk =pg_Result($result,$i,3);                 
 		$title_bk_id=pg_Result($result,$i,4);               
		$person1 =pg_Result($result,$i,5);                
 		$name_of_corporate_body_id =pg_Result($result,$i,6);
 		$preliminary=pg_Result($result,$i,7);               
 		$textual =pg_Result($result,$i,8); 
	}
	$result=pg_Exec($database,"SELECT * FROM name_of_corporate_body ".
	      "WHERE name_of_corporate_body_id='$name_of_corporate_body_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$name_of_corporate_body1=pg_Result($result,$i,1); 
		$name_of_corporate_body[$i] = $name_of_corporate_body1; 
 		$parent_body_name1 =pg_Result($result,$i,2);      
 		$parent_body_name[$i] = $parent_body_name1; 
		$address_of_corporate_body1=pg_Result($result,$i,3); 
		$address_of_corporate_body[$i] = $address_of_corporate_body1;  
		$country_of_corporate_body1=pg_Result($result,$i,4);           
 		$country_of_corporate_body[$i] = $country_of_corporate_body1;  
		$role_of_corporate_body1=pg_Result($result,$i,5);
		$role_of_corporate_body[$i] = $role_of_corporate_body1;  
	}
for($j=0;$j<count($country_of_corporate_body);$j++){
	$result=pg_Exec($database,"SELECT country_desc from country ".
		"WHERE country='$country_of_corporate_body[$j]'");
	for($i=0;$i<pg_numrows($result);$i++){
		$country_of_corporate_body_desc[$j]=pg_result($result,$i,0);
	}
}
	$result=pg_Exec($database,"SELECT * FROM type_of_material ".
		"WHERE type_of_material='$type_of_material'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 	 	$type_of_material_desc=pg_Result($result,$i,1);          
	}
	$result=pg_Exec($database,"SELECT * FROM common_to_books_and_serial ".
		"WHERE record_id='$record_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$bibliographic_level =pg_Result($result,$i,1);   
 		$uniform_title =pg_Result($result,$i,2);         
	 	$place_and_distribution=pg_Result($result,$i,3); 
 		$invoice_no =pg_Result($result,$i,4);            
 		$bibliographic_note=pg_Result($result,$i,5);
	}  
	$result=pg_Exec($database,"SELECT * FROM bibliographic_level ".
		"WHERE  bibliographic_level='$bibliographic_level'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$bibliographic_level_desc=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM books ".
		"WHERE record_id='$record_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$isbn_id =pg_Result($result,$i,1);                        
 		$edition_statt_bk =pg_Result($result,$i,2);               
	 	$no_of_meeting_or_conference_id =pg_Result($result,$i,3); 
 		$price_id =pg_Result($result,$i,4);                       
 		$issn=pg_Result($result,$i,5);                         
 		$part_statt_id =pg_Result($result,$i,6);      
	}
	$result=pg_Exec($database,"SELECT * FROM series_statt ".
		"WHERE issn='$issn'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$series_name=pg_Result($result,$i,1);         
 		$statt_of_resp_sr_stt=pg_Result($result,$i,2);
 		$part_statt_no=pg_Result($result,$i,3);      
 		$part_statt_id_sr_stt=pg_Result($result,$i,4);
	}
	$result=pg_Exec($database,"SELECT * FROM part_statt ".
		"WHERE part_statt_id='$part_statt_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$volume_or_part_no=pg_Result($result,$i,1);     
 		$part_statt=pg_Result($result,$i,2);          
 		$preliminary_pt_stt =pg_Result($result,$i,3);          
 		$textual_pt_stt=pg_Result($result,$i,4);               
	}
	$result=pg_Exec($database,"SELECT * FROM part_statt ".
		"WHERE part_statt_id='$part_statt_id_sr_stt'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$volume_or_part_no_sr_stt=pg_Result($result,$i,1);     
 		$part_statt_sr_stt  =pg_Result($result,$i,2);          
 		$preliminary_sr_stt =pg_Result($result,$i,3);          
 		$textual_sr_stt=pg_Result($result,$i,4);               
	}
	$result=pg_Exec($database,"SELECT * FROM pagination ".
	    "WHERE preliminary='$preliminary_pt_stt' and ".
	    "textual='$textual_pt_stt'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$for_pagination_pt_stt =pg_Result($result,$i,2);
 		$descr_det_pt_stt=pg_Result($result,$i,3);      
 		$dimension_pt_stt =pg_Result($result,$i,4);     
 		$accomp_material_pt_stt=pg_Result($result,$i,5);
	}

	$result=pg_Exec($database,"SELECT * FROM pagination ".
	    "WHERE preliminary='$preliminary_sr_stt' and ".
	    "textual='$textual_sr_stt'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$for_pagination_sr_stt =pg_Result($result,$i,2);
 		$descr_det_sr_stt=pg_Result($result,$i,3);      
 		$dimension_sr_stt =pg_Result($result,$i,4);     
 		$accomp_material_sr_stt=pg_Result($result,$i,5);
	}
	$result=pg_Exec($database,"SELECT * FROM for_pagination ".
		"WHERE for_pagination='$for_pagination_sr_stt'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$pagination_desc_sr_stt=pg_Result($result,$i,1);
	}
	$result=pg_Exec($database,"SELECT * FROM for_pagination ".
		"WHERE for_pagination='$for_pagination_pt_stt'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$pagination_desc_pt_stt=pg_Result($result,$i,1);
	}
	$result=pg_Exec($database,"SELECT * FROM price_and_binding ".
		"WHERE price_id='$price_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$price=pg_Result($result,$i,1);         
 		$date_of_price=pg_Result($result,$i,2); 
 		$binding=pg_Result($result,$i,3);  
	}
	$result=pg_Exec($database,"SELECT * FROM ".
	   "name_of_meeting_or_conference WHERE ".
	   "no_of_meeting_or_conference_id='$no_of_meeting_or_conference_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$entry_element=pg_Result($result,$i,1);             
 		$no_of_meeting=pg_Result($result,$i,2);             
 		$sponsor_name =pg_Result($result,$i,3);             
		$country_of_meeting_or_conference=pg_Result($result,$i,4); 
 		$place_of_meeting_or_conference =pg_Result($result,$i,5); 
 		$date_of_meeting=pg_Result($result,$i,6);           
	}
	$result=pg_Exec($database,"SELECT * FROM country ".
		"WHERE country='$country_desc'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$country_desc_of_meet_or_conf=pg_Result($result,$i,1);    
	}
	$result=pg_Exec($database,"SELECT * FROM edition_statt_bk ".
		"WHERE edition_statt_bk='$edition_statt_bk'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$edition_statt=pg_Result($result,$i,1);    
 		$statt_of_resp_bk=pg_Result($result,$i,2); 
 		$role1_bk_ed  =pg_Result($result,$i,3);  
	}
	$result=pg_Exec($database,"SELECT * FROM edition_statt ".
		"WHERE edition_statt='$edition_statt'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$forms_of_edition_statt_bk=pg_Result($result,$i,1);    
	}
	$result=pg_Exec($database,"SELECT * FROM name_of_person ".
		"WHERE person1='$person1'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$primary_element1=pg_Result($result,$i,1);
//		$primary_element .=$primary_element1;
//		$primary_element .='#';     
 		$secondary_element1=pg_Result($result,$i,2);   
//		$secondary_element .=$secondary_element1;
//		$secondary_element .='#';
 		$additional_element1=pg_Result($result,$i,3);  
//		$additional_element .=$additional_element1;
//		$additional_element .='#';
		$element[$i][0] = $primary_element1;
		$element[$i][1] = $secondary_element1;
		$element[$i][2] = $additional_element1;
 		$date=pg_Result($result,$i,4);                
 		$role22=pg_Result($result,$i,5);   
		$role[$i] = $role22;             
		$role1[$i]=pg_Result($result,$i,6);      	
	}
	$result=pg_Exec($database,"SELECT * FROM title_bk ".
		"WHERE title_bk_id='$title_bk_id' AND ".
		"title_bk='$title_bk'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$statt_of_resp_ti_bk=pg_Result($result,$i,2); 
 		$language_code_bk=pg_Result($result,$i,3);       
 		$script_bk=pg_Result($result,$i,4);      
	}
	$result=pg_Exec($database,"SELECT * FROM language_code ".
		"WHERE language_code ='$language_code_bk '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$language_desc_bk=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM script ".
		"WHERE script ='$script_bk '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$script_desc_bk=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM parallel_title ".
		"WHERE parallel_title_id='$parallel_title_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$parallel_title=pg_Result($result,$i,1); 
 		$statement_of_resp_pt=pg_Result($result,$i,2); 
 		$language_code_pt=pg_Result($result,$i,3);   
 		$script_pt=pg_Result($result,$i,4);     
	}
	$result=pg_Exec($database,"SELECT * FROM language_code ".
		"WHERE language_code ='$language_code_pt '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$language_desc_pt=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM script ".
		"WHERE script ='$script_pt '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$script_desc_pt=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM other_title ".
		"WHERE other_title_id='$other_title_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		 $other_title=pg_Result($result,$i,1);
 		 $type_of_title_ot=pg_Result($result,$i,2);
 		 $language_code_ot=pg_Result($result,$i,3);
	}
	$result=pg_Exec($database,"SELECT t_o_t_desc FROM type_of_title ".
		"WHERE type_of_title='$type_of_title'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		 $t_o_t_desc_ot=pg_Result($result,$i,0);
	}
	$result=pg_Exec($database,"SELECT language_desc FROM language_code ".
		"WHERE language_code='$language_code_ot'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		 $language_desc_ot=pg_Result($result,$i,0);
	}
	$result=pg_Exec($database,"SELECT language_code FROM uniform_title ".
		"WHERE uniform_title='$uniform_title'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		 $language_code_ut=pg_Result($result,$i,0);
	}
	$result=pg_Exec($database,"SELECT language_desc FROM language_code ".
		"WHERE language_code='$language_code_ut'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		 $language_desc_ut=pg_Result($result,$i,0);
	}
//uniform title,parallel_title,other title,name_of_person,rec_acc,title_bk
//common_to_three,common_to_books_and_thesis,common_to_books_and_serial,books
//10 tables

	$result=pg_Exec($database,"SELECT * FROM invoice_details ".
		"WHERE invoice_no='$invoice_no'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$invoice_date=pg_Result($result,$i,1);  
 		$amt_paid =pg_Result($result,$i,2);     
 		$name_of_grant =pg_Result($result,$i,3);
	}
	$result=pg_Exec($database,"SELECT * FROM isbn ".
		"WHERE isbn_id='$isbn_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$isbn=pg_Result($result,$i,1);      
 		$qualifier =pg_Result($result,$i,2);  
	}
	$result=pg_Exec($database,"SELECT * FROM place_and_distribution ".
		"WHERE place_and_distribution_id='$place_and_distribution'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$name_of_distributor1=pg_Result($result,$i,1); 
		$name_of_distributor[$i] =$name_of_distributor1;  
 		$address_of_distributor1=pg_Result($result,$i,2);   
		$address_of_distributor[$i] =$address_of_distributor1;
 		$place_of_distributor1 =pg_Result($result,$i,3);    
		$place_of_distributor[$i] =$place_of_distributor1;
		$country_of_distributor1=pg_Result($result,$i,4); 
		$country_of_distributor[$i] =$country_of_distributor1;  
	}
for($j=0;$j<count($country_of_distributor);$j++){
	$result=pg_Exec($database,"SELECT * FROM country ".
		"WHERE country='$country_of_distributor[$j]'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$country_of_distributor_desc[$j]=pg_Result($result,$i,1); 
	}
}
	$result=pg_Exec($database,"SELECT * FROM place_and_publisher ".
		"WHERE publisher_name_id='$publisher_name_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$publisher_name1=pg_Result($result,$i,1); 
		$publisher_name[$i] =$publisher_name1;
 		$place_of_publisher1=pg_Result($result,$i,2);      
		$place_of_publisher[$i] = $place_of_publisher1;       
 		$address_of_publisher1 =pg_Result($result,$i,3);
		$address_of_publisher[$i] =$address_of_publisher1;
 		$country_of_publisher1 =pg_Result($result,$i,4);  
		$country_of_publisher[$i] =$country_of_publisher1; 
	}
for($j=0;$j<count($country_of_publisher);$j++){
	$result=pg_Exec($database,"SELECT * FROM country ".
		"WHERE country='$country_of_publisher[$j]'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$country_of_publisher_desc[$j]=pg_Result($result,$i,1); 
	}
}
	$result=pg_Exec($database,"SELECT * FROM pagination ".
		"WHERE preliminary='$preliminary' AND ".
		"textual ='$textual'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$for_pagination=pg_Result($result,$i,2); 
 		$descr_det=pg_Result($result,$i,3);      
 		$dimension=pg_Result($result,$i,4);      
 		$accomp_material=pg_Result($result,$i,5);
	}
	$result=pg_Exec($database,"SELECT pagination_desc FROM ".
		"for_pagination WHERE for_pagination='$for_pagination'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$pagination_desc=pg_Result($result,$i,0);   
	}

//16 tables
for($j=0;$j<count($physical_medium);$j++){
	$result=pg_Exec($database,"SELECT physical_medium_desc FROM ".
	     "physical_medium WHERE physical_medium ='$physical_medium[$j]'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$physical_medium_desc[$j]=pg_Result($result,$i,0);   
	}
}
	$result=pg_Exec($database,"SELECT * FROM language_id ".
		"WHERE language_id ='$language_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$language_code_id=pg_Result($result,$i,1);   
 		$script_id=pg_Result($result,$i,2);          
 		$translation_code_id=pg_Result($result,$i,3);   
	}
	$result=pg_Exec($database,"SELECT * FROM language_code ".
		"WHERE language_code ='$language_code_id '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$language_desc_id=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM script ".
		"WHERE script ='$script_id '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$script_desc_id=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM translation_code ".
		"WHERE translation_code ='$translation_code_id '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$language_code_tr=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM language_code ".
		"WHERE language_code ='$language_code_tr '");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$language_desc_tr=pg_Result($result,$i,1);   
	}
	$result=pg_Exec($database,"SELECT * FROM ".
		"classification_scheme_notation ".
		"WHERE notation ='$notation' and identification='$identification'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$edition_no=pg_Result($result,$i,1);               
 		$classification_scheme_code=pg_Result($result,$i,3);  
	}
	$result=pg_Exec($database,"SELECT * FROM classification_scheme_code ".
	    "WHERE classification_scheme_code='$classification_scheme_code'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
 		$c_s_c_desc=pg_Result($result,$i,1);   
	}
	include("book2.php");
}else {
	Header("Location:http://$HTTP_HOST/~pro/authfail.html");
	}
?>
</BODY>
</HTML>
