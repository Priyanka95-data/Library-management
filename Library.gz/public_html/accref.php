<HTML>
         <HEAD><TITLE>Making entry for Books.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

         <DIV ALIGN = CENTER> <H1>List Of Books </H1></DIV>
         <FORM ACTION=accrefbook.php method = post>

    <BR>
    <DIV ALIGN=CENTER>  <b><u>Give The Limits (Acc no.)..</u></b><BR><BR><BR>


   <b> From</b><INPUT NAME="o" TYPE="text" SIZE="10">
                <b>TO </b><INPUT NAME="t" TYPE="text" SIZE="10">

<BR><BR><HR><BR>

  <INPUT NAME="Enter" TYPE="submit" VALUE="Enter">
</DIV>
</body>
</html>