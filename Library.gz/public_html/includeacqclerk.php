<TABLE WIDTH=100% ALIGN=CENTER><TR><TD>
     <DIV ALIGN=LEFT>
        <A HREF=acqclerkentry.php>
        <FONT COLOR=RED><b>Goto Home Page</b></FONT>
     </A></DIV></TD><TD>
     <DIV ALIGN=RIGHT>
        <A HREF=logout.php>
        <FONT COLOR=RED><b>Logout</B></FONT>
</A></DIV></TD></TR></TABLE>

