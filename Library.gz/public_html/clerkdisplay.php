<HTML>
  
<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">


<HR><BR>
	
<DIV ALIGN=CENTER>
	<H1>Please Verify The Information. <H1>
	</DIV><BR><HR>

<?php

$temp=1;
if($email != '')
        {
        $tel=$email;
        
        $t=$tel;
        $w=strlen($tel);
        $l=strcspn($tel,"@");        
        $t=substr($t,-4,1);
        if($w == $l || $t !='.')
        {
        $temp=2;
      echo("<DIV ALIGN=CENTER> <H1> Wrong E-mail. </H1></DIV>");
	echo("\t");
        }
        }
	    if($clerk_id && $surname && $first_name && ($passwd == $verify) && $status && $date_of_registration_dd && $date_of_registration_mm && $date_of_registration_yy && ($temp == 1))
{
        echo("<TABLE ALIGN=CENTER WIDTH='50%'><TR><TD>");
        echo("<FORM ACTION=clerkdatabase.php>");
	echo("Clerk ID : </TD><TD>$clerk_id</TD></TR><TR><TD>");
	echo("Surname : </TD><TD>$surname</TD></TR><TR><TD>");
 	echo("First Name : </TD><TD>$first_name</TD></TR><TR><TD>");
        echo("Designation : </TD><TD>$status</TD></TR><TR><TD>");
 	echo("Temporary Address : </TD><TD>$temporary_address</TD></TR><TR><TD>");
 	echo("Permenant Address : </TD><TD>$permanant_address</TD></TR><TR><TD>"); 
 	echo("Phone No. : </TD><TD>$phone</TD></TR><TR><TD>");
 	echo("E-mail : </TD><TD>$email</TD></TR><TR><TD>");
 	echo("Date of Joining : </TD><TD>$date_of_registration_mm/$date_of_registration_dd/$date_of_registration_yy</TD></TR></TABLE><HR>");
      
        $date_of_registration_mm .= "/";
        $date_of_registration_dd .= "/";
	$date_of_registration .=$date_of_registration_mm;
        $date_of_registration .=$date_of_registration_dd;
        $date_of_registration .=$date_of_registration_yy;
        $surname .="-";
        $surname .=$first_name; 

 echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >");
 	    echo("<INPUT TYPE=hidden VALUE='$surname' NAME=surname >");
 	    echo("<INPUT TYPE=hidden VALUE='$passwd' NAME=passwd >");
 	    echo("<INPUT TYPE=hidden VALUE='$status' NAME=status >");
 	    echo("<INPUT TYPE=hidden VALUE='$temporary_address' NAME=temporary_address >");
 	    echo("<INPUT TYPE=hidden VALUE='$permanant_address' NAME=permanant_address >");
 	    echo("<INPUT TYPE=hidden VALUE='$date_of_registration' NAME=date_of_registration >");
    echo("<INPUT TYPE=hidden VALUE='$phone' NAME=phone >");
    echo("<INPUT TYPE=hidden VALUE='$email' NAME=email >");
	echo("<BR><DIV ALIGN=CENTER>");
        echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
	echo ("<INPUT NAME=back TYPE=submit VALUE=Enter>");
	echo("</FORM><BR><BR>");
	echo("<FORM ACTION=clerk.php>");
        echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>"); ?>
    <INPUT TYPE="hidden" NAME="$fupload_name" VALUE="<? echo $fupload_name ?>">
    <INPUT TYPE="hidden" NAME="$fupload_type" VALUE="<? echo $fupload_type ?>">
<?
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM></DIV>");
	echo("<HR><TABLE ALIGN=CENTER WIDTH=100%><TR><TD>");
	echo("<A HREF=admin.php>Goto Home Page</A></TD><TD>");
	echo("<A HREF=logout.php>Signout</A></TD></TR></TABLE>");
	}
	else
	{
	echo("<DIV ALIGN=CENTER> <H1> Inconvient Data. </H1></DIV>");
	echo("<DIV ALIGN=CENTER>");
	echo("<FORM ACTION=clerk.php>");
        echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM><HR></DIV>");
	}
        if($passwd != $verify)
        {
         echo("<DIV ALIGN=CENTER> <H1> Wrong Password. </H1></DIV>");
	echo("\t");
        }
        

 
        ?>
</BODY>
</HTML> 










