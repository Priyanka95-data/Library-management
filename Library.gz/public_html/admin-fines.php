<HTML>
<HEAD><TITLE>Define fines</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">
<FORM>

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

	echo("<BR><H1 ALIGN = CENTER>Define fines</H1> <BR><HR><BR>");
    echo("<BR><TABLE width='60%' ALIGN=CENTER>");
    echo("<TR><TD>");
    echo("<b>First &nbsp </b>");
	echo("<INPUT TYPE=TEXT NAME=d11 SIZE=6>&nbsp <b>days<b>");
    echo("</TD><TD> ");
	echo("<b>Fine per day &nbsp</b>");
	echo("<INPUT TYPE=TEXT NAME=f11 SIZE=6>");
    echo("</TD></TR><BR><BR>");
    echo("<TR><TD>");
	echo("<b>Next &nbsp </b>");
	echo("<INPUT TYPE=TEXT NAME=d21 SIZE=6>&nbsp <b>days<b>");
    echo("</TD><TD>");
	echo("<b>Fine per day &nbsp</b>");
	echo("<INPUT TYPE=TEXT NAME=f21 SIZE=6>");
    echo("</TD></TR><BR><BR>");
    echo("<TR><TD>");
	echo("<b>&nbsp &nbsp &nbsp &nbsp After that <b>");
    //	echo("<INPUT TYPE=TEXT NAME=d31 SIZE=6>");
    echo("</TD><TD>");
	echo("<b>Fine per day &nbsp</b>");
	echo("<INPUT TYPE=TEXT NAME=f31 SIZE=6>");
    echo("</TD></TR>");
	echo("</TABLE><BR>");
	echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");  
    
?>

<BR><HR><BR>
<DIV ALIGN=CENTER>
<INPUT TYPE="submit" name="Enter" VALUE="Enter">
</DIV>
</FORM><BR>
<?
         echo("<BR><HR>");
         echo("<TABLE ALIGN=CENTER WIDTH='100%'><TR><TD>");
         echo("<A HREF=admin.php>Return to home page</A></TD><TD>");
         echo("<A HREF=logout.php>Logout</A></TD></TR></TABLE>");


     if($Enter){
         $result=query("DELETE FROM admin_fine");
         echo("<H3 ALIGN=CENTER> First $d11 days &nbsp&nbsp ... &nbsp&nbsp fine Rs. $f11 /-</H3><BR>");
         $result=query("INSERT INTO admin_fine VALUES ('$d11','$f11')");
         if($d21 !='' && $f21 !='')
         {
             $result=query("INSERT INTO admin_fine VALUES ('$d21','$f21')");
             echo("<H3 ALIGN=CENTER>&nbsp Next $d21 days &nbsp&nbsp ... &nbsp&nbsp fine Rs. $f21 /-</H3><BR>");
         }
         else{
             $result=query("INSERT INTO admin_fine VALUES ('$d11','$f11')");
         }	
         //    if($d31 !='' && $f31 !='')
         if($f31 !='')
         {
             $d31=1;
             $result=query("INSERT INTO admin_fine VALUES ('$d31','$f31')");
             echo("<H3 ALIGN=CENTER>&nbsp&nbsp&nbsp&nbsp&nbsp After that &nbsp&nbsp&nbsp&nbsp&nbsp ... &nbsp&nbsp fine Rs. $f31 /-</H3><BR>");
         } 
         elseif($d21 !='' && $f21!='' && $f31 =='') {
             $result=query("INSERT INTO admin_fine VALUES ('$d21','$f21')");
         }	
         else{
             $result=query("INSERT INTO admin_fine VALUES ('$d11','$f11')");
         }	

     }
}else{
    echo("<BR><HR>");
    echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
    echo("<FORM ACTION=login.html>"); 
    echo("<DIV ALIGN=RIGHT>");
    echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
    echo("</DIV>");
    echo("</FORM>");
}

?> 
</BODY>
</HTML>






