<HTML>
<HEAD><TITLE>Add new members</TITLE></HEAD>
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" LINK="#8173FF" VLINK="#F428FF" ALINK="#2F9424">

<?php

include("common.php");

if(authenticate_user($name, $password, $option)) {
  echo("<BR><HR>");
  echo("<DIV ALIGN = CENTER> <H1>Add new members to member database </H1></DIV><HR>");

?>
         <FORM ACTION=display1.php METHOD=POST enctype="multipart/form-data">
<?
         echo("<BR>");
         echo("<BR><TABLE ALIGN=CENTER WIDTH='60%'>");    
         echo("<TR><TD><b>Member Id :</b></TD>");
         echo("<TD><INPUT NAME=mem_id TYPE=TEXT></TD></TR>");
         echo("<TR><TD><b>Password :</b></TD>");
         echo("<TD><INPUT NAME=passwd TYPE=password></TD></TR>");
         echo("<TR><TD><b>Verify Password :</b></TD>");
         echo("<TD><INPUT NAME=verify TYPE=password></TD></TR>");

         echo("<TR><TD><b>Surname   :</b></TD>");
         echo("<TD><INPUT NAME=surname TYPE=text></TD></TR>");
         echo("<TR><TD><b>First Name :</b></TD>");
         echo("<TD><INPUT NAME=first_name TYPE=text ></TD></TR>"); 
         echo("<TR><TD>Date Of Birth :</TD>");
         echo("<TD><SELECT NAME=date_of_birth_mm>");
         echo("<OPTION><None><OPTION VALUE='1'>Jan <OPTION VALUE='2'>Feb <OPTION VALUE='3'>Mar <OPTION VALUE='4'>Apr <OPTION VALUE='5'>May <OPTION VALUE='6'>Jun <OPTION VALUE='7'>Jul <OPTION VALUE='8'>Aug <OPTION VALUE='9'>Sep <OPTION VALUE='10'>Oct <OPTION VALUE='11'>Nov <OPTION VALUE='12'>Dec");
         echo("</SELECT> ");            
         echo("<SELECT NAME=date_of_birth_dd>");
         echo("<OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31");
         echo("</SELECT>");
         echo("<INPUT NAME=date_of_birth_yy TYPE=text SIZE=5 MAXLENGTH=4></TD></TR>");
         echo("<TR><TD><b> Status :</b></TD>");
         //get pre-defined status types
         $res = query("SELECT status FROM status");
         echo("<TD><SELECT NAME=status>");
         for($i=0; $i<pg_NumRows($res);$i++) {
             $st=pg_result($res,$i,0);
             echo("<OPTION> $st");
         }
         echo("</SELECT></TD></TR>");
         echo("<TR><TD>Institution :</TD>");
         echo("<TD><INPUT NAME=institution TYPE=text ></TD></TR>");
         echo("<TR><TD>Course :</TD>");
         echo("<TD><INPUT NAME=field TYPE=text ></TD></TR>");
         echo("<TR><TD>Year :</TD>");
         echo("<TD><INPUT NAME=year TYPE=integer ></TD></TR>");
         echo("<TR><TD><b>Temporary Address :</b></TD>");
         echo("<TD><INPUT NAME=temporary_address TYPE=text ></TD></TR>");
         echo("<TR><TD>Permanent Address :</TD>");
         echo("<TD><INPUT NAME=permanent_address TYPE=text ></TD></TR>");       
         echo("<TR><TD>Phone :</TD>");
         echo("<TD><INPUT NAME=phone TYPE=text VALUE=0></TD></TR>");       
         echo("<TR><TD>E-mail :</TD>");
         echo("<TD><INPUT NAME=email TYPE=text ></TD></TR>");              
         echo("<TD><b>Date Of Registration :</b></TD>");
         echo("<TD><SELECT NAME=date_of_registration_mm>");
         echo("<OPTION><None> <OPTION VALUE='1'>Jan <OPTION VALUE='2'>Feb <OPTION VALUE='3'>Mar <OPTION VALUE='4'>Apr <OPTION VALUE='5'>May <OPTION VALUE='6'>Jun <OPTION VALUE='7'>Jul <OPTION VALUE='8'>Aug <OPTION VALUE='9'>Sep <OPTION VALUE='10'>Oct <OPTION VALUE='11'>Nov <OPTION VALUE='12'>Dec");
         echo("</SELECT>");             
         echo("<SELECT NAME=date_of_registration_dd >");
         echo("<OPTION><None> <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31");
         echo("</SELECT>");             
         echo("<SELECT NAME=date_of_registration_yy>");
         echo("<OPTION><None>	 <OPTION>1990 <OPTION>1991 <OPTION>1992 <OPTION>1993 <OPTION>1994 <OPTION>1995 <OPTION>1996 <OPTION>1997 <OPTION>1998 <OPTION>1999 <OPTION>2000 <OPTION>2001 <OPTION>2002<OPTION>2003<OPTION>2004<OPTION>2005<OPTION>2006<OPTION>2007<OPTION>2008<OPTION>2009<OPTION>2010<OPTION>2011<OPTION>2012<OPTION>2013<OPTION>2014<OPTION>2015<OPTION>2016<OPTION>2017<OPTION>2018<OPTION>2091");
         echo("</SELECT></TD></TR>");             
         echo("<INPUT NAME=date_of_renewal_mm TYPE=HIDDEN VALUE = '10' >");
         echo("<INPUT NAME=date_of_renewal_dd TYPE=HIDDEN VALUE = '10' >");
         echo("<INPUT NAME=date_of_renewal_yy TYPE=HIDDEN VALUE = '1010' >");
         echo("<TR><TD><b>Receipt No. :</b></TD>");
         echo("<TD><INPUT NAME=receipt_no TYPE=text ></TD></TR>");

         echo("<INPUT NAME=mem_still_exist_or_no TYPE=HIDDEN VALUE='y'>");
         //         echo("<TR><TD>Upload Image :</TD>"); 
?>
<!--
         <TD><INPUT TYPE="hidden" NAME="$fupload_name" VALUE="<? echo $fupload_name ?>">
         <INPUT TYPE=file NAME="fupload" VALUE=""></TD></TR>
-->
         </TABLE><BR>
<?php 

         echo("<HR> <TABLE ALIGN=RIGHT>");
         echo("<TR><TD> <FONT COLOR=BLACK><b>Bold</b> fields are compulsary</FONT>");
         echo("</TD></TR></TABLE><BR><BR>");

         echo("<HR><DIV ALIGN=CENTER>");
         //         echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); 
         echo("<INPUT NAME=display TYPE=submit VALUE=Display>");
         echo("</DIV>");
         echo("</FORM> <BR>");

         //reset the form
         echo("<FORM ACTION=member.php> ");
         //         echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); 
         echo("<DIV ALIGN=CENTER>");
         echo("<INPUT NAME=reset TYPE=submit VALUE=Reset>");
         echo("</DIV>");
         echo("</FORM><BR>");

         //logout
         echo("<FORM ACTION=logout.php> ");
         //         echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); 
         echo("<HR><DIV ALIGN=RIGHT>");
         echo("<A HREF=logout.php><b>Logout</b></A>");
         echo("</DIV>");

         echo("</FORM>");

 } else {
    //login failed
    header("Location: http://$HTTP_HOST/~pro/authfail.html");
 }
?>
</BODY>
</HTML> 







