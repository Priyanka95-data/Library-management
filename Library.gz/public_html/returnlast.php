<HTML>
<HEAD><TITLE>Book has been returned</TITLE></HEAD>  
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    $res = query("BEGIN WORK"); 
    
    $entit = $entit + 1;
    
    $res = query("SELECT date_of_return,".
                 "status_mem_bk FROM mem_book WHERE acc_no='$acc_no' ".
                 "and (status_mem_bk='i' or status_mem_bk='d')");
    
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            $date_of_return= pg_Result($res,$i,0);
            $status_mem_bk= pg_Result($res,$i,1);
        } 
    
    $res=query("SELECT (CURRENT_DATE)");
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            $returned_date= pg_Result($res,$i,0);
        }
    
    
    $res=query("SELECT (CAST('$returned_date' ".
               "AS DATE) - CAST('$date_of_return' AS DATE))");
    
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            $days= pg_Result($res,$i,0);
            
        }
    
    $fine=0;

    if( $days > 3)
	   	{
            $res=query("SELECT days,fine from admin_fine");
			for($i=0; $i<1;$i++) {
                $res1=pg_Result($res,$i,0);
                $res2=pg_Result($res,$i,1);


            }
            if($days <= $res1)
                {
                    $fine = $fine + $res2 * $days;
                    $days = $days - $res1;
                } 
            else
                {
                    $fine = $fine + $res2 * $res1;
                    $days = $days - $res1;
                }
            if($days > 0)
                {
                    $res=query("SELECT days,fine from admin_fine");
                    for($i=0; $i<2;$i++) {
                        $res1=pg_Result($res,$i,0);
                        $res2=pg_Result($res,$i,1);
                    }
                    if($days <= $res1)
                        {
                            $fine = $fine + $res2 * $days;
                            $days = $days - $res1;
                        } 
                    else
                        {
                            $fine = $fine + $res2 * $res1;
                            $days = $days - $res1;
                        }
                }
            if($days > 0)
                {
                    $res=query("SELECT days,fine from admin_fine");
                    for($i=0; $i<3;$i++) {
                        $res1=pg_Result($res,$i,0);
                        $res2=pg_Result($res,$i,1);
	                }
                    if($days <= $res1)
                        {
                            $fine = $fine + $res2 * $days;
                        } 
                }
            
        }
    $fines=$fines+$fine;     

    if($status_mem_bk == 'i' && $fine <= 0)
        {
            $status_mem_bk = 'I';
        }
    else
        {
            $status_mem_bk = 'D';
        }
    
    $res = query(
                 "UPDATE mem_related_to_entitlement SET ".
                 "entitlement_withheld = '$entit', fines ='$fines' WHERE".
                 " mem_entitl_id='$mem_entit_id'");
    
    $res = query(
                 "UPDATE mem_book set returned_date=CURRENT_DATE,".
                 "clerk='$name',status_mem_bk='$status_mem_bk' ".
                 "WHERE acc_no='$acc_no' and (status_mem_bk='i' or ".
                 "status_mem_bk='d')");
        
    // new
    
    $res = query(" SELECT rec_acc.record_id from rec_acc where rec_acc.acc_no = '$acc_no'");          
    
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            $record= pg_Result($res,$i,0);
        } 
    
    $res10 = query(
                   "SELECT count(reservation_book.record_id),reservation_book.record_id from reservation_book where reservation_book.record_id = '$record' group by reservation_book.record_id "); 
    
    for($i=0 ; $i<pg_NumRows($res10);$i++)
        {
            $count1 = pg_Result($res10,$i,0);
        } 
    
    $res = query("SELECT dynamic_reference from dynamic_reference"); 
    
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            $reference = pg_Result($res,$i,0);
        } 
    $temp = 0;          
    if($count1 > $reference)
        {
            $res = query("INSERT INTO reference_book VALUES ('$acc_no','r')");
            $temp = 1;
        }
    
    
    $res1 = query(
                  "select mem_entitl_id, email, first_name FROM ".
                  "member, reservation_book WHERE ". 
                  "member.mem_id=reservation_book.mem_id AND ".
                  "reservation_book.record_id = '$record' ");
    
    for($i=0 ; $i<pg_NumRows($res1);$i++)
        {
            
            $mem_entitl_id = pg_Result($res1,$i,0);
            $email = pg_Result($res1,$i,1);
            $name = pg_Result($res1,$i,2);
            
            
            $res = query(
                         "SELECT reservation_withheld from mem_related_to_entitlement where mem_entitl_id = '$mem_entitl_id'"); 
            
            for($j=0 ; $j<pg_NumRows($res);$j++)
                {
                    $reservation = pg_Result($res,$j,0);
                } 
            $reservation = $reservation + 1;
            
            
            $res = query(
                         "UPDATE mem_related_to_entitlement SET ".
                         "reservation_withheld = '$reservation' WHERE".
                         " mem_entitl_id='$mem_entitl_id'");
            
            
           
            if($temp == 1)
                {
                    echo("<H2>Book with Accession No. $acc_no has been made a Reference Book</H2>");
                }
            else 
                {
                    echo("<H2>$name <$email> may come and take the book</H2>");
                }
        }
    
    $res = query("DELETE FROM reservation_book WHERE record_id='$record'");
    

           //send email
           $res1=query("SELECT email FROM member WHERE ".
                       "mem_id='$mem_id' ");
           for($i=0;$i<pg_NumRows($res1);$i++){
               $to=pg_Result($res1,$i,0);
           }   

                $success=0;
                if($to)
                    {
                        $res2=query("SELECT email FROM clerk WHERE clerk='admin'");
                        $adminmail=pg_result($res2,0,"email");

                        $subj = LIBRARY . " - Returned book";

                        $header = "From: " . $adminmail;

                        $body = LIBRARY . " \r\n\r\nThis is to inform you that " . 
                             "the following book has been returned by you: \r\n " .
                             "\r\nAccession No.: " . $acc_no;
                        
                        $success = mail($to, $subj, $body, $header);
                    }
                
                if($success) {
                    echo("<H2>Mail successfully sent to $mem_id</H2><BR>");
                } else {
                    echo("<H2>Mail could not be sent to $mem_id</H2><BR>");
                }
  
//email sent

                $res = query("DELETE FROM in_or_out WHERE acc_no='$acc_no'");                
                
                echo("<H2>Book with Accession No. $acc_no returned by $mem_id</H2>");
                $res = query("COMMIT WORK"); 
                
                echo("<FORM ACTION=return.php>"); 
                echo("<INPUT TYPE=SUBMIT VALUE='Go Back' NAME='Go Back'>");
                echo("</FORM>");

}
?>

</BODY>
</HTML>

                     
                     







