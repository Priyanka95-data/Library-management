#!/usr/bin/perl -w  

use Pg;
#use diagnostics;

my ($ll, $tl, $line, $rl, $il, $dl, $do, $ell, $eol, $rest);
my ($sdl, $n, $dir, $data, $del, $entry_tag, $entry_length);


# rl   = record_length
# ll   = leader length (24 for CDS/ISIS)
# il   = field indicator length
# sdl  = subfield delimiter length
# do   = data offset
# ell  = length of "length of entry" field in directory section
# eol  = length of "offset of entry" field in directory section
# rest = rest of record (beginning with directory section)
# tl   = tag length (3 for CDS/ISIS)
# dl   = directory length (= do - ll - 1, (1 adjusts for field separator))
# dir  = directory section
# data = data section
# del  = directory entry length (tl + ell + eol)

my ($reccnt, $totreccnt) = (0) x 2;

$conn = Pg::connectdb("user=pro dbname=lmstemp");
die $conn->errorMessage unless $conn->status eq PGRES_CONNECTION_OK;

NEWRECORD: 
    while(1){ 

	$reccnt++;

	$ll = 24;
	$tl = 3;
#	chomp($line = <>);
	$line = <>;

	print("Parsing: $line \n");

	#no more records
	if ($line =~ /^\#\#\#/) {
	    print "\n\n\nTotal records inserted: $totreccnt\n\n";
	    exit;
	}

	($rl, $il, $sdl, $do, $ell, $eol, $rest) = unpack("a5 x5 a1 a1 a5 x3 a1 a1 x2 a*", $line);
	$n = int($rl/80);
	while ($n--)
	{
	    chomp($line = <>);
	    $rest .= $line;
	}

	$dl = $do - $ll - 1;
	($dir, $data) = unpack("a$dl x1 a*", $rest);
	$del = $tl + $ell + $eol;


#    $conn = Pg::connectdb("dbname=lms");
#    die $conn->errorMessage unless $conn->status eq PGRES_CONNECTION_OK;

	my (
	     $language_code,
	     $script,
	     $translation_code,
	     $uniform_title,
	     $language_code_uniform_title,
	     $parallel_title,
	     $statement_of_resp,
	     $language_code_parallel_title,
	     $script_parallel_title,
	     $other_title,
	     $type_of_title,
	     $language_code_other_title,
	     $name_of_corporate_body,
	     $parent_body_name,
	     $address_of_corporate_body,
	     $country_of_corporate_body,
	     $role_of_corporate_body,
	     $price,
	     $binding,
	     $date_of_price,
	     $vendor_name,
	     $vendor_city,
	     $invoice_no,
	     $invoice_date,
	     $amount_paid,
	     $name_of_grant,
	     $notation,
	     $identification,
	     $classification_scheme_code,
	     $edition_no,
	     $place_of_distributor,
	     $name_of_distributor,
	     $address_of_distributor,
	     $country_of_distributor,
	     $isbn,
	     $qualifier,
	     $forms_of_statt,
	     $statt_of_resp_bk,
	     $role1,
	     $entry_element,
	     $sponsor_name,
	     $country_of_meet,
	     $place_of_meet,
	     $date_of_meeting,
	     $no_of_element,
	     $pre,
	     $textual,
	     $descr_det,
	     $h, $w, $d,
	     $accomp_material,
	     $part_statt_no,
	     $part_statt,
	     $series_name,
	     $statt_of_resp_sr_stt,
	     $volume_or_part_no,
	     $issn,
	     $title_bk,
	     $statt_of_resp_ti_bk,
	     $language_code_title_bk,
	     $script_title_bk,
	     $place_of_publisher,
	     $publisher_name,
	     $address_of_publisher,
	     $country_of_publisher,
	     $primary_element,
	     $secondary_element,
	     $additional_element,
	     $date,
	     $role,
	     $acc_no,
	     $record_id,
	     $location,
	     $date_of_entry,
	     $subject_desc,
	     $document_no,
	     $bibliographic_note,
	     $date_of_publication,
	     $note,
	     $bibliographic_level,
	     $physical_medium,
	     $type_of_material
	     ) = ('') x 83;


	while ($dl)
	{
	    ($entry_tag, $entry_length, $dir) = unpack("a$tl a$ell x$eol a*", $dir);
	    --$entry_length;

	    ($entry, $data) = unpack("x$il a$entry_length x1 a*", $data);
	    $dl -= $del;

	    @repeats = split(/%/, $entry); #to remove repeats

	    foreach $repeat (@repeats) {

		@subfields = split(/\^/,$repeat);

		shift @subfields; #to remove null in subscript [0]  

		foreach $subfield (@subfields) {
		    $_ = $entry_tag . "^" . $subfield;

		    $entry = unpack("x1 a*", $subfield);


# identifying tags 
		  SWITCH: {
#
		      /040\^A/ && do {$language_code = $entry; last SWITCH;};

		      /040\^B/ && do {$script = $entry; last SWITCH;};

		      /040\^C/ && do {$translation_code = $entry; last SWITCH;};
#
		      /240\^A/ && do {$uniform_title = $entry; last SWITCH;};

		      /240\^L/ && do {$language_code_uniform_title = $entry; last SWITCH;};

		      /210\^A/ && do {$parallel_title .= $entry; last SWITCH;};

		      /210\^B/ && do {$statement_of_resp .= $entry; last SWITCH;};

		      /210\^L/ && do {$language_code_parallel_title .= $entry; last SWITCH;};

		      /210\^S/ && do {$script_parallel_title .= $entry; last SWITCH;};

		      /230\^A/ && do {$other_title .= $entry; last SWITCH;};

		      /230\^B/ && do {$type_of_title .= $entry; last SWITCH;};

		      /230\^L/ && do {$language_code_other_title .= $entry; last SWITCH;};

		      /310\^A/ && do {$name_of_corporate_body .= $entry; last SWITCH;};

		      /310\^B/ && do {$parent_body_name .= $entry; last SWITCH;};

		      /310\^D/ && do {$address_of_corporate_body .= $entry; last SWITCH;};

		      /310\^E/ && do {$country_of_corporate_body .= $entry; last SWITCH;};

		      /310\^G/ && do {$role_of_corporate_body .= $entry; last SWITCH;};
#
		      /465\^A/ && do {$price = $entry; last SWITCH;};

		      /465\^B/ && do {$binding = $entry; last SWITCH;};

		      /465\^C/ && do {$date_of_price = $entry; last SWITCH;};
#
		      /466\^A/ && do {$vendor_name = $entry; last SWITCH;};

		      /466\^B/ && do {$vendor_city = $entry; last SWITCH;};

		      /466\^C/ && do {$invoice_no = $entry; last SWITCH;};

		      /466\^D/ && do {$invoice_date = $entry; last SWITCH;};

		      /466\^E/ && do {$amount_paid = $entry; last SWITCH;};

		      /466\^F/ && do {$name_of_grant = $entry; last SWITCH;};
#
		      /610\^A/ && do {$notation = $entry; last SWITCH;};

		      /610\^B/ && do {$identification = $entry; last SWITCH;};

		      /610\^C/ && do {$classification_scheme_code = $entry; last SWITCH;};

		      /610\^D/ && do {$edition_no = $entry; last SWITCH;};

		      /420\^A/ && do {$place_of_distributor .= $entry; last SWITCH;};

		      /420\^B/ && do {$name_of_distributor .= $entry; last SWITCH;};

		      /420\^C/ && do {$address_of_distributor .= $entry; last SWITCH;};

		      /420\^D/ && do {$country_of_distributor .= $entry; last SWITCH;};
#
		      /100\^A/ && do {$isbn = $entry; last SWITCH;};

		      /100\^B/ && do {$qualifier = $entry; last SWITCH;};

		      /100\^A/ && do {$forms_of_statt = $entry; last SWITCH;};

		      /100\^B/ && do {$statt_of_resp_bk = $entry; last SWITCH;};

		      /100\^C/ && do {$role1 = $entry; last SWITCH;};
#
		      /320\^A/ && do {$entry_element .= $entry; last SWITCH;};

		      /320\^B/ && do {$sponsor_name .= $entry; last SWITCH;};

		      /320\^E/ && do {$country_of_meet .= $entry; last SWITCH;};

		      /320\^G/ && do {$place_of_meet .= $entry; last SWITCH;};

		      /320\^I/ && do {$date_of_meeting .= $entry; last SWITCH;};

		      /320\^J/ && do {$no_of_element .= $entry; last SWITCH;};
#
                      ## 460^A[0-9] => textual , 460^A[a-z],[0-9] => pre,textual

		      /460\^A/ && do {  $_= $entry; ($pre,$textual)  =     \
					    /([a-z]*),*([0-9]*)/; last SWITCH;};	      
#
		      /460\^B/ && do {$descr_det = $entry; last SWITCH;};

                      ## /460\^C/  $h,$w,$d <= hxwxd

		      /460\^C/ && do { $_ = $entry; ($h,$w,$d) = /(.*)x(.*)x(.*)/; last SWITCH;};

		      /460\^D/ && do {$accomp_material = $entry; last SWITCH;};
#
		      /490\^A/ && do {$volume_or_part_no = $entry; last SWITCH;};

		      ## /490\^B/ => check

		      /490\^C/ && do {$part_statt = $entry; last SWITCH;};
#
		      /480\^A/ && do {$series_name = $entry; last SWITCH;};

		      /480\^B/ && do {$statt_of_resp_sr_stt = $entry; last SWITCH;};

		      /480\^C/ && do {$part_statt_no = $entry; last SWITCH;};

		      /480\^D/ && do {$issn = $entry; last SWITCH;};
#
		      /200\^A/ && do {$title_bk = $entry; last SWITCH;};

		      /200\^B/ && do {$statt_of_resp_ti_bk = $entry; last SWITCH;};

		      /200\^L/ && do {$language_code_title_bk = $entry; last SWITCH;};

		      /200\^S/ && do {$script_title_bk = $entry; last SWITCH;};
#
		      /400\^A/ && do {$place_of_publisher .= $entry; last SWITCH;};

		      /400\^B/ && do {$publisher_name .= $entry; last SWITCH;};

		      /400\^C/ && do {$address_of_publisher .= $entry; last SWITCH;};

		      /400\^D/ && do {$country_of_publisher .= $entry; last SWITCH;};

		      ## /300\^x/ =>  ^F(role)

		      /300\^A/ && do { $primary_element .= $entry; last SWITCH;};
		      
		      /300\^B/ && do { $secondary_element .= $entry; last SWITCH;};
		      
		      /300\^C/ && do { $additional_element .= $entry; last SWITCH;};
		      
		      /300\^D/ && do { $date .= $entry; last SWITCH;};
		      
		      /300\^F/ && do { $role .= $entry; last SWITCH;};
#
		      /900\^A/ && do {$acc_no .= $entry; last SWITCH;}; #### can appear >1
#
		      /001/ && do {$record_id = $entry; last SWITCH;};
#
		      /020\^A/ && do {$location = $entry; last SWITCH;};
#
		      /022\^A/ && do {$date_of_entry = $entry; last SWITCH;};
#
		      /620\^A/ && do {$subject_desc = $entry; last SWITCH;};
#
		      /120\^A/ && do {$document_no = $entry; last SWITCH;};
#
		      /510\^A/ && do {$bibliographic_note = $entry; last SWITCH;};
#
		      /440\^A/ && do {$date_of_publication = $entry; last SWITCH;};
#
		      /500\^A/ && do {$note = $entry; last SWITCH;};
#
		      /015\^A/ && do {$bibliographic_level = $entry; last SWITCH;};
#
		      /050\^A/ && do {$physical_medium = $entry; last SWITCH;};
#
		      /060\^A/ && do {$type_of_material = $entry; last SWITCH;};	      
		  }

		}		#matches foreach subfield  

#repeatable fields
		$parallel_title .=  "\#";
		$statement_of_resp .= "\#";
		$language_code_parallel_title .= "\#";
		$script_parallel_title .= "\#";

		$other_title .= "\#";
		$type_of_title .= "\#";
		$language_code_other_title .= "\#";

		$name_of_corporate_body .= "\#";
		$parent_body_name .= "\#";
		$address_of_corporate_body .= "\#";
		$country_of_corporate_body .= "\#";
		$role_of_corporate_body .= "\#";

		$place_of_distributor .=  "\#";
		$name_of_distributor .= "\#";
		$address_of_distributor .=  "\#";
		$country_of_distributor .=  "\#";

		$entry_element .= "\#";
		$sponsor_name .=  "\#";
		$country_of_meet .= "\#";
		$place_of_meet .= "\#";
		$date_of_meeting .= "\#";
		$no_of_element .= "\#";

		$place_of_publisher .= "\#";
		$publisher_name .= "\#";
		$address_of_publisher .= "\#";
		$country_of_publisher .= "\#";
		$primary_element .= "\#";
		$secondary_element .= "\#";
		$additional_element .= "\#";
		$date .= "\#";
		$role .= "\#";
		$acc_no .= "\#";		


	    }			#matches foreach repeat	    

	}			# matches while($dl)

	
#skip record if absent acc_no, title_bk or primary_element
	if ($acc_no =~ /^\#+$/) {
	    print "Skipping record: No accession number\n";
	    next NEWRECORD;
	}

	if ($title_bk eq '') {
	    print "Skipping record: No Title\n";
	    next NEWRECORD;
	}

	if ($primary_element =~ /^\#+$/) {
	    print "Skipping record: No Author\n";
	    next NEWRECORD;
	}


	$date_of_price = $date_of_price eq '' ? '10101010' : $date_of_price; 
	$invoice_date = $invoice_date eq '' ? '10101010' : $invoice_date; 

	if ($date =~ /^\#+$/) { #if date and role1 are not present,
	    #defaults are put in locations corres. to present data in primary_element
	    $date = $primary_element;
	    $role1 = $primary_element;
	    $date =~ s/[^\#]+/10101010/g; 
	    $role1 =~ s/[^\#]+/70/g; 
}

#actually, date_of_meeting should be handled like date above, but not
#been done since all other fields of place_and_publisher are not present 
	if ($date_of_meeting =~ /^\#+$/) { $date_of_meeting = '99999999'; }

	$date_of_entry = $date_of_entry eq '' ? '10101010' : $date_of_entry;
	$date_of_publication = $date_of_publication eq '' ? '10101010' : $date_of_publication;  

	if ($date_of_publication =~ /^\d{4}$/ ) {  #if date in form yyyy
	    $date_of_publication  .= '1010';
	}


#####POSTGRES STUFF
#	$result = $conn->exec("begin work;"); 


	$result = $conn->exec("INSERT INTO language_id VALUES( \
                            nextval('language_id_seq'), '$language_code', \
                            '$script', '$translation_code');");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	if($uniform_title ne '') {   
	    $result = $conn->exec("INSERT INTO uniform_title VALUES( \
                               '$uniform_title', '$language_code_uniform_title');");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	}
	else {$uniform_title = 'DEFAULT';}
#
	if($parallel_title ne '') {   
	    
	    $result = $conn->exec("INSERT INTO map_parallel_title VALUES( \
                               nextval('parallel_title_seq'));");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	    my(@t, @t1, @t2, @t3);

	    @t  = split (/\#/, $parallel_title);
	    @t1 = split (/\#/, $statement_of_resp);
	    @t2 = split (/\#/, $language_code_parallel_title);
	    @t3 = split (/\#/, $script_parallel_title);

	    shift @t;
	    shift @t1;
	    shift @t2;
	    shift @t3;

	    for $i (0 .. $#t) {
		
		    $result = $conn->exec("INSERT INTO parallel_title VALUES ( \
                              currval('parallel_title_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]',  '$t3[$i]');")
			unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq '' && $t3[$i] eq '') ;

		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
		}
	}
	else {$parallel_title = 'DEFAULT';}
#
	if($other_title ne '') {   

	    $result = $conn->exec("INSERT INTO map_other_title VALUES( \
                               nextval('other_title_seq'));");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	    my(@t, @t1, @t2);

	    @t  = split (/\#/, $other_title);
	    @t1 = split (/\#/, $type_of_title);
	    @t2 = split (/\#/, $language_code_other_title);

	    for $i (0 .. $#t) {
		

		    $result = $conn->exec("INSERT INTO other_title VALUES ( \
                              currval('other_title_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]');")
		    unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq '' );
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	}
	else {$other_title = 'DEFAULT';}
#
	if($name_of_corporate_body ne  '') {   

	    $result = $conn->exec("INSERT INTO map_corporate_body VALUES( \
                               nextval('name_of_corporate_body_seq'));");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	    my(@t, @t1, @t2);

	    @t  = split (/\#/, $name_of_corporate_body);
	    @t1 = split (/\#/, $parent_body_name);
	    @t2 = split (/\#/, $address_of_corporate_body);
	    @t3 = split (/\#/, $country_of_corporate_body);
	    @t4 = split (/\#/, $role_of_corporate_body);

	    for $i (0 .. $#t) {

		    $result = $conn->exec("INSERT INTO name_of_corporate_body VALUES ( \
                              currval(' name_of_corporate_body_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]',  '$t3[$i]', '$t4[$i]');")
		unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq ''
			&& $t3[$i] eq '' && $t4[$i] eq '');
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
		
	    }
	    
	}
	else {$name_of_corporate_body = 'DEFAULT';}
#
	$result = $conn->exec("INSERT INTO price_and_binding VALUES ( \
                         nextval('price_id_seq'), '$price', CAST($date_of_price AS DATE), \
                         '$binding');");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	if($invoice_no ne ''){
	    if(($vendor_name and $vendor_city) eq 'NULL') {
		$result = $conn->exec("INSERT INTO invoice_details VALUES( \
                                  $invoice_no, 999, $invoice_date, 
                                  '$amt_paid', '$name_of_grant');");
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	    else{

		print "else";
		$result = $conn->exec("INSERT INTO vendor VALUES ( \
                                  nextval('vendor_seq'), '$vendor_name', \
                                  '$vendor_city', '', '', '');");
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

		$result = $conn->exec("INSERT INTO invoice_details VALUES( \
                                   $invoice_no, currval('vendor_seq'), $invoice_date, 
                                   '$amt_paid', '$name_of_grant');");
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	}
#

	if ($notation ne '') {

	    $result = $conn->exec("INSERT INTO classification_scheme_notation VALUES ( \
                         '$notation', '$edition_no', \
                         '$identification', '$classification_scheme_code');");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	}
#	else {
#	    $notation = 'DEFAULT';
#	    $edition_no = 'DEFAULT';
#	}

#
	    if($place_of_distributor ne '') {
		
		$result = $conn->exec("INSERT INTO map_distribution VALUES( \
                               nextval('place_and_distribution_seq'));");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	    my(@t, @t1, @t2);

	    @t  = split (/\#/, $place_of_distributor);
	    @t1 = split (/\#/, $name_of_distributor);
	    @t2 = split (/\#/, $address_of_distributor);
	    @t3 = split (/\#/, $country_of_distributor);
	    
	    for $i (0 .. $#t) {
		
		    $result = $conn->exec("INSERT INTO place_and_distribution VALUES ( \
                              currval('place_and_distribution_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]',  '$t3[$i]');")
		unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq ''
			&& $t3[$i] eq '');
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	    
	}
	else {$place_of_distributor = 'DEFAULT';}
#
	$result = $conn->exec("INSERT INTO isbn VALUES( \
                          nextval('isbn_seq'), '$isbn', '$qualifier');");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	if($entry_element ne '') {
	    
	    $result = $conn->exec("INSERT INTO map_meeting VALUES( \
                               nextval('no_of_meeting_or_conference_seq'))");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	    my(@t, @t1, @t2, @t4, @t5);

	    @t  = split (/\#/, $entry_element);
	    @t1 = split (/\#/, $no_of_element);
	    @t2 = split (/\#/, $sponsor_name);
	    @t3 = split (/\#/, $country_of_meet);
	    @t4 = split (/\#/, $place_of_meet);
	    @t5 = split (/\#/, $date_of_meeting);
	    
	    for $i (0 .. $#t) {
		
		$result = $conn->exec("INSERT INTO name_of_meeting_or_conference VALUES ( \
                              currval(' name_of_meeting_or_conference_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]',  '$t3[$i]',  '$t4[$i]',  '$t5[$i]')")
		    unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq ''
			    && $t3[$i] eq '' && $t4[$i] eq '' && $t5[$i] eq '');
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	}
	else {$entry_element = 'DEFAULT';}
#
	$result = $conn->exec("INSERT INTO title_bk VALUES( \
                         nextval('title_bk_seq'), '$title_bk', '$statt_of_resp_ti_bk', \
                        '$language_code_title_bk', '$script_title_bk')");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	if($publisher_name ne '') {
	    
	    $result = $conn->exec("INSERT INTO map_publisher VALUES( \
                               nextval('publisher_name_seq'))");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	    my(@t, @t1, @t2, @t3) = ('')x4;

	    @t  = split (/\#/, $publisher_name);
	    @t1 = split (/\#/, $place_of_publisher);
	    @t2 = split (/\#/, $address_of_publisher);
	    @t3 = split (/\#/, $country_of_publisher);
	    
	    for $i (0 .. $#t) {
		
		$result = $conn->exec("INSERT INTO place_and_publisher VALUES ( \
                              currval('publisher_name_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]', '$t3[$i]');")
		    unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq ''
			    && $t3[$i] eq '');
		
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	}
	else {$publisher_name = 'DEFAULT';}
#
	$dimension = "{{$h},{$w},{$d}}";

	if(($pre or $textual) ne '') {
	    $result = $conn->exec("INSERT INTO pagination VALUES(  \
                              '$pre', $textual, 0, \
                              '$descr_det', '$dimension', '$accomp_material');"); 
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	}
	else {$pre = 'DEFAULT'; $textual = 0;}
#
	$result = $conn->exec("INSERT INTO part_statt VALUES(  \
                           nextval('part_statt_seq'), '$volume_or_part_no',  \
                           '$part_statt', '$pre', $textual);"); 
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
#if an issn no is provided use it, otherwise no entry in table isbn,
#the default is used, ie. 999 which is entered by init 
	if ($issn ne '')
	{
	    $result = $conn->exec("INSERT INTO series_statt VALUES( \
                          $issn, '$series_name',
                          '$statt_of_resp_sr_stt', '$part_statt_no',
                           currval('part_statt_seq') );");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	}
	else {$issn=0;}
#
	my (@trole1, $trole1);
	@trole1 = split (/\#/, $role1);
	for $i (0 .. $#trole1) {
	    $trole1 = $trole1[$i] =~ /\d+/ ? $trole1[$i] : '';
	}
	$result = $conn->exec("INSERT INTO edition_statt_bk VALUES( \
                          nextval('edition_statt_bk_seq'), \
                          '$forms_of_statt', '$statt_of_resp_bk', '$trole1');");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	if($entry_element ne '') {   

	    $result = $conn->exec("INSERT INTO map VALUES( \
                               nextval('person1_seq'));");
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	    my(@t, @t1, @t2, @t3, @t4, @t5);

	    @t  = split (/\#/, $primary_element);
	    @t1 = split (/\#/, $secondary_element);
	    @t2 = split (/\#/, $additional_element);
	    @t3 = split (/\#/, $date);
	    @t4 = split (/\#/, $role);
	    @t5 = split (/\#/, $role1);

	    for $i (0 .. $#t) {
		
		$result = $conn->exec("INSERT INTO name_of_person VALUES ( \
                              currval('person1_seq'), '$t[$i]', '$t1[$i]', \
                              '$t2[$i]', CAST($t3[$i] AS DATE),
		              '$t4[$i]', '$t5[$i]');")
		unless ($t[$i] eq '' && $t1[$i] eq '' && $t2[$i] eq ''
			&& $t3[$i] eq '' && $t4[$i] eq '' && $t5[$i] eq '');
                              #t5=role1 not checked since it may have default value
		die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	    }
	}
	else {$entry_element = 'DEFAULT';}
#
	if($physical_medium eq '') {$physical_medium = 999;}

	$result = $conn->exec("INSERT INTO map_physical_medium VALUES( \
                               nextval('physical_medium_seq'));");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;

	$result = $conn->exec("INSERT INTO common_to_three VALUES ( nextval('record_id_seq'), '$location',  \
                          CAST($date_of_entry AS DATE), \
                          currval('language_id_seq'), currval('physical_medium_seq'), \
                          currval('parallel_title_seq'), \
                          currval('other_title_seq'), \
                          currval('publisher_name_seq'), \
                          CAST($date_of_publication AS DATE), '$note', '$notation', \
                          '$identification', '$subject_desc')");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	my @t = split (/\#/, $acc_no);
	
	for $i (0 .. $#t) {
	    

	    $result = $conn->exec("INSERT INTO rec_acc VALUES ( \
                          '$t[$i]', currval('record_id_seq'));")
		unless ($t[$i] eq '');	
	    die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
	}
#
	if($type_of_material eq '') {$type_of_material = 999;}

	$result = $conn->exec("INSERT INTO common_to_books_and_thesis VALUES( \
                          currval('record_id_seq'),  $type_of_material, \
                          '$document_no', '$title_bk',currval('title_bk_seq'),
                           currval('person1_seq'), \
                          currval('name_of_corporate_body_seq'), '$pre', '$textual');");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	$result = $conn->exec("INSERT INTO common_to_books_and_serial VALUES( \
                          currval('record_id_seq'), '$bibliographic_level', \
                          '$uniform_title', \
                          currval('place_and_distribution_seq'), '$invoice_no', \
                          '$bibliographic_note');");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
	$result = $conn->exec("INSERT INTO books VALUES( \
                          currval('record_id_seq'), currval('isbn_seq'), \
                          currval('edition_statt_bk_seq'), \
                          currval('no_of_meeting_or_conference_seq'), \
                          currval('price_id_seq'), $issn, currval('part_statt_seq'));");
	die $conn->errorMessage unless $result->resultStatus eq PGRES_COMMAND_OK;
#
#	$result = $conn->exec("commit work;"); 

	print "Successful: Record $reccnt inserted\n";    
	$totreccnt++;
 
    };	# matches while(1){


























