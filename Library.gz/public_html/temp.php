<?php
        $database=pg_connect("dbname=lms user=postgres");  

      $result=pg_Exec($database,"SELECT name_of_corporate_body from name_of_corporate_body");
   echo("<SELECT NAME=name_of_corporate_body2>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
        for($j=($i+1); $j<pg_NumRows($result);$j++) {
                $result2=pg_Result($result,$j,0);
         if($result1 == $result2)
{
               $pp=0;
          break;
}


}

if($pp > 0)
{
echo( "<option> $result1");

}
$pp = 1;
 }

echo("</SELECT>");
?>