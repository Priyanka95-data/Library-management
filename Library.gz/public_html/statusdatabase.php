<HTML>
<HEAD><TITLE>Allocate status</TITLE></HEAD>  
<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password,$option)) {

	echo("<HR><BR><BR>");


    if($entitlement2 == '')
        {
            $entitlement2 = $entitlement;  
        }

    //    $result=$result1=$result2=1;
    
    $result = query("BEGIN WORK"); 

    $result1 = query("INSERT INTO status values ('$status','$deposited_amt','$fees','$entitlement','$entitlement2','$days_per_book','$entitlement3')"); 
    
    $result2 = query("COMMIT WORK"); 


    echo("<H2 ALIGN=CENTER>New status category has been sucessfully added into the database</H2><BR>"); 
	echo("<FORM ACTION=status.php>");
	echo("<DIV ALIGN=CENTER>");
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</DIV></FORM><HR>");
	echo("<TABLE ALIGN=CENTER WIDTH=100%>");
	echo("<TR><TD><A HREF=admin.php>Home Page</A></TD>");
	echo("<TD><A HREF=logout.php>Logout</A></TD></TR></TABLE>");
}
?>

</BODY>
</HTML>








