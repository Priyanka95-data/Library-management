<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
	include("header.inc");
	include("common.php");
	if(authenticate_user($name,$password,$option)){
?>
	<HR>
	<BR><BR>
	<?php

        	$database = pg_connect("dbname=lms user=pro password=pro");
		$temp='n';
        	$result = pg_Exec($database,
        	"begin work;"); 

        	$result = pg_Exec($database,
        	"INSERT INTO language_id values (nextval('language_id_seq'),language_code('$language_code'),script('$script'),language_code('$translation_code'))"); 


if($parallel_title != '')
{

              $result = pg_Exec($database,
                 "INSERT INTO map_parallel_title VALUES(nextval('parallel_title_seq'))");  


$t=$parallel_title;
$t1=$statement_of_resp;
$t2=$language_code_parallel_title;
$t3=$script_parallel_title;


	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);




              $result = pg_Exec($database,
                 "INSERT INTO parallel_title values(currval('parallel_title_seq'),'$te','$te1',language_code('$te2'),script('$te3'))");

    $result=pg_Exec($database,"SELECT currval('parallel_title_seq') from map_parallel_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $parallel_title12=pg_Result($result,$i,0);
                
        }

              
 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);



              $result = pg_Exec($database,
                 "INSERT INTO parallel_title values(currval('parallel_title_seq'),'$te','$te1',language_code('$te2'),script('$te3'))");


}  //while
}  //if
else
{
  $parallel_title12=0;
}



if($other_title != '')
{
     $result = pg_Exec($database,
                 "INSERT INTO map_other_title VALUES(nextval('other_title_seq'))");  
       


$t=$other_title;
$t1=$type_of_title;
$t2=$language_code_other_title;



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);



  
             $result = pg_Exec($database,
                 "insert into other_title values(currval('other_title_seq'),'$te',type_of_title('$te1'),language_code('$te2'))");

    $result=pg_Exec($database,"SELECT currval('other_title_seq') from map_other_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $other_title12=pg_Result($result,$i,0);
                
        }
              

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);


             $result = pg_Exec($database,
                 "insert into other_title values(currval('other_title_seq'),'$te',type_of_title('$te1'),language_code('$te2'))");
}  //while
}
else
{
  $other_title12=0;
}

if($name_of_corporate_body != '')
{

     $result = pg_Exec($database,
                 "INSERT INTO map_corporate_body VALUES(nextval('name_of_corporate_body_seq'))");  



$t=$name_of_corporate_body;
$t1=$parent_body_name;
$t2=$address_of_corporate_body;
$t3=$country_of_corporate_body;
$t4=$role_of_corporate_body;


	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);





  $result = pg_Exec($database,
                  "insert into name_of_corporate_body values(currval('name_of_corporate_body_seq'),'$te','$te1','$te2',country('$te3'),'$te4')");
              

    $result=pg_Exec($database,"SELECT currval('name_of_corporate_body_seq') from map_corporate_body ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $name_of_corporate_body12 = pg_Result($result,$i,0);
                
        }

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);



	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);



  $result = pg_Exec($database,
                  "insert into name_of_corporate_body values(currval('name_of_corporate_body_seq'),'$te','$te1','$te2',country('$te3'),'$te4')");
}
}
else
{
 $name_of_corporate_body12 = 0;
}

   



if($priliminary != '' && $textual != 0)
{
  $result = pg_Exec($database,
                  "insert into pagination values('$priliminary','$textual',for_pagination('$pagination_desc'),'$illustration','{{$l},{$b},{$h}}','$accomp_material')");

}


if($notation != '' && $edition_no != '')
{ 
  $result = pg_Exec($database,
                  "insert into classification_scheme_notation values('$notation','$edition_no','$identification','$c_s_c_desc')");
}
else
{
 $notation='DEFAULT';
 $identification='NULL';
}

 $result = pg_Exec($database,
                 "insert into title_bk values(nextval('title_bk_seq'),'$title_bk','$statt_of_resp_ti_bk',language_code('$language_code_title_bk'),script('$script_title_bk'))");




if($degree != " " || $research !=" ")
{
     $result = pg_Exec($database,
                 "INSERT INTO map_reserved_field VALUES(nextval('thesis_seq'))");  

  $result1=pg_Exec($database,"SELECT currval('thesis_seq') from  map_reserved_field ");
        
        for($j=0; $j<pg_NumRows($result1);$j++) {
      
		$thesis12=pg_Result($result1,$j,0);
        }


$t1=$research;
$t=$degree;
$t2=$funds;
$t3=$team;



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);

$result = pg_Exec($database,
                "insert into reserved_field values(currval('thesis_seq'),'$te','$te1','$te2','$te3')");  

  

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);

$result = pg_Exec($database,
                "insert into reserved_field values(currval('thesis_seq'),'$te','$te1','$te2','$te3')");  

}

}
else
{
$thesis12=0;
}


if($publisher_name != " ")
{
     $result = pg_Exec($database,
                 "INSERT INTO map_publisher VALUES(nextval('publisher_name_seq'))");  

  $result1=pg_Exec($database,"SELECT currval('publisher_name_seq') from map_publisher ");
        
        for($j=0; $j<pg_NumRows($result1);$j++) {
      
		$publisher_name12=pg_Result($result1,$j,0);
        }


$t1=$place_of_publisher;
$t=$publisher_name;
$t2=$address_of_publisher;
$t3=$country_of_publisher;



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);

$result = pg_Exec($database,
                "insert into place_and_publisher values(currval('publisher_name_seq'),'$te','$te1','$te2',country('$te3'))");  

  

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


$result = pg_Exec($database,
                "insert into place_and_publisher values(currval('publisher_name_seq'),'$te','$te1','$te2',country('$te3'))");  


}

}
else
{
$publisher_name12=0;
}



if($abstract != " ")
{
     $result = pg_Exec($database,
                 "INSERT INTO map_abstract VALUES(nextval('abstract_seq'))");  

  $result1=pg_Exec($database,"SELECT currval('abstract_seq') from map_abstract ");
        
        for($j=0; $j<pg_NumRows($result1);$j++) {
      
		$abstract12=pg_Result($result1,$j,0);
        }


$t1=$abstract;
$t=$language_of_abstract;




	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);


$result = pg_Exec($database,
                "insert into abstract values(currval('abstract_seq'),'$te1',language_code('$te1'))");  

  

 while(strlen($t) >= 1	)
{


	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);


$result = pg_Exec($database,
                "insert into abstract values(currval('abstract_seq'),'$te1',language_code('$te1'))");  

}

}
else
{
$absract12=0;
}


$t=$entry_element;
$t1=$secondary_element;
$t2=$additional_element;
$t3=$role_type;
$t4=$role;

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);


 $result = pg_Exec($database,
               "INSERT INTO map VALUES( nextval('person1_seq'))"); 


 $result = pg_Exec($database,
                "insert into name_of_person values(currval('person1_seq'),'$te','$te1','$te2','$date','$te4',role('$te3'))");
              
 while(strlen($t) >= 1	)
{


	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);








 $result = pg_Exec($database,
                "insert into name_of_person values(currval('person1_seq'),'$te','$te1','$te2','$date','$te4',role('$te3'))");

}


$t=$award;


	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);


 $result = pg_Exec($database,
               "INSERT INTO map_date_related_to_thesis VALUES( nextval('date_seq'))"); 


 $result = pg_Exec($database,
                "insert into date_related_to_thesis values(currval('date_seq'),'$te','$date_of_price','$date_of_invoice')");
              
 while(strlen($t) >= 1	)
{


	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);


 $result = pg_Exec($database,
                "insert into date_related_to_thesis values(currval('date_seq'),'$te','$date_of_price','$date_of_invoice')");
              


}







          $result = pg_Exec($database,
          "INSERT INTO map_physical_medium VALUES(nextval('physical_medium_seq'))");  




if($paper1 == "paper")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$paper1'))");  
}



if($film1 == "film")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$film1'))");  
}


if($magnetic1 == "magnetic")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$magnetic1'))");  
}


if($laser1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$laser1'))");  
}


if($other1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$other1'))");  
}



if($braille1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$braille1'))");  
}

 $result = pg_Exec($database,
               "insert into common_to_three values(nextval('record_id_seq'),'$location','$date_of_entry',currval('language_id_seq'),currval('physical_medium_seq'),'$parallel_title12','$other_title12','$publisher_name12','$date_of_publication','$note','$notation','$identification','$subject_desc','$name')");

  $result = pg_Exec($database,
               "insert into common_to_books_and_thesis values (currval('record_id_seq'),type_of_material('$type_of_material_desc'),'$document_no','$title_bk',currval('title_bk_seq'),currval('person1_seq'),'$name_of_corporate_body12','$priliminary','$textual')");


  $result = pg_Exec($database,
               "insert into thesis values (currval('record_id_seq'),currval('date_seq'),currval('abstract_seq'),currval('thesis_seq'))");


$t=$acc_no;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into rec_acc values('$te',currval('record_id_seq'))");


}


$t=$reference;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into reference_book values('$te','r')");


}

$t=$study;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into reference_book values('$te','s')");


}

$temp='y';
        	$result = pg_Exec($database,
        	"commit work;"); 



if($temp=='y')
{
echo("<BR><H2 ALIGN=CENTER>Data has been sucessfully inserted into the database.</H2><BR><HR>"); 
	echo("<DIV ALIGN=CENTER>");
	echo("<FORM ACTION=thesis.php>");
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM><BR>");

	echo("<FORM ACTION=thesisremarks.php>");
	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); 
	echo("<INPUT NAME='Remarks' TYPE=submit VALUE='Remarks'><BR>");
	echo("</FORM><HR></DIV>");
?>
<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
	<DIV ALIGN=left><FONT COLOR=RED><b>
	<A HREF=acqclerkentry.php>Goto Home Page</A></b></FONT>
	</DIV>	</TD><TD><DIV ALIGN=RIGHT><FONT COLOR=RED><B>
	<A HREF=logout.php>Logout</A></b></FONT>
	</DIV></TD></TR></TABLE>
<?
}
}
else{
Header("Location:http://$HTTP_HOST/~pro/authfail.html");
}
?>
        </FORM>
        </BODY>
</HTML> 
      










