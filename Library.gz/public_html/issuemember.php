<HTML>
<HEAD><TITLE>List Of Members Who Issued Books Today</TITLE></HEAD>

<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

       $res=query(
" SELECT common_to_books_and_thesis.person1,mem_book.mem_id,mem_book.acc_no,common_to_books_and_thesis.title_bk,mem_related_to_entitlement.fines from mem_book,rec_acc,member,mem_related_to_entitlement,name_of_person,common_to_books_and_thesis WHERE mem_book.mem_id=member.mem_id AND member.mem_entitl_id=mem_related_to_entitlement.mem_entitl_id AND mem_book.acc_no=rec_acc.acc_no AND common_to_books_and_thesis.record_id=rec_acc.record_id AND mem_book.date_of_issue=CURRENT_DATE GROUP BY mem_book.mem_id,mem_book.acc_no,common_to_books_and_thesis.title_bk,mem_related_to_entitlement.fines,common_to_books_and_thesis.person1 "); 

    if(pg_numrows($res) == 0 ) {
        echo("<BR><H1 ALIGN=CENTER>No books issued today<H1>");
    }else {
        echo("<BR><H1 ALIGN=CENTER>Books issued today<H1><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Member_id</TH>");
        echo("<TH>Fine</TH>");
        echo("<TH>Accession No.</TH>");
        echo("<TH>Title</TH>");
        echo("<TH>Author</TH>");
        echo("</TR>");        

        for($i=0; $i<pg_NumRows($res);$i++) 
            {
                $r0=pg_Result($res,$i,0);
              
                $r2=pg_Result($res,$i,1);
                $r3=pg_Result($res,$i,2);
                $r4=pg_Result($res,$i,3);
                $r5=pg_Result($res,$i,4);


                $res1=query("SELECT primary_element,secondary_element,additional_element from name_of_person where person1='$r0' ");

                $r1=" ";

                for($j=0; $j<pg_NumRows($res1);$j++) 
                    {
                        $s1=pg_Result($res1,$j,0);
                        $s2=pg_Result($res1,$j,1);
                        $s3=pg_Result($res1,$j,2);
                        $r1 .=$s1;
                        $r1 .=" "; 
                        $r1 .=$s2;
                        $r1 .=".";
                        $r1 .=$s3;
                        $r1 .="#";                
                    }
 
        echo("<TR><TD ALIGN = CENTER> $r2 </TD>");
        echo("<TD ALIGN = CENTER> $r5 </TD>");
        echo("<TD ALIGN = CENTER> $r3 </TD>");
        echo("<TD ALIGN = CENTER> $r4 </TD>");
        echo("<TD ALIGN = CENTER> $r1 </TD></TR>");
        
            }
 echo("</TABLE>");
    }
    
} 

?>
</BODY>
</HTML>






