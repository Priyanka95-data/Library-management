<HTML>
<HEAD><TITLE>Suggest books</TITLE>
<BODY bgcolor="#8AFF90" text="#316431">


<?php
include("header.inc");
include("common.php");

if(authenticate_user($membername, $password, $option)) {

?>
 
 <DIV ALIGN=CENTER>
      <P><H1>Suggest books </H1></P>
 </DIV>
      
        <BR><BR><BR><HR><BR><BR><BR>       
                                         
<?php
 echo("<FORM ACTION=suggestiondatabase.php>");
 echo("<TABLE>");
 echo("<TR><TD><b> Name of book </b> :</TD>");
 echo("<TD><INPUT TYPE=TEXT  NAME=name SIZE=30></TD></TR><BR>");
 echo("<TR><TD><b> Author of book </b> :</TD>");
 echo("<TD><INPUT TYPE=TEXT  NAME=author SIZE=30 ></TD></TR>");
 echo("<TR><TD><b> Publisher of book </b> :</TD>");
 echo("<TD><INPUT TYPE=TEXT  NAME=publisher SIZE=30></TD></TR>");
 echo("<BR></TABLE>");
 echo ("<BR><BR><HR><BR><BR><INPUT NAME=back TYPE=submit VALUE=Enter>");
 echo("</FORM>");

?>

<?php
	echo("<BR><BR><HR><DIV ALIGN=RIGHT>");
	echo("<A HREF=logoutmember.php><b>Logout</b></A>");
	echo("</DIV>");

       } else{
        echo("<BR><HR>");
        echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
        echo("<FORM ACTION=login.html>"); 
              echo("<DIV ALIGN=RIGHT>");
              echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
              echo("</DIV>");
        echo("</FORM>");
        }

?>


</BODY>
</HTML> 







