<?php

  $res=query("SELECT mem_still_exist_or_no FROM member ".
                "WHERE mem_id='$mem_id'");     

   for($i=0 ; $i<pg_NumRows($res);$i++)
  {
		 $still = pg_Result($res,$i,0); 
  }

   if($still != 'y')
{
?>
<HR><H1>
 <H1 ALIGN=CENTER><FONT COLOR=BLUE><U>Member Status</U></FONT></H1>
<?php 
    echo("<HR><BR><H2 ALIGN=CENTER>Member $mem_id does not exist</H2>");
	exit();
}
?>
<BR><HR>
<TABLE WIDTH=100% ALIGN=CENTER><TR><TD>
<DIV ALIGN=LEFT><A HREF=clerkentry.php>Home Page</A></DIV>
</TD><TD>
<DIV ALIGN=LEFT><A HREF=logout.php>Logout</A></DIV>
</TD></TR></TABLE>
