<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">


	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
<H2>Remarks have been added to book</H2>
	</DIV>

	<?php


        	$database = pg_connect("dbname=lms user=pro password=pro");


        	$result = pg_Exec($database,
     "insert into remarks values('$acc_no','$remarks')");


echo("<BR><BR><HR><BR><BR>"); 

echo("<FORM ACTION=remarks.php>");
?>
	<DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>

<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'>
	</DIV>

</FORM>
<TABLE WIDTH=100% ALIGN=CENTER><TR><TD>
<A HREF=acqclerkentry.php>Home Page</A></TD><TD>
<DIV ALIGN=RIGHT>
<A HREF=logout.php>Logout</A>
</DIV></TD></TR></TABLE>

</BODY>
</HTML> 
