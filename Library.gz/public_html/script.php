<HTML>
<BODY>
<?php
    $result=query("insert into script values('ba','Roman')");   
   $result1=query("insert into script values('ca','Cyrillic')");
    $result=query("insert into script values('da','Japanese-script unspecified')");   
    $result=query("insert into script values('NU','null')"); 
  $result=query("insert into country values('NU','null')"); 
      $result=query("insert into language_code values('NUL','null')"); 
      $result=query("insert into language_code values('eng','English')"); 
      $result=query("insert into translation_code values('NUL','NUL')"); 
      $result=query("insert into translation_code values('eng','eng')"); 
 $result=query("insert into script values('db','Japanese-Kanji')");   
 $result=query("insert into script values('dc','Japanese-kana')");
 $result=query(
 "insert into script values('ea','Chinese')");
 $result=query(
 "insert into script values('fa','Arabic')");
 $result=query(
 "insert into script values('ga','greek')");
 $result=query(
 "insert into script values('ha','Hebrew')");
 $result=query(
 "insert into script values('ia','Thai')");
    $result=query(
 "insert into script values('ja','Devanagari')");
    $result=query(
 "insert into script values('ka','Korean')");
    $result=query(
 "insert into script values('la','Tamil')");
    $result=query(
 "insert into script values('za','Other')");
    $result=query(
 "insert into bibliographic_level values('m','Monograph')");
   $result1=query(
 "insert into bibliographic_level values('s','Serial')");
   $result=query(
 "insert into bibliographic_level values('a','Component part')");
   $result=query(
 "insert into bibliographic_level values('c','Multivolume')");
  $result=query(
 "insert into bibliographic_level values('e','Made-up Collection')");
   $result=query(
 "insert into physical_medium values('010','paper')");
   $result=query(
 "insert into physical_medium values('020','film')");
   $result=query(
 "insert into physical_medium values('030','braille')");
   $result=query(
 "insert into physical_medium values('050','laser/optical')");
   $result=query(
 "insert into physical_medium values('040','magnetic')");
   $result=query(
 "insert into physical_medium values('900','other')");
   $result=query(
 "insert into type_of_material values('100','textual')");
   $result=query(
 "insert into type_of_material values('105','report/tectnical report')");
   $result=query(
 "insert into type_of_material values('110','thesis/dissertation')");
   $result=query(
 "insert into type_of_material values('115','meeting document')");
   $result=query(
 "insert into type_of_material values('120','periodical')");
   $result=query(
 "insert into type_of_material values('125','newspaper')");
   $result=query(
 "insert into type_of_material values('130','annual')");
   $result=query(
 "insert into type_of_material values('135','patent document')");
   $result=query(
 "insert into type_of_material values('140','standard')");
   $result=query(
 "insert into type_of_material values('145','irregual serial')");
   $result=query(
 "insert into type_of_material values('150','monographic series')");
   $result=query(
 "insert into type_of_material values('199','other textual materials')");
   $result=query(
 "insert into type_of_material values('900','non-textual materials')");
   $result=query(
 "insert into type_of_title values('0','Other Title/Unknown Title')");
   $result=query(
 "insert into type_of_title values('1','Sub Title')");
   $result=query(
 "insert into type_of_title values('2','Spine Title')");
   $result=query(
 "insert into type_of_title values('3','Cover Title')");
   $result=query(
 "insert into type_of_title values('4','Added Title')");
   $result=query(
 "insert into type_of_title values('5','Running Title')");
   $result=query(
 "insert into edition_statt values('2nd ed','Second Edition')");
  $result=query(
 "insert into edition_statt values('DEFAULT','NULL')");
   $result=query(
 "insert into edition_statt values('rev.ed','Revised Edition')");
   $result=query(
 "insert into edition_statt values('New ed.,rev.and enl','Revised And Enlarged Edition')");
   $result=query(
 "insert into edition_statt values('1st illustrated ed','First illustrated Edition')");
   $result=query(
 "insert into edition_statt values('1st Indian ed','First Indian Edition')");
   $result=query(
 "insert into edition_statt values('Draft ed','Draft Edition')");
   $result=query(
 "insert into edition_statt values('Fascim. ed','Fascimile Edition')");
   $result=query(
 "insert into for_pagination values('0','Books')");
   $result=query(
 "insert into for_pagination values('1','Maps')");
   $result=query(
 "insert into for_pagination values('2','Globes')");
   $result=query(
 "insert into for_pagination values('3','Audio Cassettes')");
   $result=query(
 "insert into for_pagination values('4','Film Reels')");
   $result=query(
 "insert into for_pagination values('5','Video Cassettes')");
   $result=query(
 "insert into for_pagination values('6','Magnetic Tapes')");
   $result=query(
 "insert into for_pagination values('7','Magnetic Disks')");
   $result=query(
 "insert into for_pagination values('8','Charts')");
   $result=query(
 "insert into for_pagination values('9','Posters')");
   $result=query(
 "insert into for_pagination values('10','Slides')");
   $result=query(
 "insert into for_pagination values('11','Photographs')");
   $result=query(
 "insert into for_pagination values('12','Drawings')");
   $result=query(
 "insert into for_pagination values('13','Pictures')");
   $result=query(
 "insert into for_pagination values('14','CD-Rom')");
   $result=query(
 "insert into for_pagination values('15','Micro Films')");
  $result=query(
 "insert into currency values('UKP','Pound Sterling')");
  $result=query(
 "insert into currency values('USD','U.S.Dollar')");
  $result=query(
 "insert into currency values('CND','Canadian Dollar')");
  $result=query(
 "insert into currency values('DEM','Deustche Mark')");
  $result=query(
 "insert into currency values('DUG','Dutch Guilder')");
  $result=query(
 "insert into currency values('SFR','Swiss Franc')");
  $result=query(
 "insert into currency values('BFR','Belgian Franc')");
  $result=query(
 "insert into currency values('FFR','French Franc')");
  $result=query(
 "insert into currency values('SKR','Swedish Kroner')");
  $result=query(
 "insert into currency values('ITL','Italian Lira')");
  $result=query(
 "insert into currency values('YEN','Japanese Yen')");
  $result=query(
 "insert into currency values('AUD','Australian Dollar')");
  $result=query(
 "insert into currency values('HKD','Hongkong Dollar')");
  $result=query(
 "insert into currency values('MLR','Malaysian Ringitt')");
  $result=query(
 "insert into currency values('SPD','Singapore Dollar')");
  $result=query(
 "insert into currency values('DKR','Danish Kroner')");
  $result=query(
 "insert into currency values('NKR','Norwegian Kroner')");
  $result=query(
 "insert into currency values('SRI','Saudi Riyal')");
  $result=query(
 "insert into currency values('BHD','Bah Dinar')");
  $result=query(
 "insert into currency values('KWD','Kuw Dinar')");
  $result=query(
 "insert into classification_scheme_code values('C','Colon Classification')");
  $result=query(
 "insert into classification_scheme_code values('z','Default')");
  $result=query(
 "insert into classification_scheme_code values('D','Deway Decimal')");
  $result=query(
 "insert into classification_scheme_code values('L','Library Of Congress')");
  $result=query(
 "insert into classification_scheme_code values('U','Univresal Decimal')");
  $result=query(
 "insert into price_and_binding values(0,'DEFAULT','10/10/1000','NULL')");
  $result=query(
 "insert into classification_scheme_notation values('DEFAULT','DEFAULT','NULL','z')");
 
 $result=query(
 "insert into isbn values(0,'DEFAULT','NUL')");
 $result=query(
 "insert into role values(0,'NULL')");
 $result=query(
 "insert into edition_statt_bk values(0,'DEFAULT','NULL',0)");
 $result=query(
 "insert into vendor values(0,'DEFAULT','NULL')");
 $result=query(
 "insert into map_book_details values(0)");

 $result=query(
 "insert into invoice_details values(0,'10/10/1000','NULL','DEFAULT')");
 $result=query(
 "insert into uniform_title values('DEFAULT','NUL')"); 
       $result=query(
  "insert into pagination values('',0,0,'NULL','{{NULL},{NULL},{NULL}}','NULL')"); 
       $result=query(
  "insert into part_statt values(0,'NULL','NULL','',0)"); 
       $result=query(
  "insert into series_statt values(0,'NULL','NULL','NULL',0)"); 

       $result=query(
       "INSERT INTO map_corporate_body VALUES(0)");
       $result=query(
"INSERT INTO map_parallel_title VALUES(0)");
       $result=query(
 "INSERT INTO map_other_title VALUES(0)");
       $result=query(
 "INSERT INTO map_meeting VALUES(0)");
       $result=query(
 "INSERT INTO map_publisher VALUES(0)");
       $result=query(
 "INSERT INTO map_distribution VALUES(0)");
       $result=query(
 "INSERT INTO name_of_corporate_body VALUES(0,'NULL','NULL','NULL','NU','null')");
       $result=query(
"INSERT INTO parallel_title VALUES(0,'NULL','NULL','NUL','ba')");
       $result=query(
 "INSERT INTO name_of_corporate_body VALUES(0,'NULL',1,'NUL')");
       $result=query(
 "INSERT INTO name_of_meeting_or_conference VALUES(0,'NULL',0,'NULL','NU','null','1010-10-10')");
       $result=query(
"INSERT INTO place_and_publisher VALUES(0,'NULL','NULL','NULL','NU')");
       $result=query(
 "INSERT INTO place_and_distribution VALUES(0,'NULL','NULL','NULL','NU')");
       $result=query(
 "INSERT INTO map_abstract values(0)");
       $result=query(
 "INSERT INTO map_reserved_field values(0)");
       $result=query(
 "INSERT INTO frequency values('an','Annual')");
       $result=query(
 "INSERT INTO serial_frequency values('an','10/10/1010')");

?>
</BODY>
</HTML>










