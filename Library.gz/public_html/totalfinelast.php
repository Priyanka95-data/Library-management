<HTML>
<HEAD><TITLE>Fine paid</TITLE></HEAD>  
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

           $res = query("BEGIN WORK"); 

           $res = query("UPDATE mem_related_to_entitlement ".
                        "SET fines='0' WHERE ".
                        "mem_entitl_id='$mem_entit_id'");

           $res = query("INSERT INTO record_of_fines ".
                        "VALUES ('$receipt_no','$mem_id','$fine','CURRENT_DATE','$name')");

           //send email
           $res1=query("SELECT email FROM member WHERE ".
                       "mem_id='$mem_id' ");
           for($i=0;$i<pg_NumRows($res1);$i++){
               $to=pg_Result($res1,$i,0);
           }   

                $success=0;
                if($to)
                    {
                        $res2=query("SELECT email FROM clerk WHERE clerk='admin'");
                        $adminmail=pg_result($res2,0,"email");

                        $subj = LIBRARY . " - Fine paid";

                        $header = "From: " . $adminmail;

                        $body = LIBRARY . " \r\n\r\nThis is to inform you that " . 
                             "a fine has been paid by you: \r\n " .
                             "\r\nReceipt No.: " . $receipt_no  .
                             "\r\nFine amount: " . $fine;
                        
                        $success = mail($to, $subj, $body, $header);
                    }
                
                if($success) {
                    echo("<H2>Mail successfully sent to $mem_id</H2><BR>");
                } else {
                    echo("<H2>Mail could not be sent to $mem_id</H2><BR>");
                }
                //email sent
                
                echo("<H2>Fine settled by $mem_id</H2>");
                $res = query("COMMIT WORK");
        
                echo("<FORM ACTION=totalfine.php>"); 
                echo("<INPUT TYPE=SUBMIT VALUE='Go Back' NAME='Go Back'>");
                echo("</FORM>");
                
}
?>
</BODY>
</HTML>


















