<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    $result=query("SELECT common_to_books_and_thesis.person1, " .
                  "mem_book.mem_id, mem_book.acc_no, " . 
                  "common_to_books_and_thesis.title_bk, " .
                  "mem_related_to_entitlement.fines, " . 
                  "member.email FROM mem_book, " . 
                  "rec_acc, member, mem_related_to_entitlement, " . 
                  "name_of_person, common_to_books_and_thesis " . 
                  "WHERE mem_book.status_mem_bk='d' AND " .
                  "mem_book.mem_id=member.mem_id AND " . 
                  "member.mem_entitl_id=mem_related_to_entitlement.mem_entitl_id " . 
                  "AND mem_book.acc_no=rec_acc.acc_no AND ". 
                  "common_to_books_and_thesis.record_id=rec_acc.record_id ". 
                  "GROUP BY mem_book.mem_id, " .
                  "mem_book.acc_no, common_to_books_and_thesis.title_bk, " . 
                  "mem_related_to_entitlement.fines, " . 
                  "common_to_books_and_thesis.person1, member.email"); 
    
    
    if(pg_NumRows($result) == 0 ){
        echo("<BR><H1 ALIGN=CENTER>No overdue books <H1>");
    }else {
        echo("<BR><H1 ALIGN=CENTER>Overdue books <H1>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR><TD ALIGN = CENTER><b>Member Id.</b></TD>");
        echo("<TD ALIGN = CENTER><b>Fine</b></TD>");
        echo("<TD ALIGN = CENTER><b>Accesion No.</b></TD>");
        echo("<TD ALIGN = CENTER><b>Title </b></TD>");
        echo("<TD ALIGN = CENTER><b>Author</b></TD></TR>");
        
        for($i=0; $i<pg_NumRows($result);$i++) 
            {
                $r0=pg_Result($result,$i,0); //person1 (author id)
                
                $r6="";   
                
                $r2=pg_Result($result,$i,1); //mem_id
                $r3=pg_Result($result,$i,2); //acc_no
                $r4=pg_Result($result,$i,3); //title_bk
                $r5=pg_Result($result,$i,4); //fines
                $r6=pg_Result($result,$i,5); //email

                //                echo("Email id for $r2 is:$r6.<BR>");

                //get details of author of overdue book using person1
                $result1=query("SELECT primary_element, " .
                               "secondary_element, additional_element " .
                               "FROM name_of_person WHERE person1='$r0' ");
                
                $r1="";
                
                for($j=0; $j<pg_NumRows($result1);$j++) 
                    {
                        $s1=pg_Result($result1,$j,0); //primary_el
                        $s2=pg_Result($result1,$j,1); //sec_el
                        $s3=pg_Result($result1,$j,2); //addtnl_el
                        $r1 = $r1 . $s1 . " " . $s2 . " " . $s3 . "#";
                    }

                $res = query("SELECT CURRENT_DATE");
                $date=pg_result($res,0,0);

                $success=0;
                if($r6)
                    {
                        
                        echo("<TR><TD ALIGN = CENTER><b> $r2 </b></TD>");
                        echo("<TD ALIGN = CENTER><b> $r5 </b></TD>");
                        echo("<TD ALIGN = CENTER><b> $r3 </b></TD>");
                        echo("<TD ALIGN = CENTER><b> $r4 </b></TD>");
                        echo("<TD ALIGN = CENTER><b> $r1 </b></TD></TR>");
                        
                        
                        
                        //                        $body="Book of Folowing Accession.No: ". $r3 ." Title : ". $r4 ."And Authors : ". $r1 ." Has been Delayed by you And You Have To Pay A Fine Of Rs.". $r5 ;


                        //$admin='admin';
                        $result2=query("SELECT email FROM clerk WHERE clerk='admin'");
                        $adminmail=pg_result($result2,0,"email");

                        ////////////////////////
                        $to = $r6;

                        $subj = LIBRARY . " - Overdue books";

                        $header = "From: " . $adminmail;

                        $body = LIBRARY . " \r\n\r\nThis is to inform you that " . 
                             "the following book is overdue: \r\n " .
                             "\r\nAccession No.: " . $r3 .
                             "\r\nTitle: " . $r4 . 
                             "\r\nAuthor(s): " . $r1 .
                             "\r\n\r\nFine (as of " . $date . "): Rs." . $r5;
                        
                           $success = mail($to, $subj, $body, $header);
                        
                        //$success=1;
                      
                    }
                
                if($success) {
                    echo("Mail successfully sent to $r2<BR>");
                } else {
                    echo("Mail could not be sent to $r2<BR>");
                }
                
            }
        echo("</TABLE>");
        echo("<H3 ALIGN=CENTER> All mails sent</H1>");                
    }

    //    echo("<BR><BR>To: $to<BR>From: $header<BR>Subject: $subj<BR>Body: $body<BR>");
}
?>
</BODY>
</HTML>






