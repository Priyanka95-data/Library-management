<HTML>
<HEAD><TITLE> Administrator's Homepage</TITLE></HEAD>
<BODY BGCOLOR="#999999" TEXT="#000000" vlink="#0000bb">
<BR><HR><H1 ALIGN = CENTER>Administrator's Homepage</H1><BR><HR>

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {


 	echo("<TABLE ALIGN=CENTER width='50%'><TR><TD>");

	echo("<FORM ACTION = adminpasswd.php>");
	echo("<b>Change Passwords</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Change Password' VALUE='Change Password'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = statistics.php>");
	echo("<b>Statistics</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Statistics' VALUE='Statistics'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = clerk.php>");
	echo("<b>Add Clerk :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Add Clerk' VALUE='Add Clerk'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = acqclerk.php>");
	echo("<b>Add Acquisition Clerk :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Add Acquisition Clerk' VALUE='Add Acquisition Clerk'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = query.php>");
	echo("<b>Give Query :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Give Query' VALUE='Give Query'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = status.php>");
	echo("<b>Allocate Status:</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Define Status' VALUE='Define Status'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = admin-fines.php>");
	echo("<b>Set Fines</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Define Fines' VALUE='Define Fines'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = ticks.php>");
	echo("<b>Mark Reference After <FONT COLOR=RED>**</FONT> demands</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Mark Reference' VALUE='Mark Reference'>");
	echo("</FORM></TD></TR><TR><TD>");

	echo("<FORM ACTION = getprofile.php>");
	echo("<b>Update Profile</b></TD><TD>");
    echo("<INPUT TYPE=hidden NAME=nametochange VALUE='$name'>");
    echo("<INPUT TYPE=hidden NAME=group VALUE='Administrator'>");
	echo("<INPUT TYPE=SUBMIT NAME='Update Profile' VALUE='Update Profile'>");

	echo("</FORM></TD></TR> </TABLE>");
	echo("<BR><HR><DIV ALIGN=RIGHT>");
	echo("<A HREF=logout.php><b>Logout</b></A>");
	echo("</DIV>");
}else{
    //login failed
    header("Location: http://$HTTP_HOST/~pro/authfail.html");
}

?>
</BODY>
</HTML>