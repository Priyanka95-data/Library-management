<HTML>
  
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
	<H1>Please Verify The Information. <H1>
	</DIV>

        <?php

    $asdf= 0;

 $database = pg_connect("dbname=lms user=pro password=pro");

 
if($invoice_no1 != 0)
{
        	$result = pg_Exec($database,
                "select title_bk_details,invoice_no from book_details where title_bk='$title_bk1' and invoice_no='$invoice_no1' "); 

              $fdsa =  pg_NumRows($result);
  if($fdsa == 0 )
{ 
    $asdf = 1;
    echo("  Wrong Invoice No. ");

}
}             



  if( $acc_no1 && $bibliographic_level_desc1 && $location1 && $date_of_entry_mm1 && $date_of_entry_dd1 && date_of_entry_yy1 && $language_code1 && $script1 && $translation_code1 && ($paper1 || $magnetic1 || $film1 || $laser1 || $braille1 || $other1) && $issn1 && $abbreviated_title_sr1 && $title_sr1 && $language_code_title_sr1 && $key_title1 && abbreviated_title_kt1 && $language_code_title_kt1 &&  $date_of_publication_mm1 && $date_of_publication_dd1 && $date_of_publication_yy1 && $edition_statt_sr1 && language_code_edition_statt_sr1 && $subject_desc1 && $asdf == 0)

{ 
           $subject_desc1=$subject_desc1.$subject_desc2;

            echo("<FORM ACTION=serialdatabase.php>");

if($publisher_name2 != 'NULL')
{
  $publisher_name1=$publisher_name2;
}
if($place_of_publisher2 != 'NULL')
{
  $place_of_publisher1=$place_of_publisher2;
}
if($address_of_publisher2 != 'NULL')
{
  $address_of_publisher1=$address_of_publisher2;
}
if($country_of_publisher2 != 'null')
{
  $country_of_publisher1=$country_of_publisher2;
}
if($name_of_distributor2 != 'NULL')
{
  $name_of_distributor1=$name_of_distributor2;
}
if($place_of_distributor2 != 'NULL')
{
  $place_of_distributor1=$place_of_distributor2;
}
if($address_of_distributor2 != 'NULL')
{
  $address_of_distributor1=$address_of_distributor2;
}
if($country_of_distributor2 != 'null')
{
  $country_of_distributor1=$country_of_distributor2;
}
if($name_of_vendor2 != 'DEFAULT')
{
  $name_of_vendor1=$name_of_vendor2;
}
if($city2 != 'NULL')
{
  $city1=$city2;
}
if($language_code_parallel_title2 != 'null')
{
  $language_code_parallel_title1=$language_code_parallel_title2;
}
if($script_parallel_title2 != 'NULL')
{
  $script_parallel_title1=$script_parallel_title2;
}
else
{
$script_parallel_title1='Roman';
}
if($language_code_other_title2 != 'null')
{
  $language_code_other_title1=$language_code_other_title2;
}
if($type_of_title2 != 'NULL')
{
  $type_of_title1=$type_of_title2;
}
else
{
 $type_of_title1='Sub Title';
}


 	    echo("<INPUT TYPE=hidden VALUE='$bibliographic_level_desc1' NAME=bibliographic_level_desc >");
	    $bibliographic_level_desc=$bibliographic_level_desc1;	
 	    echo("<INPUT TYPE=hidden VALUE='$location1' NAME='location' >");
	    $location=$location1;
 	    echo("<INPUT TYPE=hidden VALUE='$language_code1' NAME=language_code >");
	    $language_code=$language_code1;

 	    echo("<INPUT TYPE=hidden VALUE='$language_code_edition_statt_sr1' NAME=language_code_statt_sr >");
	    $language_code_edition_statt_sr=$language_code_statt_sr1;

 	    echo("<INPUT TYPE=hidden VALUE='$script1' NAME=script >");
	    $script=$script1;
 	    echo("<INPUT TYPE=hidden VALUE='$translation_code1' NAME=translation_code >");
	    $translation_code=$translation_code1;
 	    echo("<INPUT TYPE=hidden VALUE='$type_of_material_desc1' NAME=type_of_material_desc >");
	    $type_of_material_desc=$type_of_material_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$issn1' NAME=issn >");
	    $issn=$issn1;
 	    echo("<INPUT TYPE=hidden VALUE='$coden1' NAME=coden >");
	    $coden=$coden1;


 	    echo("<INPUT TYPE=hidden VALUE='$title_sr1' NAME=title_sr >");
	    $title_sr=$title_sr1;

 	    echo("<INPUT TYPE=hidden VALUE='$language_code_title_sr1' NAME=language_code_title_sr >");
	    $language_code_title_sr=$language_code_title_sr1;

 	    echo("<INPUT TYPE=hidden VALUE='$parallel_title1' NAME=parallel_title >");
	    $parallel_title=$parallel_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$key_title1' NAME=key_title >");
	    $key_title=$key_title1;

 	    echo("<INPUT TYPE=hidden VALUE='$abbreviated_title_sr1' NAME=abbreviated_title_sr >");
            $abbreviated_title_sr=$abbreviated_title_sr1;
	    
 	    echo("<INPUT TYPE=hidden VALUE='$abbreviated_title_kt1' NAME=abbreviated_title_kt >");
            $abbreviated_title_kt=$abbreviated_title_kt1;
	    
 	    echo("<INPUT TYPE=hidden VALUE='$language_code_parallel_title1' NAME=language_code_parallel_title >");
	    $language_code_parallel_title=$language_code_parallel_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$language_code__title_kt1' NAME=language_code_title_kt >");
	    $language_code_title_kt=$language_code_title_kt1;

 	    echo("<INPUT TYPE=hidden VALUE='$other_title1' NAME=other_title >");
	    $other_title=$other_title1;

 	    echo("<INPUT TYPE=hidden VALUE='$uniform_title1' NAME=uniform_title >");
	    $uniform_title=$uniform_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$language_code_uniform_title1' NAME=language_code_uniform_title >");
	    $language_code_uniform_title=$language_code_uniform_title1;



 	    echo("<INPUT TYPE=hidden VALUE='$publisher_name1' NAME= publisher_name>");
	    $publisher_name=$publisher_name1;
 	    echo("<INPUT TYPE=hidden VALUE='$place_of_publisher1' NAME=place_of_publisher >");
	    $place_of_publisher=$place_of_publisher1;
 	    echo("<INPUT TYPE=hidden VALUE='$address_of_publisher1' NAME=address_of_publisher >");
	    $address_of_publisher=$address_of_publisher1;
 	    echo("<INPUT TYPE=hidden VALUE='$country_of_publisher1' NAME=country_of_publisher >");
	    $country_of_publisher=$country_of_publisher1;
 	    echo("<INPUT TYPE=hidden VALUE='$name_of_distributor1' NAME=name_of_distributor >");
	    $name_of_distributor=$name_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$place_of_distributor1' NAME=place_of_distributor >");
	    $place_of_distributor=$place_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$address_of_distributor1' NAME=address_of_distributor >");
	    $address_of_distributor=$address_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$country_of_distributor1' NAME=country_of_distributor >");
	    $country_of_distributor=$country_of_distributor1;

 	    echo("<INPUT TYPE=hidden VALUE='$name_of_vendor1' NAME=name_of_vendor >");
	    $name_of_vendor=$name_of_vendor1;
 	    echo("<INPUT TYPE=hidden VALUE='$city1' NAME=city >");
	    $city=$city1;
 	    echo("<INPUT TYPE=hidden VALUE='$invoice_no1' NAME=invoice_no >");
	    $invoice_no=$invoice_no1;
 	    echo("<INPUT TYPE=hidden VALUE='$amt_paid1' NAME=amt_paid >");
	    $amt_paid=$amt_paid1;
 	    echo("<INPUT TYPE=hidden VALUE='$name_of_grant1' NAME=name_of_grant >");
	    $name_of_grant=$name_of_grant1;

 	    echo("<INPUT TYPE=hidden VALUE='$frequency1' NAME= frequency>");
	    $frequency=$frequency1;

 	    echo("<INPUT TYPE=hidden VALUE='$note1' NAME= note>");
	    $note=$note1;
 	    echo("<INPUT TYPE=hidden VALUE='$note1' NAME= note>");
	    $note=$note1;

 	    echo("<INPUT TYPE=hidden VALUE='$bibliographic_note1' NAME=bibliographic_note >");
	    $bibliographic_note=$bibliographic_note1;
 	    echo("<INPUT TYPE=hidden VALUE='$notation1' NAME=notation >");
	    $notation=$notation1;
 	    echo("<INPUT TYPE=hidden VALUE='$edition_statt_sr1' NAME=edition_statt_sr >");
	    $edition_statt_sr=$edition_statt_sr1;


 	    echo("<INPUT TYPE=hidden VALUE='$edition_no1' NAME=edition_no >");
	    $edition_no=$edition_no1;

 	    echo("<INPUT TYPE=hidden VALUE='$identification1' NAME=identification >");
	    $identification=$identification1;
 	    echo("<INPUT TYPE=hidden VALUE='$c_s_c_desc1' NAME=c_s_c_desc >");
	    $c_s_c_desc=$c_s_c_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$subject_desc1' NAME=subject_desc >");
	    $subject_desc=$subject_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$acc_no1' NAME=acc_no >");
	    $acc_no=$acc_no1;

        $date_of_entry_mm1 .= "/";
        $date_of_entry_dd1 .= "/";
	$date_of_entry1 .=$date_of_entry_mm1;
        $date_of_entry1 .=$date_of_entry_dd1;
        $date_of_entry1 .=$date_of_entry_yy1;


 	    echo("<INPUT TYPE=hidden VALUE='$date_of_entry1' NAME=date_of_entry >");
	    $date_of_entry=$date_of_entry1;


        $date_of_fre_mm1 .= "/";
        $date_of_fre_dd1 .= "/";
	$date_of_fre1 .=$date_of_fre_mm1;
        $date_of_fre1 .=$date_of_fre_dd1;
        $date_of_fre1 .=$date_of_fre_yy1;
        if($date_of_fre1 == '//')
        {
           $date_of_fre1 = '10/10/1010';
        }

 	    echo("<INPUT TYPE=hidden VALUE='$date_of_fre1' NAME=date_of_fre >");
	    $date_of_fre=$date_of_fre1;



        $date_of_invoice_mm1 .= "/";
        $date_of_invoice_dd1 .= "/";
	$date_of_invoice1 .=$date_of_invoice_mm1;
        $date_of_invoice1 .=$date_of_invoice_dd1;
        $date_of_invoice1 .=$date_of_invoice_yy1;
        if($date_of_invoice1 == '//')
        {
           $date_of_invoice1 = '10/10/1010';
        }

 	    echo("<INPUT TYPE=hidden VALUE='$date_of_invoice1' NAME=date_of_invoice >");
	    $date_of_invoice=$date_of_invoice1;
    echo("<INPUT TYPE=hidden VALUE='$paper1' NAME=paper1 >");
    echo("<INPUT TYPE=hidden VALUE='$film1' NAME=film1 >");
    echo("<INPUT TYPE=hidden VALUE='$magnetic1' NAME=magnetic1 >");
    echo("<INPUT TYPE=hidden VALUE='$laser1' NAME=laser1 >");
    echo("<INPUT TYPE=hidden VALUE='$braille1' NAME=braille1 >");
    echo("<INPUT TYPE=hidden VALUE='$other1' NAME=other1 >");
    echo("<INPUT TYPE=hidden VALUE='$reference' NAME=reference >");
    echo("<INPUT TYPE=hidden VALUE='$study' NAME=study >");




        $date_mm1 .= "/";
        $date_dd1 .= "/";
	$date1 .=$date_mm1;
        $date1 .=$date_dd1;
        $date1 .=$date_yy1;
        if($date1 == '//')
        {
           $date1 = '10/10/1010';
        }


        echo("<INPUT TYPE=hidden VALUE='$date1' NAME=date>");
        $date=$date1;
   



        $date_of_publication_mm1 .= "/";
        $date_of_publication_dd1 .= "/";
	$date_of_publication1 .=$date_of_publication_mm1;
        $date_of_publication1 .=$date_of_publication_dd1;
        $date_of_publication1 .=$date_of_publication_yy1;





 	    echo("<INPUT TYPE=hidden VALUE='$date_of_publication1' NAME=date_of_publication >");
	    $date_of_publication=$date_of_publication1;


   echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER><TR><TD>");
   echo("Bibliographic Level :$bibliographic_level_desc</TD><TD>");
   echo("Location :$location</TD></TR>");
   echo("<TR><TD>Date of Entry : $date_of_entry1</TD><TD>");            
   echo("Language :$language_code</TD></TR>");
   echo("<TR><TD>Script :$script</TD><TD>");
   echo("Translation :$translation_code</TD></TR>");
   echo("<TR><TD>Physical Medium :$physical</TD><TD>");
   echo("Type Of Material :$type_of_material_desc</TD></TR><HR>");
   echo("<TR><TD>ISBN :$isbn</TD></TR>");
   echo("<TR><TD>Qualification(Optional) :$qualifier</TD><TD>");
   echo("Document No. :$document_no</TD></TR>");
   echo("<TR><TD>Title :$title_bk</TD><TD>");
   echo("Statement Of Responsibility :$statt_of_resp_ti_bk</TD></TR>");
   echo("<TR><TD>Language :$language_code_title_bk</TD><TD>");
   echo("Script :$script_title_bk</TD></TR>");
   echo("<TR><TD>Parallel Title :$parallel_title</TD><TD>");
   echo("Statement Of Responsibility :$statement_of_resp</TD></TR>"); 
   echo("<TR><TD>Language :$language_code_parallel_title</TD><TD>");
   echo("Script :$script_parallel_title</TD></TR>");
   echo("<TR><TD>Other Title :$other_title</TD><TD>");
   echo("Type Of Title :$type_of_title</TD></TR>");
   echo("<TR><TD>Language :$language_code_other_title</TD><TD>");
   echo("Uniform Title :$uniform_title</TD></TR>");
   echo("<TR><TD>Language :$language_code_uniform_title</TD><TD>" );
   echo("Edition Statement :$forms_of_statt</TD></TR>" );
   echo("<TR><TD>Statement Of Responsibility :$statt_of_resp_bk</TD><TD>" );
   echo("Role :$role_type</TD></TR>");
   echo("<TR><TD>NAME OF PERSON (Except Author)  :</TD></TR>");
   echo("<TR><TD>Entry Element :$entry_element</TD><TD>" );
   echo("Secondary Element :$secondary_element</TD></TR>");
   echo("<TR><TD>Additional Element :$additional_element</TD><TD>" );
   echo("Date(date of birth,date of death,etc) : $date1</TD></TR>");           
   echo("<TR><TD>Role :$role_type</TD><TD>");   
   echo("Name Of Corporate Body :$name_of_corporate_body</TD></TR>");
   echo("<TR><TD>Name Of Parent Body :$parent_body_name</TD><TD>"); 
   echo("Address :$address_of_corporate_body</TD></TR>"); 
   echo("<TR><TD>Country :$country_of_corporate_body</TD><TD>");
   echo("Role :$role_of_corporate_body</TD></TR>" );
   echo("<TR><TD>NAME OF MEETING / CONFERENCE :</TD></TR>");
   echo("<TR><TD>Entry Element :$entry_element_meet</TD><TD>");
   echo("No. Of Meeting :$no_of_element</TD></TR>" );
   echo("<TR><TD>Country :$country_of_meet</TD><TD>");
   echo("Sponsor Name :$sponsor_name</TD></TR>" );
   echo("<TR><TD>Place :$place_of_meet</TD><TD>");
   echo("Date : $date_of_meeting1</TD></TR>");        
   echo("<TR><TD>PLACE AND NAME OF PUBLISHER :</TD></TR>");
   echo("<TR><TD>Name :$publisher_name</TD><TD>" );
   echo("Place :$place_of_publisher</TD></TR>"); 
   echo("<TR><TD>Address :$address_of_publisher</TD><TD>");
   echo("Country :$country_of_publisher</TD></TR>" );
   echo("<TR><TD>PLACE AND NAME OF DISTRIBUTOR :</TD></TR>");
   echo("<TR><TD>Name :$name_of_distributor</TD><TD>" );
   echo("Place :$place_of_distributor</TD></TR>" ); 
   echo("<TR><TD>Address :$address_of_distributor</TD><TD>");
   echo("Country :$country_of_distributor</TD></TR>" );
   echo("<TR><TD>Date Of Publication :$date_of_publication1</TD></TR>" );
   echo("<TR><TD>PHYSICAL DESCRIPTION :</TD></TR>" );
   echo("<TR><TD>Pagination_Description :$pagination_desc</TD><TD>" );
   echo("preliminary (Optional) :$priliminary</TD></TR>" );
   echo("<TR><TD>Textual :$textual</TD><TD>" );
   echo("illustration :$illustration</TD></TR>" );
   echo("<TR><TD>Dimensions :$l $d $h</TD><TD>" );
   echo("Accompanying Material :$accomp_material</TD></TR>");
   echo("<TR><TD>PRICE AND BINDING</TD></TR>" );
   echo("<TR><TD>Price :$price</TD><TD>" );             
   echo("<TR><TD>Date Of Price : $date_of_price1</TD><TD>");
    echo("Binding :$binding</TD></TR>" );
   echo("<TR><TD>INVOICE DETAILS :</TD></TR>" );
   echo("<TR><TD>Name Of Vendor :$name_of_vendor</TD><TD>" );
   echo("City :$city</TD></TR>" );
   echo("<TR><TD>Invoice No. :$invoice_no</TD><TD>" );
   echo("Date Of Invoice :$date_of_invoice1</TD></TR>" );             
   echo("<TR><TD>Amount Paid :$currency_of_invoice $amt_paid</TD><TD>" );
   echo("Name Of Grant :$name_of_grant</TD></TR>" );
   echo("<TR><TD>PART STATT :</TD></TR>" );
   echo("<TR><TD>Title Of Volume/Part :$part_statt</TD><TD>");
   echo("Volume/Part No. :$volume_or_part_no</TD></TR>");
   echo("<TR><TD>DETAILS OF SERIES :</TR></TD>");
   echo("<TR><TD>ISSN :$issn</TD><TD>");
   echo("Series Name :$series_name</TD></TR>");
   echo("<TR><TD>Statement Of Responsibility :$statt_of_resp_sr_stt</TD><TD>");
   echo("Note :$note</TD></TR>");
   echo("<TR><TD>Note On Bibliographic :$bibliographic_note</TD></TR>");
   echo("<TR><TD>CLASSIFICATION SCHEME NOTATION </TD></TR>" );
   echo("<TR><TD>Notation :$notation</TD></TR>");
   echo("<TR><TD>edition_no :$edition_no</TD><TD>" );
   echo("Identification Of Classification Code :$identification</TD></TR>" );
   echo("<TR><TD>Classification Scheme Code :$c_s_c_desc</TD><TD>");
   echo("Subject Descriptor :$subject_desc</TD></TR>" );
   echo("<TR><TD>Accession No. :$acc_no</TD></TR>");
   echo("</TABLE>");           
echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id>"); 
	echo("<BR>");
	echo ("<INPUT NAME=back TYPE=submit VALUE=Enter>");
	
	echo("</FORM>");
	}
        else
        {
	echo("<DIV ALIGN=CENTER> <H1> Inconvient Data. </H1></DIV>");
        }

       	echo("\t");
 	echo("<FORM ACTION=serial.php>");
	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id>"); 
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM><HR>");

        ?>
</BODY>
</HTML> 
      


