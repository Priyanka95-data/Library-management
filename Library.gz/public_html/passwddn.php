<HTML>
<HEAD><TITLE>This Page Is Used to Change ** Password **.</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">
<?php
	require("header.inc");
	if($admin_id){
        $database=pg_connect("dbname=lms user=pro");
	switch ($group){
		case "Administrator":
			$result=pg_Exec($database,"SELECT * FROM ".
			"clerk WHERE clerk='admin'");
			if(pg_NumRows($result) > 0){
			echo("<FORM ACTION=password.php METHOD=POST>");
			echo("<TABLE width='70%' ALIGN=CENTER><TR><TD>");
			echo("Please Enter New Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mpasswd></TD></TR><TR><TD>");
			echo("Verify Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mvpasswd></TD></TR></TABLE>");
			echo("<INPUT TYPE=HIDDEN NAME=value VALUE='Administrator'>");
			$value='Administrator';
			echo("<DIV ALIGN=CENTER>");
			echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
			echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
			echo("</DIV>");
			echo("</FORM>");			
			}
		break;
                case "Clerk":
			$result=pg_Exec($database,"SELECT * FROM ".
			"clerk WHERE clerk='$name'");
			if(pg_NumRows($result) > 0){
			echo("<FORM ACTION=password.php METHOD=POST>");
			echo("<TABLE width='70%' ALIGN=CENTER><TR><TD>");
			echo("Please Enter New Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mpasswd></TD></TR><TR><TD>");
			echo("<BR>Verify Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mvpasswd></TD></TR></TABLE>");
			echo("<INPUT TYPE=HIDDEN NAME=value VALUE='Clerk'>");
			echo("<INPUT TYPE=HIDDEN NAME=name VALUE='$name'>");
			$value='Clerk';
			echo("<DIV ALIGN=CENTER>");
			echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
			echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
			echo("</DIV>");
			echo("</FORM>");			
			}
		break;
                case "Member":
			$result=pg_Exec($database,"SELECT * FROM ".
			"member WHERE mem_id='$name' ");
			if(pg_NumRows($result) > 0){
			echo("<FORM ACTION=password.php METHOD=POST>");
			echo("<TABLE width='70%' ALIGN=CENTER><TR><TD>");
			echo("Please Enter New Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mpasswd></TD></TR><TR><TD>");
			echo("<BR>Verify Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mvpasswd></TD></TR></TABLE>");
			echo("<INPUT TYPE=HIDDEN NAME=value VALUE='Member'>");
			echo("<INPUT TYPE=HIDDEN NAME=name VALUE='$name'>");
			$value='Member';
			echo("<DIV ALIGN=CENTER>");
			echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
			echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
			echo("</DIV>");
			echo("</FORM>");	
			}		
		break;
                case "Acquisition Clerk":
			$result=pg_Exec($database,"SELECT * FROM ".
			"acquisition_clerk WHERE acq_clerk='$name'");
			if(pg_NumRows($result) > 0){
			echo("<FORM ACTION=password.php METHOD=POST>");
			echo("<TABLE width='70%' ALIGN=CENTER><TR><TD>");
			echo("Please Enter New Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mpasswd></TD></TR><TR><TD>");
			echo("<BR>Verify Password :</TD><TD>");
			echo("<INPUT TYPE=PASSWORD NAME=mvpasswd></TD></TR></TABLE>");
			echo("<INPUT TYPE=HIDDEN NAME=value VALUE='Acquisition Clerk'>");
			echo("<INPUT TYPE=HIDDEN NAME=name VALUE='$name'>");
			$value='Acquisition Clerk';
			echo("<DIV ALIGN=CENTER>");
			echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
			echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
			echo("</DIV>");
			echo("</FORM>");			
			}
		break;

		default:
		break;

	}
	}
	else{
        echo("<BR><HR>");
        echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
        echo("<FORM ACTION=login.html>"); 
              echo("<DIV ALIGN=RIGHT>");
              echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
              echo("</DIV>");
        echo("</FORM>");
        }

?>
</BODY>
</HTML>