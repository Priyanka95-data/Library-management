<HTML>
<HEAD><TITLE>List Of All Books</TITLE></HEAD>

<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

<?php
include("header.inc");
include("common.php");



    //        $database=pg_connect("dbname=lms user=postgres");      


    $res=query("SELECT rec_acc.acc_no, common_to_books_and_thesis.person1, " .
                  "common_to_books_and_thesis.title_bk, " .
                  "common_to_three.notation, common_to_three.identification " .
                  "FROM rec_acc, common_to_books_and_thesis, common_to_three " . 
                  "WHERE common_to_books_and_thesis.record_id=rec_acc.record_id  " . 
                  "AND common_to_three.record_id=rec_acc.record_id " .
                  "GROUP BY rec_acc.acc_no, common_to_three.notation, " .
                  "common_to_three.identification, common_to_books_and_thesis.title_bk, " . 
                  "common_to_books_and_thesis.person1"); 
    
    if(pg_numrows($res) == 0 ) {
        echo("<H1 ALIGN=CENTER>No books found<H1>");
    }else {
        $i=pg_numrows($res);
    echo("<BR><BR><BR><DIV ALIGN=CENTER><b>Total No. Of Books : $i</b> </DIV>");         
}
 
?>

</BODY>
</HTML>





