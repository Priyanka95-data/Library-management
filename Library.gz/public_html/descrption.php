<? function label_names($label_name) {
?>	<TR><TD> <b><? echo $label_name ?></b> </TD>
<? } 

function label_values($label_value,$change=1) { 
	if($change==1){ ?>
	<TD BGCOLOR=RED><FONT COLOR=WHITE>
		<? echo $label_value ?> </FONT></TD></TR>
<?	} else { ?>
	<TD> <? echo $label_value ?> </TD></TR>
<? 	} 
	} 

function label_values_for($label_value,$change) {
	if($change==1){ ?>
	<TD BGCOLOR=RED><UL><FONT COLOR=WHITE>
<?	}else { ?>
	<TD><UL><FONT>
<?	} 
	for($i=0;$i<count($label_value);$i++){ ?>
		<LI> <? echo $label_value[$i];
	} ?>
	</FONT></UL></TD>
<? }					

function for_author_fc($element,$mrole,$additional_element1,$entry_element1,$secondary_element1){
	$role=explode("#",$mrole);
	$author_chk_ae=$author_chk_se=$author_chk_ee=0;
	$entry_elmt=explode("#",$entry_element1);
	$secondary_elmt=explode("#",$secondary_element1);
	$addtnal_element=explode("#",$additional_element1);
	for($i=0;$i<count($entry_elmt);$i++){
	if(in_array($entry_elmt[$i],$element)){
		$author_chk_ee=0;
	} else {
		$author_chk_ee=1;
		break;
	}
	}
	for($i=0;$i<count($secondary_elmt);$i++){
	if(in_array($secondary_elmt[$i],$element)){
		$author_chk_se=0;
	}else {
		$author_chk_se=1;
		break;
	}
	}
	for($i=0;$i<count($addtnal_element);$i++){
	if(in_array($addtnal_element[$i],$element)){
		$author_chk_ae=0;
	} else {
		$author_chk_ae=1;
		break;
	} }
	if($author_chk_ae or $author_chk_se or $author_chk_ee) {
	?> <TD BGCOLOR=RED><FONT COLOR=WHITE> <?
		$set_nop=1;
	} else { ?>
	<TD><FONT> 
<?	}
	for($i=0;$i<count($addtnal_element) or $i<count($role) or $i<count($entry_elmt) or $i<count($secondary_elmt);$i++)
	{ 
		echo $secondary_elmt[$i]." ".$addtnal_element[$i]." ".$entry_elmt[$i];
		echo " ( $role[$i] )<BR>";
	}
?>	</FONT></TD>
<?	}

function for_publisher_distri_name($value,$name,$name1,$details){
	$value="Name Of ".$value;
	label_names($value);
	if($details=='NULL'){
		unset($details);
	}
	if($details){ ?>
		<TD BGCOLOR=RED><FONT=WHITE>
		<? echo $details;
		?>  </FONT></TD> <?
		$set=1;
	} elseif($name==$name1){
		label_values($name1,0);
		$set=0;
	}else {
		label_values($name1);
		$set=1;
	}
	return $set;
}

function for_publisher_distri_place($value,$name,$name1,$details){
        $value="Place Of ".$value;
        label_names($value);
        if($details=='NULL'){
                unset($details);
        }
        if($details){ ?>
                <TD BGCOLOR=RED><FONT=WHITE>
                <? echo $details;
                ?>  </FONT></TD> <?
		$set=1;
        } elseif($name==$name1){
                label_values($name1,0);
		$set=0;
        }else {
                label_values($name1);
		$set=1;
        }
	return $set;
}

function for_publisher_distri_addr($value,$name,$name1,$details){
        $value="Address Of ".$value;
        label_names($value);
        if($details=='NULL'){
                unset($details);
        }
        if($details){ ?>
                <TD BGCOLOR=RED><FONT=WHITE>
                <? echo $details;
                ?>  </FONT></TD> <?
		$set=1;
        } elseif($name==$name1){
                label_values($name1,0);
		$set=0;
        }else {
                label_values($name1);
		$set=1;
        }
	return $set;
}

function for_publisher_distri_con($value,$name,$name1,$details){
        $value="Country Of ".$value;
        label_names($value);
        if($details=='NULL'){
                unset($details);
        }
        if($details){ ?>
                <TD BGCOLOR=RED><FONT=WHITE>
                <? echo $details;
                ?>  </FONT></TD> <?
		$set=1;
        } elseif($name==$name1){
                label_values($name1,0);
		$set=0;
        }else {
               label_values($name1);
	       $set=1;
        }
	return $set;
}
										
?>
