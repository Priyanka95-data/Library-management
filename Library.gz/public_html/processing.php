<HTML>
<HEAD><TITLE>This is the login jumper</TITLE></HEAD>
<BODY>

<?php 

include("header.inc");
include("common.php");

delete_cookies();


if(trim($name)=="" and trim($password)=="" ) {
    echo("SORRY ... NAME AND PASSWORD ARE EMPTY<BR>");
    exit();

}else { //authenticate user
    $password = md5($password);

    if (authenticate_user($name, $password, $option)) {
        setcookie("name",$name,(time()+60*60*2));
        setcookie("password",$password,(time()+60*60*2));
        setcookie("option",$option,(time()+60*60*2));
        //        setcookie("clerk_id", $clerk_id);
    } else {
        //login failed
     header("Location: http://$HTTP_HOST/~pro/authfail.html");
    }
}

//this is common to old and new sessions    

//go to home page of the staff member

if(!$option) {
    $option="Administrator";
}

switch ($option) {
 case "Administrator":
     //        include("admin.php");
     header("Location: http://$HTTP_HOST/~pro/admin.php");
     break;
 case "Issue/Return Clerk":
     //        include("clerkentry.php");
     header("Location:http://$HTTP_HOST/~pro/clerkentry.php");
     break;
 case "Acquisition Clerk":
     //        include("clerkentry.php");
     header("Location:http://$HTTP_HOST/~pro/acqclerkentry.php?clerk_id=$name");
     break;
 case "Member Clerk":
     //        include("member.php");
     //        header("Location: http://$HTTP_HOST/~pro/member.php?clerk_id=$clerk_id&option=".(urlencode($option)));
     header("Location: http://$HTTP_HOST/~pro/member.php");
     //        exit();
     break;
     
}


?>
</BODY>
</HTML>
