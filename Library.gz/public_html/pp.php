<HTML>
<BODY>
<?
	echo("The details are : $name .<BR>");
	ereg("([A-Za-z0-9]*)( [A-Za-z0-9]*)( [A-Za-z0-9]*)( [0-9]*)",$name,$pp);
	echo("The Name is : $pp[1]<BR>");
	echo("The suranme is :$pp[2]<BR>");
	echo("The Address is :$pp[3]<BR>");
	echo("The pincode is :$pp[4]<BR>");
?>
</BODY>
</HTML>
