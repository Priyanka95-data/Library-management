<HTML>
<HEAD><TITLE>Making entry for Book.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

        include("book1.php");
     
	}else{
	echo("<BR><HR>");
	echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
	echo("<FORM ACTION=login.html>"); 
	      echo("<DIV ALIGN=RIGHT>");
          $clerk_id = $name;
	      echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$name'>");
	      echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
	      echo("</DIV>");
	echo("</FORM>");
	}
?>
</BODY>
</HTML> 







