<HTML>
<HEAD><TITLE>Search Results</TITLE></HEAD> 
<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

	<H1 ALIGN=CENTER>Search Results</H1>

	<HR>
    <?php

       if (trim($name)==""){
	  header("Location:http://$HTTP_HOST/~pro/error2.html");
	  exit();
       } 
       else {
       echo("<FORM ACTION=membersearchdisplay.php>");
       switch ($count) {
		case '10 records per page' :
			$count1=10;       
			break;
		case '20 records per page' :
			$count1=20;
			break;
		case '25 records per page' :
			$count1=25;
			break;
		case '50 records per page' :
			$count1=50;
			break;
		default :
			break;
		}
       $database=pg_connect("dbname=lms user=pro password=pro");
       $temp=0;


       switch ($selection) {

       case 'Author' :
       $namee=$name;   
       $nam=$name;
       $name1='';
       $name2='';
    	$tel=$namee;
        $w=strlen($tel);
        $l=strcspn($tel,",");
	$name=substr($tel,0,$l);
        $namee=substr($tel,$l+1,strlen($tel));
      

       	$tel=$name;
        $w=strlen($tel);
        $l=strcspn($tel," ");
	$name=substr($tel,0,$l);
	$name1=substr($tel,$l+1,strlen($tel));

	if(strlen($name1)>0){
        $tel=$name1;
        $w=strlen($tel);
        $l=strcspn($tel," ");
	$name1=substr($tel,0,$l);
	$name2=substr($tel,$l+1,strlen($tel));
        }

       
	$reach2=pg_Exec($database,"SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc,name_of_person,common_to_books_and_thesis where common_to_books_and_thesis.record_id=rec_acc.record_id and common_to_books_and_thesis.person1=name_of_person.person1 and name_of_person.primary_element='$name'  group by name_of_person.person1,common_to_books_and_thesis.title_bk union  SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc, name_of_person,title_bk where common_to_books_and_thesis.record_id=rec_acc.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and name_of_person.additional_element='$name'  group by name_of_person.person1,common_to_books_and_thesis.title_bk union  SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc, name_of_person,title_bk where common_to_books_and_thesis.record_id=rec_acc.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and name_of_person.secondary_element='$name' group by name_of_person.person1,common_to_books_and_thesis.title_bk");

	if(pg_NumRows($reach2) == 0 ){
		echo("<H1 ALIGN=CENTER>No Record <H1>");
	}else {
        echo("<H3 ALIGN=CENTER>Books found matching search criteria<H3><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");
        echo("<TH>Reserve Book</TH>");

        if($name1=="")
        {
          include("memberauthor.php");
	}
	elseif($name2==""){
	  include("memberauthor1.php");
	}
	else{
	  include("memberauthor2.php");
	}

		
		$offset+=$count1;
		echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
		echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
		echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>");
		echo("</TABLE>");
	}
            echo("<input type=hidden name=name value='$nam'>");
             $name=$nam;

             echo("<BR><INPUT TYPE=SUBMIT NAME=Reserve VALUE=Reserve>");
 	break;


       case 'Title' :
       $nam=$name;
       $reach=pg_Exec($database,
"SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 from common_to_books_and_thesis where common_to_books_and_thesis.title_bk='$name' group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 union SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 from common_to_books_and_thesis,common_to_three where common_to_three.parallel_title_id=parallel_title.parallel_title_id and parallel_title.parallel_title='$name' group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 union SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 from common_to_books_and_thesis,common_to_three where common_to_three.other_title=other_title.other_title_id and other_title.other_title='$name' group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1") ;


	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 
        

           include("membertitle.php");
	    $offset+=$count;

		  
             
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count VALUE='$count'>");
        echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
        $nam=$name;
        echo("<INPUT TYPE=HIDDEN NAME=name VALUE='$name'>");
             echo("<BR><INPUT TYPE=SUBMIT NAME=Reserve VALUE=Reserve>");
        if($offset<pg_NumRows($reach)){
             echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        }

        echo("</FORM>");

	echo("<BR>");
	echo("<FORM ACTION=membersearch.php>");
	echo("<DIV ALIGN=RIGHT>");
	echo("<INPUT TYPE=SUBMIT NAME='Go Back' VALUE='Go Back'> \t");
	echo("</DIV>");
	echo("</FORM>"); 
	}

	break;
       case 'Call Number' :
       $nam=$name;

       $reach=pg_Exec($database,"SELECT count(rec_acc.acc_no) ,".
	   "common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element ,name_of_person.secondary_element,".
	   "name_of_person.additional_element ".
	   "from rec_acc,common_to_three,common_to_books_and_thesis,map,".
	   "name_of_person WHERE name_of_person.person1=map.person1 and ".
	   "map.person1=common_to_books_and_thesis.person1 and ".
	   "common_to_books_and_thesis.record_id=common_to_three.record_id ".
	   "and rec_acc.record_id=common_to_three.record_id ".
       "AND (common_to_three.notation LIKE '%$name%'  OR ".
       "common_to_three.identification LIKE '%$name%')".
	   "GROUP BY common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element,name_of_person.secondary_element,".
	   "name_of_person.additional_element ORDER BY ".
	   "common_to_books_and_thesis.title_bk ");



	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 

  $query=pg_Exec($database,"SELECT ".
         "reservation_withheld from mem_related_to_entitlement where mem_entitl_id='$mem'");

   for($l=0;$l<pg_NumRows($query);$l++)
   {
       $reservation=pg_Result($query,$l,0);


    }

	    for($j=0;$j < $count1;$j++)
		{         
			if($reservation > 0){

                              if($a[$j] != 0){
                                $resp=pg_Exec($database,"INSERT ".
				"INTO reservation_book VALUES ".
				"('$mem_id','$a[$j]')");	
			$reservation=$reservation-1;
                         $a[$j]=0;
			}
			}
		}

	    $resp=pg_Exec($database,"UPDATE mem_related_to_entitlement ".
		"SET reservation_withheld='$reservation' WHERE ".
		"mem_entitl_id='$mem'");
	
			
	echo("<INPUT TYPE=HIDDEN VALUE='$mem_id' NAME=mem_id>"); 
	echo("<INPUT TYPE=HIDDEN VALUE='$mem' NAME=mem>"); 

        echo("<H3 ALIGN=CENTER>Books found matching search criteria<H3><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");
        echo("<TH>Reserve Book</TH>");
        $result=pg_Exec($database,"SELECT count(rec_acc.acc_no) ,".
        "common_to_books_and_thesis.title_bk,".
        "name_of_person.primary_element,name_of_person.secondary_element,".
        "name_of_person.additional_element ".
        "from rec_acc,common_to_three,common_to_books_and_thesis,map, ".
        "name_of_person where name_of_person.person1=map.person1 and ".
        "map.person1=common_to_books_and_thesis.person1 and ".
        "common_to_books_and_thesis.record_id=common_to_three.record_id ".
        "and rec_acc.record_id=common_to_three.record_id ".
        "AND (common_to_three.notation LIKE '%$name%' OR ".
        "common_to_three.identification LIKE '%$name%') ".
        "GROUP BY common_to_books_and_thesis.title_bk,".
        "name_of_person.primary_element,name_of_person.additional_element,".
        "name_of_person.secondary_element ORDER BY ".
        "common_to_books_and_thesis.title_bk LIMIT $count1,$offset");
            $offset+=$count;

	    $name='';
	    $j=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,1);
$reachy=pg_Exec($database,"select record_id from common_to_books_and_thesis where title_bk='$title'");
            for($y=0;$y<pg_NumRows($reachy);$y++){
		    $record=pg_Result($reachy,$y,0);
}

		    $name1=pg_Result($result,$i,2);
		    $name2=pg_Result($result,$i,3);
		    $name3=pg_Result($result,$i,4);
		    $countz=pg_Result($result,$i,0);
                 
		    $name .= $name1;
                    if($name2 !=''){
		        $name .=' ';
                	$name .=$name2;
		    }
                    if($name3 !=''){
		        $name .='.';
                	$name .=$name3;
		    }

                    $name .=',';
		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
                              include("count1.php");
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$j);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo (substr($name,0,strlen($name)-1));
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $countz;
                        $left=$countz-$left;
                        echo("</b></TD>");
                 if($left == 0 && $reservation!=0){
 echo("<TD ALIGN=CENTER><b>");
 
                          echo("<input type=checkbox name='a[$i]' value='$record'>");
 
 
} 
		    echo("<TD ALIGN=CENTER><b>");

                	    echo("</b></TD></TR>");
		    }
		  
             }
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count VALUE='$count'>");
	$name=$nam;
              echo("<INPUT TYPE=HIDDEN NAME=name VALUE='$name'>");
              echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
        if($offset<pg_NumRows($reach)){
             echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        }
             echo("<INPUT TYPE=SUBMIT NAME=Reserve VALUE=Reserve>");
        echo("</FORM>");
	echo("</TABLE>");
	echo("<BR>");
	echo("<FORM ACTION=membersearch.php>");
	echo("<INPUT TYPE=HIDDEN VALUE='$mem_id' NAME=mem_id>"); 
	echo("<INPUT TYPE=HIDDEN VALUE='$mem' NAME=mem>"); 


	echo("<DIV ALIGN=RIGHT>");
	echo("<INPUT TYPE=SUBMIT NAME='Go Back' VALUE='Go Back'> \t");
	echo("</DIV>");
	echo("</FORM>"); 
	}
	break;
       case 'Keywords' :
 $nam=$name;
  $query=pg_Exec($database,"SELECT ".
         "reservation_withheld from mem_related_to_entitlement where mem_entitl_id='$mem'");

   for($l=0;$l<pg_NumRows($query);$l++)
   {
       $reservation=pg_Result($query,$l,0);


    }

	    for($j=0;$j < $count1;$j++)
		{         
			if($reservation > 0){


                              if($a[$j] != 0){
                    
                               $resp=pg_Exec($database,"INSERT ".
				"INTO reservation_book VALUES ".
				"('$mem_id','$a[$j]')");	
			$reservation=$reservation-1;
                         $a[$j]=0;
			}
			}
		}

	    $resp=pg_Exec($database,"UPDATE mem_related_to_entitlement ".
		"SET reservation_withheld='$reservation' WHERE ".
		"mem_entitl_id='$mem'");
	
			
	echo("<INPUT TYPE=HIDDEN VALUE='$mem_id' NAME=mem_id>"); 
	echo("<INPUT TYPE=HIDDEN VALUE='$mem' NAME=mem>"); 

       $reach=pg_Exec($database,"SELECT ".
	   "common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 ".
	   "from common_to_three,common_to_books_and_thesis ".
	   " where ".
	   "common_to_books_and_thesis.record_id=common_to_three.record_id ".
	   "and rec_acc.record_id=common_to_three.record_id ".
	   "and common_to_three.note LIKE '%$name%' ".
	   "GROUP BY common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1");



	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 

        echo("<H3 ALIGN=CENTER>Books found matching search criteria<H3><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No<TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");
        echo("<TH>Reserve Book</TH>");

       $result=pg_Exec($database,"SELECT ".
	   "common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1, count(rec_acc.record_id),rec_acc.record_id ".
	   "from rec_acc,common_to_three,common_to_books_and_thesis".
	   " where ".
	   "common_to_books_and_thesis.record_id=common_to_three.record_id ".
	   "and rec_acc.record_id=common_to_three.record_id ".
	   "and common_to_three.note LIKE '%$name%' ".
	   "GROUP BY common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,rec_acc.record_id ".
	   " LIMIT $count1,$offset");


            $offset+=$count;
	    $name='';
	    $a=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,0);
		    $record=pg_Result($result,$i,3);



		    $rest=pg_Result($result,$i,1);
		    $countz=pg_Result($result,$i,2);

       $reach1=pg_Exec($database,
              "select primary_element,secondary_element,additional_element from name_of_person where person1='$rest'");
                 
 
                  $name5=" ";
            for($j=0;$j<pg_NumRows($reach1);$j++){
		    $name1=pg_Result($reach1,$j,0);
		    $name2=pg_Result($reach1,$j,1);
                    $name3=pg_Result($reach1,$j,2);

		    $name5 .= $name1;
                 
		        $name5 .=' ';
                	$name5 .=$name2;
	
		        $name5 .=' ';
                	$name5 .=$name3;
	

                    $name5 .=',';


}

		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
                              include("count.php");
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$a);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $name5;
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
                echo $countz;
                $left=$countz-$left;
                echo("</b></TD>");                    
                
                if($left == 0 && $reservation!=0){
                    echo("<TD ALIGN=CENTER><b>");
                    //      a[$i]=$record;
                    echo("<input type=checkbox name='a[$i]' value='$record'>");
                } 

                 echo("<TD ALIGN=CENTER><b>");
                 echo("</b></TD></TR>");
		    }
		  
            }
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
        echo("<INPUT TYPE=HIDDEN NAME=count VALUE='$count'>");
         $name=$nam;
        echo("<INPUT TYPE=HIDDEN NAME=name VALUE='$name'>");
        if($offset<pg_NumRows($reach)){
             echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        }
             echo("<INPUT TYPE=SUBMIT NAME=Reserve VALUE=Reserve>");
        echo("</FORM>");
	echo("</TABLE>");
	echo("<BR>");
	echo("<FORM ACTION=membersearch.php>");
	echo("<DIV ALIGN=RIGHT>");
	echo("<INPUT TYPE=SUBMIT NAME='Go Back' VALUE='Go Back'> \t");
	echo("</DIV>");
	echo("</FORM>"); 
	}
	break;
       case 'Journal Title' :

	//    $reach=pg_Exec($database,"SELECT ".

	  // "common_to_books_and_thesis.title_bk");

	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 

        echo("<H3 ALIGN=CENTER>Books found matching search criteria<H3><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No<TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");
        echo("<TH>Reserve Book</TH>");

//	$result=pg_Exec($database,"SELECT ".

	    $name='';
	    $j=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,1);
		    $name1=pg_Result($result,$i,2);
		    $name2=pg_Result($result,$i,3);
		    $name3=pg_Result($result,$i,4);
		    $count=pg_Result($result,$i,0);
                 
		    $name .= $name1;
                    if($name2 !=''){
		        $name .=' ';
                	$name .=$name2;
		    }
                    if($name3 !=''){
		        $name .='.';
                	$name .=$name3;
		    }
                    $name .=',';
		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$j);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo (substr($name,0,strlen($name)-1));
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $count;
                	    echo("</b></TD></TR>");
		    }
		  
             }
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count VALUE='$count'>");
        if($offset<pg_NumRows($reach)){
             echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        }
             echo("<INPUT TYPE=SUBMIT NAME=Reserve VALUE=Reserve>");
        echo("</FORM>");
	echo("</TABLE>");
	echo("<BR>");
	echo("<FORM ACTION=search.html>");
	echo("<DIV ALIGN=RIGHT>");
	echo("<INPUT TYPE=SUBMIT NAME='Go Back' VALUE='Go Back'> \t");
	echo("</DIV>");
	echo("</FORM>"); 
	}
	break;
       default :
	break;
       }
      }	
    ?>

</BODY>
</HTML>

