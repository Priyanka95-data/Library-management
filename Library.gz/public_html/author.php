<?php
	$m=0;
    $reach=pg_Exec($database,"SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc,name_of_person,common_to_books_and_thesis where common_to_books_and_thesis.record_id=rec_acc.record_id and common_to_books_and_thesis.person1=name_of_person.person1 and name_of_person.primary_element LIKE '%$name%'  group by name_of_person.person1,common_to_books_and_thesis.title_bk union  SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc, name_of_person,title_bk where common_to_books_and_thesis.record_id=rec_acc.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and name_of_person.additional_element LIKE '%$name%'  group by name_of_person.person1,common_to_books_and_thesis.title_bk union  SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc, name_of_person,title_bk where common_to_books_and_thesis.record_id=rec_acc.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and name_of_person.secondary_element LIKE '%$name%'  group by name_of_person.person1,common_to_books_and_thesis.title_bk ".
		"LIMIT $count1,$offset ");

$test=$namee ;
            for($i=0;$i<pg_NumRows($reach);$i++){
		    $title=pg_Result($reach,$i,0);
		    $rest=pg_Result($reach,$i,1);
		    $countz=pg_Result($reach,$i,2);
       $reach1=pg_Exec($database,
              "select primary_element,secondary_element,additional_element from name_of_person where person1='$rest'");
   		      $name5='';                 
            for($j=0;$j<pg_NumRows($reach1);$j++){
                  
		    $name1=pg_Result($reach1,$j,0);
		    $name2=pg_Result($reach1,$j,1);
                    $name3=pg_Result($reach1,$j,2);

		    $name5 .= $name1;
                 
		        $name5 .=' ';
                	$name5 .=$name2;
	
		        $name5 .=' ';
                	$name5 .=$name3;
	

                    $name5 .=',';

                    }
     $hiren=1;
$namee .=',';
$namee .='zzz';
        while($namee !='zzz' )
{	
 
        $name='';
        $name1='';
        $name2='';
        $tel=$namee;
        $w=strlen($tel);
        $l=strcspn($tel,",");
	$name=substr($tel,0,$l);
        $namee=substr($tel,$l+1,strlen($tel));
      

       	$tel=$name;
        $w=strlen($tel);
        $l=strcspn($tel," ");
	$name=substr($tel,0,$l);
	$name1=substr($tel,$l+1,strlen($tel));

	if(strlen($name1)>0){
        $tel=$name1;
        $w=strlen($tel);
        $l=strcspn($tel," ");
	$name1=substr($tel,0,$l);
	$name2=substr($tel,$l+1,strlen($tel));
        }
 
if($hiren == 1)
{
              $hiren=0;

      if(preg_match("/$name/i","$name5"))
{
      if(preg_match("/$name1/i","$name5"))
{
      if(preg_match("/$name2/i","$name5"))
{
          $hiren=1;
 
     }
}
}
}
}
	    if($hiren == 1)
{  
     
		   echo("<TR><TD ALIGN=CENTER><b>");
		    echo(++$m);
		    echo("</b></TD>");
		    echo("<TD ALIGN=CENTER><b>");
        	    echo $title; 
		    echo("<b></TD>");
		    echo("<TD ALIGN=CENTER><b>");
        	    echo (substr($name5,0,strlen($name5)-1));
		    echo("</b></TD>");
		    echo("<TD ALIGN=CENTER><b>");
        	    echo $countz;
                   echo("</b></TD></TR>");
}
$namee=$test;
}

?>










