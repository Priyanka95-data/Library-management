<HTML>
<HEAD><TITLE>This Page is used as accession register</TITLE></HEAD>
<BODY>
<TABLE ALIGN=CENTER WIDTH='200%'><TR bgcolor='B0C4DE'>
<TD>Date Of Entry</TD>
<TD>Accession No.</TD>
<TD>Title & SubTitle</TD>
<TD>Author</TD>
<TD>Publisher</TD>
<TD>Place Of Pub.& Date</TD>
<TD>Supplier</TD>
<TD>Pages</TD>
<TD>Call No.</TD>
<TD>Order No.</TD>
<TD>Bill No.</TD>
<TD>Amount</TD>
<TD>Remark</TD>
</TR></TABLE>
</BODY>
</HTML>