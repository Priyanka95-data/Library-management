<HTML>
<HEAD><TITLE>The Member Database Has Been Updated</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316436">
<?php
	require("header.inc");
	if($mem_id){
	    	echo("<FORM ACTION=loginmember.html>");
		$data=pg_connect("dbname=lms user=pro");
		$database=pg_Exec($data,"UPDATE member SET ".
			"institution='$institution',field='$field',".
			"temporary_address='$temporary_address',".
			"permanent_address='$permanent_address',".
			"phone='$phone',email='$email',year='$year' ".
			"WHERE mem_id='$mem_id'");
		echo("<H2 ALIGN=CENTER><u><b>$first_name $surname</b></u>");
		echo(" Your Information Has Been Updated </H2><BR><HR>");
		echo("<H3 ALIGN=RIGHT><U>Thank You</U></H3>"); 
		echo("<DIV ALIGN=CENTER>");
		echo("<INPUT TYPE=SUBMIT NAME='Logout' VALUE='Logout'>");
		echo("</DIV>");
		echo("</FORM>");
	}
	else{
		header("Location:http://$HTTP_HOST/~pro/forbidden.html");
		exit();
	}
?>
</BODY>
</HTML>