<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

	<DIV  ALIGN = CENTER>
	<HR>
	<BR><BR>

	<?php


        	$database = pg_connect("dbname=lms user=pro password=pro");

$temp='n';

        	$result = pg_Exec($database,
        	"begin work;"); 

if($invoice == 0 && $invoice_no != 0)
{
if($invoice == 0)
{
        	$result = pg_Exec($database,
               "insert into invoice_details values ('$invoice_no','$invoicedate','$net','$grant')");

	$result=pg_exec($database,"SELECT * FROM order_now WHERE order_no ='$orderno'");
	if(pg_NumRows($result)==0){
		echo("<TABLE WIDTH=100%><TR><TD>");
		echo("<H2 ALIGN=CENTER>Please Enter the Order first As it doesn't seem to exist</H1></TD></TR><BR><HR><BR>");
	echo("<TR><TD><A HREF=order.php>Go to Order Menu</A></TD>");
	echo("<TD><A HREF=book.php>Make A New Entry</A></TD>");
	echo("<TD><A HREF=logout.php>Logout</A></TD></TR></TABLE>");
	exit();
	}
        	$result = pg_Exec($database,
               "insert into acquisition values('$orderno','$name','$arrivaldate','$invoice_no')");

}
else
{                	$result = pg_Exec($database,
              "select amt_paid from invoice_details where invoice_no = '$invoice_no' ");

        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $amt_paid=pg_Result($result,$i,0);
                
        }
  $amt_paid = $amt_paid + $net;
                	$result = pg_Exec($database,
        "update invoice_details set amt_paid='$amt_paid' where invoice_no = '$invoice_no'");

}
}

       	$result = pg_Exec($database,
        	"INSERT INTO language_id values (".
	"nextval('language_id_seq'),language_code('$language_code'),".
	"script('$script'),language_code('$translation_code'))"); 
	

if($uniform_title != '')
{
              $result = pg_Exec($database,
                 "INSERT INTO uniform_title values('$uniform_title',language_code('$language_code_uniform_title'))");
}
else
{
 $uniform_title='DEFAULT';
}

if($parallel_title != '')
{

              $result = pg_Exec($database,
                 "INSERT INTO map_parallel_title VALUES(nextval('parallel_title_seq'))");  


$t=$parallel_title;
$t1=$statement_of_resp;
$t2=$language_code_parallel_title;
$t3=$script_parallel_title;


	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);




              $result = pg_Exec($database,
                 "INSERT INTO parallel_title values(currval('parallel_title_seq'),'$te','$te1',language_code('$te2'),script('$te3'))");

    $result=pg_Exec($database,"SELECT currval('parallel_title_seq') from map_parallel_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $parallel_title12=pg_Result($result,$i,0);
                
        }

              
 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);



              $result = pg_Exec($database,
                 "INSERT INTO parallel_title values(currval('parallel_title_seq'),'$te','$te1',language_code('$te2'),script('$te3'))");


}  //while
}  //if
else
{
  $parallel_title12=0;
}



if($other_title != '')
{
     $result = pg_Exec($database,
                 "INSERT INTO map_other_title VALUES(nextval('other_title_seq'))");  
       


$t=$other_title;
$t1=$type_of_title;
$t2=$language_code_other_title;



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);



  
             $result = pg_Exec($database,
                 "insert into other_title values(currval('other_title_seq'),'$te',type_of_title('$te1'),language_code('$te2'))");

    $result=pg_Exec($database,"SELECT currval('other_title_seq') from map_other_title ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $other_title12=pg_Result($result,$i,0);
                
        }
              

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);


             $result = pg_Exec($database,
                 "insert into other_title values(currval('other_title_seq'),'$te',type_of_title('$te1'),language_code('$te2'))");
}  //while
}
else
{
  $other_title12=0;
}


if($name_of_corporate_body != '')
{

     $result = pg_Exec($database,
                 "INSERT INTO map_corporate_body VALUES(nextval('name_of_corporate_body_seq'))");  



$t=$name_of_corporate_body;
$t1=$parent_body_name;
$t2=$address_of_corporate_body;
$t3=$country_of_corporate_body;
$t4=$role_of_corporate_body;


	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);





  $result = pg_Exec($database,
                  "insert into name_of_corporate_body values(currval('name_of_corporate_body_seq'),'$te','$te1','$te2',country('$te3'),'$te4')");
              

    $result=pg_Exec($database,"SELECT currval('name_of_corporate_body_seq') from map_corporate_body ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $name_of_corporate_body12 = pg_Result($result,$i,0);
                
        }

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);



	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);



  $result = pg_Exec($database,
                  "insert into name_of_corporate_body values(currval('name_of_corporate_body_seq'),'$te','$te1','$te2',country('$te3'),'$te4')");
}
}
else
{
 $name_of_corporate_body12 = 0;
}

   
if($price != '')
{ 
  $result = pg_Exec($database,
                  "insert into price_and_binding values(nextval('price_id_seq'),'$price','$date_of_price','$binding')");

    $result=pg_Exec($database,"SELECT currval('price_id_seq') from price_and_binding ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $price_id_seq_1=pg_Result($result,$i,0);
                
        }

  // $price_id_seq_1 = currval('price_id_seq');
}
else
{
$price_id_seq_1 = 0;
}


if($priliminary != '' && $textual != 0)
{
	$result=pg_Exec($database,"SELECT * FROM pagination WHERE preliminary='$priliminary' AND textual=$textual");
	if(pg_NumRows($result)==0){	

  $result = pg_Exec($database,
                  "insert into pagination values('$priliminary',$textual,for_pagination('$pagination_desc'),'$illustration','{{$l},{$b},{$h}}','$accomp_material')");
}
if($volume_or_part_no != '')
{
 $result = pg_Exec($database,
 "insert into part_statt values( nextval('part_statt_seq'),'$volume_or_part_no','$part_statt','$priliminary',$textual)");

$issn=(int)$issn;
if($issn == 0)
{
$issn=0;
}else
{
  $result = pg_Exec($database,
          "insert into series_statt values( $issn,'$series_name','$statt_of_resp_sr_stt','$volume_or_part_no',currval('part_statt_seq'))");
}

$result=pg_Exec($database,"SELECT currval('part_statt_seq') from part_statt ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $part_statt_seq_1=pg_Result($result,$i,0);
                
        }

   // $part_statt_seq_1 = currval('part_statt_seq');
}
else
{
$part_statt_seq_1 = 0;
$issn = 0;
}
}  
else
{
// $priliminary="a";
// $textual=0;
$issn = 0;
$part_statt_seq_1 = 0;
}


if($notation != '' && $edition_no != '')
{ 
  $result = pg_Exec($database,
                  "insert into classification_scheme_notation values('$notation','$edition_no','$identification','z')");
}
else
{
 $notation='DEFAULT';
 $identification='NULL';
}
 

if($name_of_distributor != '')
{
  $result = pg_Exec($database,
           "INSERT INTO map_distribution values( nextval('place_and_distribution_seq'))");

$t=$place_of_distributor;
$t1=$name_of_distributor;
$t2=$address_of_distributor;
$t3=$country_of_distributor;

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


 $result = pg_Exec($database,
                 "insert into place_and_distribution values(currval('place_and_distribution_seq'),'$te','$te1','$te2',country('$te3'))");    

    $result=pg_Exec($database,"SELECT currval('place_and_distribution_seq') from map_distribution ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $name_of_distributor12=pg_Result($result,$i,0);
                
        }

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


 $result = pg_Exec($database,
                 "insert into place_and_distribution values( currval('place_and_distribution_seq'),'$te','$te1','$te2',country('$te3'))");    
}
}
else
{
 $name_of_distributor12=0;
}


if($isbn != '')
{
  $result = pg_Exec($database,
                 "insert into isbn values(nextval('isbn_seq'),'$isbn','$qualifier')");
    $result=pg_Exec($database,"SELECT currval('isbn_seq') from isbn ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $isbn_seq_1=pg_Result($result,$i,0);
                
        }

  // $isbn_seq_1 = currval('isbn_seq');
}
else
{
$isbn_seq_1 = 0;
}

if($entry_element_meet != '')
{
     $result = pg_Exec($database,
                 "INSERT INTO map_meeting VALUES(nextval('no_of_meeting_or_conference_seq'))");  



$t=$entry_element_meet;
$t1=$no_of_element;
$t2=$sponsor_name;
$t3=$country_of_meet;
$t4=$place_of_meet;
$t5=$date_of_meeting;

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


	$l4=strcspn($t4,"#");
	$te4=substr($t4,0,$l4);
	$t4=strstr($t4,'#');
	$t4=substr($t4,1);


	$l5=strcspn($t5,"#");
	$te5=substr($t5,0,$l5);
	$t5=strstr($t5,'#');
	$t5=substr($t5,1);



  $result = pg_Exec($database,
                "insert into name_of_meeting_or_conference values( currval('no_of_meeting_or_conference_seq'),'$te',$te1,'$te2',country('$te3'),'$te4','$te5')");

    $result=pg_Exec($database,"SELECT currval('no_of_meeting_or_conference_seq') from map_meeting ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $no_of_meeting_or_conference_12=pg_Result($result,$i,0);
                
        }

  // $no_of_meeting_or_conference_seq_1 = currval('no_of_meeting_or_conference_seq');
 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);

  $result = pg_Exec($database,
                "insert into name_of_meeting_or_conference values(currval('no_of_meeting_or_conference_seq'),'$te','$te1','$te2',country('$te3'),'$te4','$te5')");
}


}
else
{
$no_of_meeting_or_conference_seq_12 = 0;
}


 $result = pg_Exec($database,
                 "insert into title_bk values(nextval('title_bk_seq'),'$title_bk','$statt_of_resp_ti_bk',language_code('$language_code_title_bk'),script('$script_title_bk'))");




if($publisher_name == '')
{
$publisher_name12=0;

}
if($publisher_name != '')
{
     $result = pg_Exec($database,
                 "INSERT INTO map_publisher VALUES(nextval('publisher_name_seq'))");  

  $resultz=pg_Exec($database,"SELECT currval('publisher_name_seq') from map_publisher ");
        
        for($j=0; $j<pg_NumRows($resultz);$j++) {
      
		$publisher_name12=pg_Result($resultz,$j,0);
        }


$t1=$place_of_publisher;
$t=$publisher_name;
$t2=$address_of_publisher;
$t3=$country_of_publisher;



	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);

$result = pg_Exec($database,
                "insert into place_and_publisher values(currval('publisher_name_seq'),'$te','$te1','$te2',country('$te3'))");  

  

 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);


$result = pg_Exec($database,
                "insert into place_and_publisher values(currval('publisher_name_seq'),'$te','$te1','$te2',country('$te3'))");  
}
}

$t=$entry_element;
$t1=$secondary_element;
$t2=$additional_element;
$t3=$role_type;


	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);




 $result = pg_Exec($database,
               "INSERT INTO map VALUES( nextval('person1_seq'))"); 

$te=ucfirst($te);
$te1=ucfirst($te1);
$te2=ucfirst($te2);


 $result = pg_Exec($database,
                "insert into name_of_person values(currval('person1_seq'),'$te','$te1','$te2','$date','',role('$te3'))");
              
 while(strlen($t) >= 1	)
{

	$l1=strcspn($t1,"#");
	$te1=substr($t1,0,$l1);
	$t1=strstr($t1,'#');
	$t1=substr($t1,1);

	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);

	$l2=strcspn($t2,"#");
	$te2=substr($t2,0,$l2);
	$t2=strstr($t2,'#');
	$t2=substr($t2,1);

	$l3=strcspn($t3,"#");
	$te3=substr($t3,0,$l3);
	$t3=strstr($t3,'#');
	$t3=substr($t3,1);



$te=ucfirst($te);
$te1=ucfirst($te1);
$te2=ucfirst($te2);

 $result = pg_Exec($database,
                "insert into name_of_person values(currval('person1_seq'),'$te','$te1','$te2','$date','',role('$te3'))");

}





$temp=strlen($physical12);
$physical12 = substr($physical12,0,($temp - 1));



          $result = pg_Exec($database,
          "INSERT INTO map_physical_medium VALUES(nextval('physical_medium_seq'))");  



if($paper1 == "paper")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$paper1'))");  
}


if($film1 == "film")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$film1'))");  
}


if($magnetic1 == "magnetic")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$magnetic1'))");  
}


if($laser1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$laser1'))");  
}


if($other1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$other1'))");  
}



if($braille1 != " ")
{
              $result = pg_Exec($database,
                 "INSERT INTO physical_medium_m VALUES(currval('physical_medium_seq'),physical_medium('$braille1'))");  
}



          

 $result = pg_Exec($database,
               "insert into common_to_three values(nextval('record_id_seq'),'$location','$date_of_entry',currval('language_id_seq'),currval('physical_medium_seq'),'$parallel_title12','$other_title12','$publisher_name12','$date_of_publication','$note','$notation','$identification','$subject_desc','$name')");

if($forms_of_statt != ' ' )
{

  $result = pg_Exec($database,
          "insert into edition values(currval('record_id_seq'),'$forms_of_statt')");
}



if($invoice_no != 0 )
{
              	$result = pg_Exec($database,
            "insert into book_details values (currval('record_id_seq'),' ','$title_bk','$primary_element',' ',' ','$copies','$amt','$total','$discount','$net','$invoice_no')");  
}
 $result = pg_Exec($database,
               "insert into common_to_books_and_serial values( currval('record_id_seq'),bibliographic_level('$bibliographic_level_desc'),'$uniform_title',$name_of_distributor12,$invoice_no,'$bibliographic_note')");




$result = pg_Exec($database,
              "insert into books values(currval('record_id_seq'),'$isbn_seq_1','$edition_statt_bk_seq_1','$no_of_meeting_or_conference_seq_12','$price_id_seq_1','$issn','$part_statt_seq_1')");


  $result = pg_Exec($database,
               "insert into common_to_books_and_thesis values (currval('record_id_seq'),type_of_material('$type_of_material_desc'),'$document_no','$title_bk',currval('title_bk_seq'),currval('person1_seq'),'$name_of_corporate_body12','$priliminary',$textual)");

$t=$acc_no;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into rec_acc values('$te',currval('record_id_seq'))");
}
$length=strlen($t);
$t=$reference;
$length=strlen($reference);
while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($t,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into reference_book values('$te','r')");


}

$t=$study;
 while(strlen($t) >= 1	)
{
	$l=strcspn($t,"#");
	$te=substr($te,0,$l);
	$t=strstr($t,'#');
	$t=substr($t,1);
$result = pg_Exec($database,
              "insert into reference_book values('$te','s')");
}
$temp='y';
$result = pg_Exec($database,
        	"commit work;"); 



if($temp=='y')
{
echo("<H2>Data has been sucessfully inserted into the database.</H2><BR>"); 
	echo("<FORM ACTION=book.php>");
	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); 
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM><BR><BR>");

	echo("<FORM ACTION=remarks.php>");
	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); 
	echo("<INPUT NAME='Remarks' TYPE=submit VALUE='Remarks'><BR>");
	echo("</FORM><HR>");


} ?>
</DIV>
	<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
	<DIV ALIGN=LEFT>
		<A HREF=acqclerkentry.php><b>
		<FONT COLOR=RED>Goto Home Page</FONT></b></A>
	</DIV></TD><TD>
	<DIV ALIGN=right>
		<A HREF=logout.php><b><FONT COLOR=RED>Logout</FONT></b></A>
	</DIV></TD></TR></TABLE>
 </BODY>
</HTML> 
      





