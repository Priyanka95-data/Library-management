<HTML>
         <HEAD><TITLE>Making entry for Books.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

         <DIV ALIGN = CENTER> <H1>Enter Into Books Database </H1></DIV>
         <FORM ACTION=bookdisplay5.php METHOD=GET>
         <HR><DIV ALIGN=CENTER>
	 <H3>
         Use "#" sign to separate the names where ever multiple entries are required
         </H3></DIV>
	 <HR>
         <BR>
	<TABLE ALIGN=CENTER WIDTH="90%">
         <TD><b>Bibliographic Level * :</b></TD><TD>
            <SELECT NAME="bibliographic_level_desc1">
             <OPTION>Monograph
             <OPTION>Serial
             <OPTION>Component Part
             <OPTION>Multivolume
             <OPTION>Made-up Collection
            </SELECT><BR></TD><TR>
          <INPUT NAME="location1" TYPE=HIDDEN VALUE='PCCE LIB'>

         <TD> <b>Date Of Entry * :</b> </TD><TD>
          <SELECT NAME="date_of_entry_mm1" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>             
          <SELECT NAME="date_of_entry_dd1" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="date_of_entry_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR></TD></TR><TR><TD>
          <b>Language * :</b> </TD><TD>
<?php
        $database=pg_pconnect("dbname=lms user=pro password=pro");
        $result=pg_Exec($database,"SELECT language_desc from language_code");
        echo("<SELECT NAME=language_code1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
		if($result1=='English'){
			echo("<OPTION SELECTED>$result1");
		} else{
                echo("<OPTION> $result1");
		}
        }
        echo("</SELECT>");
?><BR></TD></TR><TR><TD>


        <INPUT TYPE=HIDDEN NAME="script1" VALUE='Roman'>
	
	<INPUT TYPE=HIDDEN NAME="translation_code1" VALUE='English'>
	
           <b>Physical Medium * :</b></TD><TD>    
              <UL> 
                <LI><INPUT TYPE="checkbox" NAME="paper1" VALUE="paper" CHECKED> Paper 
                <LI><INPUT TYPE="checkbox" NAME="magnetic1" VALUE="magnetic"> Magnetic 
                <LI><INPUT TYPE="checkbox" NAME="film1" VALUE="film"> Film 
                <LI><INPUT TYPE="checkbox" NAME="laser1" VALUE="laser"> Laser/Optical 
                <LI><INPUT TYPE="checkbox" NAME="braille1" VALUE="braille"> Braille 
                <LI><INPUT TYPE="checkbox" NAME="other1" VALUE="other"> Other
              </UL> </TD></TR><TR><TD>
            <b>Type Of Material * :</b></TD><TD>
               <SELECT NAME="type_of_material_desc1">
                <OPTION>textual
                <OPTION>report/technical report
                <OPTION>thesis/dissertation
                <OPTION>meeting document 
                <OPTION>periodical
                <OPTION>newspaper
                <OPTION>annual
                <OPTION>patent document
                <OPTION>standard
                <OPTION>irregual serial
                <OPTION>monograhic series
                <OPTION>other textual materials
                <OPTION>non-textual materials
               </SELECT><BR></TD></TR><TR><TD><TD><BR>
            <b><u>Title Of The Book</u></b></TD></TD></TR><TR><TD><BR>

            <b>Title * :</b></TD><TD>
                <INPUT NAME="title_bk1" TYPE="text" SIZE="50"><BR></TD></TR><TR><TD>
              Statement Of Responsibility  :</TD><TD>
                <INPUT NAME="statt_of_resp_ti_bk1" TYPE="text" SIZE="50"><BR></TD></TR><TR><TD><TD>

            <INPUT TYPE=HIDDEN NAME=language_code_title_bk1 VALUE='English'>
                
            <INPUT TYPE=HIDDEN NAME=script_title_bk1 VALUE='Roman'>

             <BR><b><u>NAME OF PERSON (Author,Illustrator,..).. </u></b></TD></TD></TR><TR><TD>
               <BR>
             <b>Surname(s) of Person(s)  * :</b></TD><TD>
                 <INPUT NAME=entry_element1 TYPE=text SIZE="50" ><BR></TD></TR><TR><TD>
                First Name(s) of Person(s) :</TD><TD>
                 <INPUT NAME=secondary_element1 TYPE=text SIZE="50" ><BR></TD></TR><TR><TD>
                Last Name(s) of Person(s) :   </TD><TD>
                 <INPUT NAME=additional_element1 TYPE=text SIZE="50" ><BR></TD></TR><TR><TD>
     
             <INPUT TYPE=HIDDEN NAME="date_mm1" VALUE='10'>
             <INPUT TYPE=HIDDEN NAME="date_dd1" VALUE='10'>
             <INPUT TYPE=HIDDEN NAME="date_yy1" VALUE='1010'>

             <b>Role * :</b></TD><TD>
	     <INPUT TYPE=TEXT NAME=role_type1 VALUE='Author'></TD></TR><TR><TD>

             <INPUT TYPE=HIDDEN NAME="date_of_publication_mm1" VALUE='10'>
             <INPUT TYPE=HIDDEN NAME="date_of_publication_dd1" VALUE='10'>


            <b>Year Of Publication * :</b></TD><TD>
	    <INPUT NAME="date_of_publication_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR>                  </TD></TR><TR><TD>

            <b>Subject Descriptor * :</b></TD><TD>
                  <INPUT NAME="subject_desc1" TYPE="text" SIZE="10">
                  <INPUT NAME="subject_desc2" TYPE="text" SIZE="10"><BR></TD></TR><TR><TD>

             <b>Accession No. * :</b></TD><TD>
                  <INPUT NAME="acc_no1" TYPE="text" SIZE="50"><BR><BR> </TD></TR><TR><TD>
	      
  	<HR>
           <b>Accession No. Of Reference Book  :</b></TD><TD>
                  <INPUT NAME="reference" TYPE="text" SIZE="50"><BR></TD></TR><TR><TD>
             <b>Accession No. Of Study Room Book  :</b></TD><TD>
                  <INPUT NAME="study" TYPE="text" SIZE="50"></TD></TR><TR><TD>  <TD><BR> <b><u>ISBN Of The Book</u></b>
              </TD></TD></TR><TR>  <TD><BR>

                ISBN :</TD><TD>
               <INPUT NAME="isbn1" TYPE="text" SIZE="20" ></TD></TR><TR><TD>

               <TD><BR><b><u>Corporate Body..</u></b></TD></TD></TR><TR><TD><BR>
        
	             
	       Name Of Corporate Body :</TD><TD>
               <INPUT NAME="name_of_corporate_body1" TYPE="text" SIZE="50" >
               </TD><TD>
<?php
$emacs="NULL##NULL##NULL";
        $result=pg_Exec($database,"SELECT name_of_corporate_body from name_of_corporate_body");

   echo("<SELECT NAME=name_of_corporate_body2>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
        for($j=($i+1); $j<pg_NumRows($result);$j++) {
                $result2=pg_Result($result,$j,0);
         if($result1 == $result2)
{
               $pp=0;
          break;
}


}

if($pp > 0)
{
echo( "<option> $result1");

}
$pp = 1;
 }
echo("</SELECT>");


?> </TD></TR>      


<TR><TD>

<TD><b><u>Other Title..</u></b></TD></TD></TR><TR><TD> 

        <INPUT NAME="document_no1" TYPE="HIDDEN" VALUE='00000' > 
 
        Other Title :</TD><TD>
        <INPUT NAME="other_title1" TYPE="text" SIZE="50" ><BR></TD></TR><TR><TD>

             
               Type Of Title :</TD><TD>
                <INPUT NAME="type_of_title1" TYPE="text" SIZE="50" >
               </TD><TD>
	       <SELECT NAME="type_of_title2">
	         <OPTION>NULL
	         <OPTION>Sub Title
                 <OPTION>Spine Title
                 <OPTION>Cover Title
                 <OPTION>Added Title 
                 <OPTION>Running Title
                 <OPTION>Other Title/Unknown Title
               </SELECT>
               </TD></TR>
               <TR><TD>

            
           <INPUT NAME="language_code_other_title1" TYPE="HIDDEN" VALUE="English">

               Edition Statement :</TD><TD>
                <INPUT TYPE=TEXT  NAME="forms_of_statt1" size="50"></TD></TR><BR><TR><TD><TD>
                  
               <b><u> PLACE AND NAME OF PUBLISHER :</u></b></TD></TD></TR>
                  
<TR><TD>
                Name :</TD><TD>
                  <INPUT NAME="publisher_name1" TYPE="text" SIZE="50" > 
</TD><TD><?php
        $result=pg_Exec($database,"SELECT * from place_and_publisher order by publisher_name");
//        $result=pg_Exec($database,"SELECT publisher_name from place_and_publisher order by publisher_name");


//   echo("<SELECT NAME=publisher_name2>");

?></TD></TR>      
<TR><TD>
                Place :</TD><TD>
                  <INPUT NAME="place_of_publisher1" TYPE="text" SIZE="50" >
</TD><TD><?php
//        $result=pg_Exec($database,"SELECT place from place_and_publisher");
//        echo("<SELECT NAME=place_of_publisher2>");
//   echo("<SELECT NAME=place_of_publisher2>");
//        for($i=0; $i<pg_NumRows($result);$i++) {
//                $result1=pg_Result($result,$i,0);
//        for($j=($i+1); $j<pg_NumRows($result);$j++) {
//                $result2=pg_Result($result,$j,0);
//         if($result1 == $result2)
//{
//               $pp=0;
//          break;
//}


//}
//
//if($pp > 0)
//{
//echo( "<option> $result1");

//}
//$pp = 1;
// }

//echo("</SELECT>");

?></TD></TR>      

<TR><TD>
          Address :</TD><TD>
            <INPUT NAME="address_of_publisher1" TYPE="text" SIZE="50" >
</TD><TD><?php
//        $result=pg_Exec($database,"SELECT address from place_and_publisher");
//        echo("<SELECT NAME=address_of_publisher2>");
//   echo("<SELECT NAME=address_of_publisher2>");
//        for($i=0; $i<pg_NumRows($result);$i++) {
//               $result1=pg_Result($result,$i,0);
//        for($j=($i+1); $j<pg_NumRows($result);$j++) {
//                $result2=pg_Result($result,$j,0);
//         if($result1 == $result2)
//{
//               $pp=0;
//          break;
//}


//}

//if($pp > 0)
//{
//echo( "<option> $result1");

//}
//$pp = 1;
// }

//echo("</SELECT>");

?> </TD></TR>      

<TR><TD>
                Country :</TD><TD>
                  <INPUT NAME="country_of_publisher1" TYPE="text" SIZE="50">
</TD><TD><?php
//        $result=pg_Exec($database,"SELECT country_desc from country");
//        echo("<SELECT NAME=country_of_publisher2>");

//        for($i=0; $i<pg_NumRows($result);$i++) {
//                $result1=pg_Result($result,$i,0);
//        for($j=($i+1); $j<pg_NumRows($result);$j++) {
//                $result2=pg_Result($result,$j,0);
//         if($result1 == $result2)
//{
//               $pp=0;
//          break;
//}


//}

//if($pp > 0)
//{
//echo( "<option> $result1");

//}
//$pp = 1;
 //}

//echo("</SELECT>");
echo("</TD></TR><TR><TD>Publisher Details :</TD><TD>");
 echo("<SELECT NAME=publisher_details>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
		$result3=pg_Result($result,$i,1);
		$result5=pg_Result($result,$i,2);
		$result7=pg_Result($result,$i,3);
		$fin_res=$result3.'## '.$result5.'## '.$result7;
        for($j=($i+1); $j<pg_NumRows($result);$j++) {
                $result2=pg_Result($result,$j,0);
                $result4=pg_Result($result,$j,1);
                $result6=pg_Result($result,$j,2);
                $result8=pg_Result($result,$j,3);
		$fin_res1=$result4.'## '.$result6.'## '.$result8;
         if($fin_res1 == $fin_res)
{
               $pp=0;
          break;
}
}

if($pp > 0)
{
echo( "<option> $fin_res");

}
$pp = 1;
 }
echo("<option SELECTED>$emacs");
echo("</SELECT>");


?></TD></TR><BR>

               <TR><TD><TD><b><u> PLACE AND NAME OF DISTRIBUTOR :</u></b></TD></TD></TR>
                  
<TR><TD>
                Name :</TD><TD>
                  <INPUT NAME="name_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
//        $result=pg_Exec($database,"SELECT name_of_distributor from place_and_distribution");
//        echo("<SELECT NAME=name_of_distributor2>");

//        for($i=0; $i<pg_NumRows($result);$i++) {
//                $result1=pg_Result($result,$i,0);
//        for($j=($i+1); $j<pg_NumRows($result);$j++) {
//                $result2=pg_Result($result,$j,0);
//         if($result1 == $result2)
//{
//               $pp=0;
//          break;
//}


//}

//if($pp > 0)
//{
//echo( "<option> $result1");

//}
//$pp = 1;
// }

//echo("</SELECT>");

?></TD></TR> 

<TR><TD>
                Place :</TD><TD>
                  <INPUT NAME="place_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
//        $result=pg_Exec($database,"SELECT place_of_distributor from place_and_distribution");
//        echo("<SELECT NAME=place_of_distributor2>");
//        for($i=0; $i<pg_NumRows($result);$i++) {
//                $result1=pg_Result($result,$i,0);
//        for($j=($i+1); $j<pg_NumRows($result);$j++) {
//                $result2=pg_Result($result,$j,0);
//         if($result1 == $result2)
//{
//               $pp=0;
//          break;
//}
//}//if($pp > 0)
//{//echo( "<option> $result1");
//}//$pp = 1;
// }//echo("</SELECT>");

?> </TD></TR>      
 
<TR><TD>
                Address :</TD><TD>
                  <INPUT NAME="address_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
//        $result=pg_Exec($database,"SELECT address_of_distributor from place_and_distribution");
//        echo("<SELECT NAME=address_of_distributor2>");
//        for($i=0; $i<pg_NumRows($result);$i++) {
//                $result1=pg_Result($result,$i,0);
//        for($j=($i+1); $j<pg_NumRows($result);$j++) {
//                $result2=pg_Result($result,$j,0);
//         if($result1 == $result2)
//{
//               $pp=0;
//          break;
//}


//}

//if($pp > 0)
//{
//echo( "<option> $result1");

//}
//$pp = 1;
// }

//echo("</SELECT>");

?></TD></TR> 

<TR><TD>
                Country :</TD><TD>
                  <INPUT NAME="country_of_distributor1" TYPE="text" SIZE="50" >
</TD></TR><TR><TD>Distributor Details :</TD><TD>

<?php
//        $result=pg_Exec($database,"SELECT country_desc from country");
        $result=pg_Exec($database,"SELECT * from place_and_distribution");
        echo("<SELECT NAME=distributor_details>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                $result3=pg_Result($result,$i,1);
                $result5=pg_Result($result,$i,2);
                $result7=pg_Result($result,$i,3);
		$fin_res=$result5.'## '.$result3.'## '.$result7;
        for($j=($i+1); $j<pg_NumRows($result);$j++) {
                $result2=pg_Result($result,$j,0);
                $result4=pg_Result($result,$j,1);
                $result6=pg_Result($result,$j,2);
                $result8=pg_Result($result,$j,3);
		$fin_res1=$result6.'## '.$result4.'## '.$result8;
         if($fin_res1 == $fin_res)
{
               $pp=0;
          break;
}
}
if($pp > 0)
{
echo( "<option> $fin_res");
}
$pp = 1;
}
echo("<option SELECTED>$emacs");
echo("</SELECT>");
?> </TD></TR><TR><TD>

                 <INPUT TYPE=HIDDEN NAME="pagination_desc1" VALUE="Books">
<BR><TD><b><u>Description Of The Book..</u></b></TD></TD></TR><BR><TR><TD>
                Preliminary (Optional)</TD><TD>
                  <INPUT NAME="priliminary1" TYPE="text" SIZE="10">
	 </TD></TR><TR><TD>
                Textual :</TD><TD>
               <INPUT NAME="textual1" TYPE="text" SIZE="10" VALUE='0'> <BR> 
	</TD></TR><TR><TD>
        <INPUT NAME="illustration1" TYPE="HIDDEN" VALUE="PCCE" > <BR>
             <INPUT NAME="l1" TYPE="HIDDEN" VALUE="8" >
                   <INPUT NAME="d1" TYPE="HIDDEN" VALUE="8" >
                   <INPUT NAME="h1" TYPE="HIDDEN" VALUE="8" >
                Accompanying Material :</TD><TD>
                   <INPUT NAME="accomp_material1" TYPE="text" SIZE="50" > <BR>             </TD></TR><TR><TD><TD><BR>

               <b><u> INVOICE DETAILS :</u></b><BR></TD></TR><TR><TD>

                Order No.: </TD><TD>
                  <INPUT NAME="orderno" TYPE="text" SIZE="10" VALUE=0><BR> </TD></TR><TR><TD>

		Date of Order : </TD><TD>
          <SELECT NAME="o_no_mm1" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>             
          <SELECT NAME="o_no_dd1" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="o_no_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ><BR></TD></TR><TR><TD>		

                Invoice No. :</TD><TD>
                  <INPUT NAME="invoice_no1" TYPE="text" SIZE="10" VALUE=0><BR> </TD></TR><TR><TD>

                No. Of Copies :</TD><TD>
                  <INPUT NAME="copies" TYPE="text" SIZE="10" VALUE=0><BR> </TD></TR><TR><TD>

                 Price Per Book :</TD><TD>
                  <INPUT NAME="amt" TYPE="text" SIZE="10" VALUE=0><BR> </TD></TR><TR><TD>

                 </TD><TD>
                  <INPUT NAME="discount" TYPE="hidden" SIZE="10" VALUE=0><BR> </TD></TR><TR><TD><TD><BR>


                <b><u>DETAILS OF SERIES :</u></b></TD></TD></TR><BR><TR><TD>
                ISSN :</TD><TD>
                  <INPUT NAME="issn1" TYPE="text" SIZE="50"><BR> </TD></TR><TR><TD>
                Series Name :</TD><TD>
                  <INPUT NAME="series_name1" TYPE="text" SIZE="50"><BR> </TD></TR><TR><TD>
                Statement Of Responsibility :</TD><TD>
               <INPUT NAME="statt_of_resp_sr_stt1" TYPE="text" SIZE="50"><BR> </TD></TR><TR><TD>  
               <TD><BR><b><u> PART STATT :</u></b></TD></TD></TR><BR><TR><TD>
                Title Of Vol/Part :  </TD><TD>
                  <INPUT NAME="part_statt1" TYPE="text" SIZE="50"><BR> </TD></TR><TR><TD>
                Vol/Part No.:</TD><TD>
                  <INPUT NAME="volume_or_part_no1" TYPE="text" SIZE="10"><BR> </TD></TR><TR><TD><BR>
                Note <i>(Enter Keywords)</i>:</TD><TD>
                  <INPUT NAME="note1" TYPE="text" SIZE="50"><BR>                    </TD></TR><TR><TD></TABLE>
<?php        
              echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");
      
 ?>

		  <HR><DIV ALIGN=RIGHT>
		      <H4>"*" indiactes compulsory fields</H4>
		  </DIV><HR> 
		  <DIV ALIGN=CENTER>
                    <INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>
  

                  </FORM> <BR>
 		  <FORM ACTION=book.php> 
  
<?php	     
              echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");
         

 ?>

		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  <TABLE ALIGN=CENTER WIDTH='100%'><TR><TD>
		  <A HREF=acqclerkentry.php>Goto Home Page</A></TD><TD>
		  </TD><TD> &nbsp<DIV ALIGN=RIGHT>
		  <A HREF=logout.php ALIGN=RIGHT>Logout</A></DIV>
		  </TD></TR></TABLE>
		  </FORM>
      </BODY>
</HTML> 
                 





