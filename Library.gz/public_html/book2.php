<HTML>
         <HEAD><TITLE>Making entry for Books.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	<HR>
         <FORM ACTION=book1update.php METHOD=POST>
         <TABLE ALIGN=CENTER WIDTH="90%">
         <TD><b>Bibliographic Level * :</b></TD><TD>
	 <SELECT NAME=bibliographic_level_desc1>
<?php	
	include "array.php";
	$res=pg_exec($database,"SELECT bibliographic_level_desc ".
	  	"FROM bibliographic_level");
	for($i=0;$i<pg_numrows($res);$i++){
		$ans=pg_result($res,$i,0);
		if($ans == $bibliographic_level_desc){
			echo ("<OPTION SELECTED>$ans");
		}
		else{
			echo ("<OPTION>$ans");
		}
	}	
?>
	</SELECT>
	<INPUT TYPE=HIDDEN NAME=record_id VALUE='<?echo $record_id?>'>
        <INPUT TYPE=HIDDEN NAME=bibliographic_level_desc VALUE='<? echo $bibliographic_level_desc ?>'>
	<BR></TD><TR>
          <INPUT NAME="location1" TYPE=HIDDEN VALUE='PCCE LIB'>
<?	  ereg("^(.+)-(.+)-(.+)$",$date_of_entry,$reg);	 ?>
          <TD> <b>Date Of Entry * :</b> </TD><TD>
	<INPUT TYPE=HIDDEN NAME=date_of_entry VALUE='<? echo $date_of_entry ?>'>
	<SELECT NAME="date_of_entry_mm1" >
<?	  while(list($key,$value) = each($month)){
		if($value == $reg[2]) { ?>
			<OPTION SELECTED><? echo $key; }
		else {	?> 
		<OPTION><? echo $key; }
		} ?> 
	  </SELECT>             
          <SELECT NAME="date_of_entry_dd1" >
<?	  	for($i=0;$i<count($date);$i++){ 
			if($date[$i]==$reg[3]){ ?>
				<OPTION SELECTED><? echo $date[$i]; }
			else{	?>
			<OPTION><? echo $date[$i]; 
			} } ?>
	  </SELECT>
	  <INPUT NAME="date_of_entry_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" VALUE=<?echo "$reg[1]"?>>
	  <BR></TD></TR><TR><TD>
          <b>Language * :</b> </TD><TD>
<?php
        $result=pg_Exec($database,"SELECT language_desc from language_code");
        echo("<SELECT NAME=language_code1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
		if($result1 == $language_desc_id AND $result1 != "null"){
			echo("<OPTION SELECTED>$result1");
		}
		else if($result1 == "null" && $result1==$language_desc_id) { ?>
			<OPTION SELECTED>English 
<?		} else{
        	        echo("<OPTION> $result1");
		}
	}
        echo("</SELECT>");
?>	
	<INPUT TYPE=HIDDEN NAME=language_desc_id VALUE='<? echo $language_desc_id ?>'>
	<BR></TD></TR><TR><TD>


        <INPUT TYPE=HIDDEN NAME="script1" VALUE='Roman'>
	
	<INPUT TYPE=HIDDEN NAME="translation_code1" VALUE='English'>
        <b>Physical Medium * :</b></TD><TD>
        <UL> 
         <LI>
<?	for($i=0;$i<count($physical_medium_desc);$i++){ 
	if($physical_medium_desc[$i]=="paper"){ ?>
	 <INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="paper" CHECKED> Paper 
<?	 } else { ?>
	 <INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="papar">Paper
<?	 } 
	 if($physical_medium_desc[$i]=="magnetic"){ ?>         
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="magnetic" CHECKED> Magnetic
<?	 } else { ?>
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="magnetic"> Magnetic
<?	 } 
	if($physical_medium_desc[$i]=="film"){ ?>
         <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="film" CHECKED> Film
<?	} else { ?>
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="film"> Film
<?	}
	if($physical_medium_desc[$i]=="laser"){ ?>
         <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="laser" CHECKED> Laser/Optical 
<?	} else { ?>
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="laser"> Laser/Optical
<?	}
	if($physical_medium_desc[$i]=="braille") { ?>
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="braille" CHECKED> Braille
<?	} else { ?>
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="braille"> Braille
<?	}
	if($physical_medium_desc[$i]=="other"){ ?>
	 <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="other" CHECKED> Other
<?	} else { ?>
         <LI><INPUT TYPE=checkbox NAME=physical_medium_desc1[] VALUE="other"> Other
<?      } // if ends here & next for **for** 
	}	?>
	</UL> </TD></TR><TR><TD>
	<? for($i=0;$i<count($physical_medium_desc);$i++){ ?>
	<INPUT TYPE=HIDDEN NAME=physical_medium_desc[] VALUE='<? echo $physical_medium_desc[$i] ?>'>
	<? } ?>
        <b>Type Of Material * :</b></TD><TD>
               <SELECT NAME="type_of_material_desc1">
<?		$result=pg_Exec($database,"SELECT type_of_material_desc ".
			"FROM type_of_material");
		for($i=0;$i<pg_numrows($result);$i++){
			$val=pg_result($result,$i,0);
			if($val != $type_of_material_desc){ ?>
			<OPTION><? echo $val; ?>
<?                 	} else { ?>
		 	<OPTION SELECTED><? echo $val; 
		} } ?>
	</SELECT><BR></TD></TR><TR><TD><TD><BR>
	<INPUT TYPE=HIDDEN NAME=type_of_material_desc VALUE='<? echo $type_of_material_desc ?>'>
        <b><u>Title Of The Book</u></b></TD></TD></TR><TR><TD><BR>

        <b>Title * :</b></TD><TD> 
        <INPUT NAME=title_bk1 TYPE=text SIZE=50 VALUE="<? echo $title_bk;?>">
	<INPUT TYPE=HIDDEN NAME=title_bk VALUE='<? echo $title_bk ?>'>
	<BR></TD></TR><TR><TD>
        Statement Of Responsibility  :</TD><TD>
           <INPUT NAME=statt_of_resp_ti_bk1 TYPE=text SIZE=50 VALUE="<? echo $statt_of_resp_ti_bk;?>">
	<INPUT TYPE=HIDDEN NAME=statt_of_resp_ti_bk VALUE='<? echo $statt_of_resp_ti_bk ?>'>
	<BR></TD></TR><TR><TD><TD>

        <INPUT TYPE=HIDDEN NAME=language_code_title_bk1 VALUE='English'>
               
        <INPUT TYPE=HIDDEN NAME=script_title_bk1 VALUE='Roman'>

        <BR><b><u>NAME OF PERSON (Author,Illustrator,..).. </u></b>
	</TD></TD></TR><TR><TD>
        <BR><b>Surname(s) of Person(s)  * :</b></TD><TD>
<?	for($i=0;$i<count($element);$i++) { 
		$sname.=$element[$i][0].'#';
		$fname.=$element[$i][1].'#';
		$aname.=$element[$i][2].'#';
		}
		$sname=substr($sname,0,strlen($sname)-1);
		$fname=substr($fname,0,strlen($fname)-1);
		$aname=substr($aname,0,strlen($aname)-1);
?>
        <INPUT NAME=entry_element1 TYPE=text SIZE=50 VALUE="<? echo $sname;?>">
        <BR></TD></TR><TR><TD>
	First Name(s) of Person(s) :</TD><TD>
<?	for($i=0;$i<count($element);$i++){
	for($j=0;$j<3;$j++){?>
	<INPUT TYPE=HIDDEN NAME=element[] VALUE='<? echo $element[$i][$j] ?>'>
<?	}  } ?>
	<INPUT NAME=secondary_element1 TYPE=text SIZE=50 VALUE="<? echo $fname;?>">
	<BR></TD></TR><TR><TD>
        Last Name(s) of Person(s) :   </TD><TD>
        <INPUT NAME=additional_element1 TYPE=text SIZE=50 VALUE="<? echo $aname;?>">
	<BR></TD></TR><TR><TD>
     
        <INPUT TYPE=HIDDEN NAME="date_mm1" VALUE='10'>
        <INPUT TYPE=HIDDEN NAME="date_dd1" VALUE='10'>
        <INPUT TYPE=HIDDEN NAME="date_yy1" VALUE='1010'>

        <b>Role * :</b></TD><TD>
<?	for($i=0;$i<count($role1);$i++){
	$result=pg_Exec("SELECT role_type FROM role ".
		"WHERE role1='$role1[$i]'");
	for($j=0;$j<pg_numrows($result);$j++){
		$mrolez =pg_result($result,$j,0);
		if($mrolez='NULL'){
			$mrolez='Author'; }
		$mrole .= $mrolez.'#';
	}
	}
	if($mrole==''){
		$mrole='Author'; }
	else { $mrole=substr($mrole,0,strlen($mrole)-1);
	}
	?>
        <INPUT TYPE=TEXT NAME=role_type1 VALUE='<? echo $mrole;?>'>
	<INPUT TYPE=HIDDEN NAME=mrole VALUE='<? echo $mrole ?>'>
	</TD></TR><TR><TD>

        <INPUT TYPE=HIDDEN NAME="date_of_publication_mm1" VALUE='10'>
        <INPUT TYPE=HIDDEN NAME="date_of_publication_dd1" VALUE='10'>


        <b>Year Of Publication * :</b></TD><TD>
<?	ereg("^(.+)-(.+)-(.+)$",$date_of_publication,$reg);?>
        <INPUT NAME=date_of_publication_yy1 TYPE=text SIZE=4 MAXLENGTH=4 VALUE="<? echo $reg[1];?>">
	<INPUT TYPE=HIDDEN NAME=date_of_publication VALUE='<? echo $date_of_publication ?>'>
	<BR></TD></TR><TR><TD>
<?	ereg("^([0-9\.]*)([A-Za-z0-9\/\.]*)",$subject_desc,$desc); ?>
        <b>Subject Descriptor * :</b></TD><TD>
	<INPUT TYPE=HIDDEN NAME=subject_desc VALUE='<? echo $subject_desc ?>'>
        <INPUT NAME=subject_desc1 TYPE=text SIZE=10 VALUE='<? echo $desc[1] ?>'>
        <INPUT NAME=subject_desc2 TYPE=text SIZE=10 VALUE='<? echo $desc[2] ?>'>
        <BR></TD></TR><TR><TD>

        <b>Accession No. * :</b></TD><TD>
<?	for($i=0;$i<count($acc_no);$i++){
		$macc_no.=$acc_no[$i].',';
	}
	$macc_no=substr($macc_no,0,strlen($macc_no)-1);
?>
        <INPUT NAME=acc_no1 TYPE=text SIZE=50 VALUE='<? echo $macc_no ?>'>
	<BR><BR> </TD></TR><TR><TD>
<?	for($i=0;$i<count($acc_no);$i++){ ?>
	<INPUT TYPE=HIDDEN NAME=acc_no[] VALUE='<? echo $acc_no[$i]?>'>	      
<?	} ?>	
  	<HR>
<?	for($i=0;$i<count($acc_no);$i++){
		$result=pg_exec($database,"SELECT * from reference_book ".
			"WHERE acc_no='$acc_no[$i]' AND ".
			"mem_still_exist_or_no='r'");
		if(pg_numrows($result)>0){
			$racc_no.=$acc_no[$i].',';
		}
		$result=pg_exec($database,"SELECT * from reference_book ".
			"WHERE acc_no='$acc_no[$i]' AND ".
			"mem_still_exist_or_no='s'");
		if(pg_numrows($result)>0){
			$sacc_no.=$acc_no[$i].',';
		}
	}
	$racc_no=substr($racc_no,0,strlen($racc_no)-1);
	$sacc_no=substr($sacc_no,0,strlen($sacc_no)-1);
?>
	<b>Accession No. Of Reference Book  :</b></TD><TD>
        <INPUT NAME=reference TYPE=text SIZE=50 VALUE='<? echo $racc_no;?>'>
	<BR></TD></TR><TR><TD>
        <b>Accession No. Of Study Room Book  :</b></TD><TD>
        <INPUT NAME=study TYPE=text SIZE=50 VALUE='<? echo $sacc_no; ?>'>
	</TD></TR><TR><TD>
	<INPUT TYPE=HIDDEN NAME=sacc_no VALUE='<?echo $sacc_no ?>'>
	<INPUT TYPE=HIDDEN NAME=racc_no VALUE='<? echo $racc_no ?>'>
	<BR> <b><u>ISBN Of The Book</u></b>
              </TD></TD></TR><TR>  <TD><BR>

                ISBN :</TD><TD>
<? 	if($isbn=='DEFAULT'){
		unset($isbn);
	} ?>
        <INPUT NAME=isbn1 TYPE=text SIZE=20 VALUE='<? echo $isbn; ?>'>
	<INPUT TYPE=HIDDEN NAME=isbn VALUE='<? echo $isbn ?>'>
	</TD></TR><TR>
        <TD><BR><b><u>Corporate Body..</u></b></TD>
	</TR><TR><TD><BR>
                    
	Name Of Corporate Body :</TD><TD>
<?	for($i=0;$i<count($name_of_corporate_body);$i++){
	if($name_of_corporate_body[$i]!="NULL"){
		$name_of_corp.=$name_of_corporate_body[$i]."#";
	}
	}
	$name_of_corp=substr($name_of_corp,0,strlen($name_of_corp)-1);
?>
        <INPUT NAME=name_of_corporate_body1 TYPE=text SIZE=50 VALUE='<? echo $name_of_corp; ?>'>
<?	for($i=0;$i<count($name_of_corporate_body);$i++){ ?>
	<INPUT TYPE=HIDDEN NAME=name_of_corporate_body[] VALUE='<? echo $name_of_corporate_body[$i] ?>'>
<?	} ?>
        </TD><TD>
<?php
        $result=pg_Exec($database,"SELECT name_of_corporate_body from name_of_corporate_body");

   echo("<SELECT NAME=name_of_corporate_body2>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
        	for($j=($i+1); $j<pg_NumRows($result);$j++) {
                	$result2=pg_Result($result,$j,0);
		        if($result1 == $result2)
			{
	               		$pp=0;
	         	        break;
			}	
		}
		if($pp > 0){
			echo("<OPTION>$result1");
		}
		$pp = 1;
 	}
	echo ("<OPTION SELECTED>NULL");
	echo("</SELECT>");
?> </TD></TR>      
	<TR><TD>
	<TD><b><u>Other Title..</u></b></TD></TD></TR><TR><TD> 
        <INPUT NAME="document_no1" TYPE="HIDDEN" VALUE='00000' > 
 
        Other Title :</TD><TD>
        <INPUT NAME=other_title1 TYPE=text SIZE=50 VALUE='<? echo $other_title;?>'>
	<INPUT TYPE=HIDDEN NAME=other_title VALUE='<? $other_title ?>'>
	<BR></TD></TR><TR><TD>
<?	if($t_o_t_desc == ''){
		$t_o_t_desc="Sub Title";
	} ?>
        Type Of Title :</TD><TD>
        <INPUT NAME=type_of_title1 TYPE=text SIZE=50 VALUE='<? echo $t_o_t_desc;?>'>
	<INPUT TYPE=HIDDEN NAME=t_o_t_desc VALUE='<? echo $t_o_t_desc ?>'>
        </TD><TD>
        <SELECT NAME="type_of_title2">
         <OPTION SELECTED>NULL
         <OPTION>Sub Title
         <OPTION>Spine Title
         <OPTION>Cover Title
         <OPTION>Added Title 
         <OPTION>Running Title
         <OPTION>Other Title/Unknown Title
        </SELECT>
        </TD></TR>
        <TR><TD>

            
        <INPUT NAME="language_code_other_title1" TYPE="HIDDEN" VALUE="English">

        Edition Statement :</TD><TD>
        <INPUT TYPE=TEXT  NAME=forms_of_statt1 size=50 VALUE='<? echo $forms_of_edition_statt_bk ;?>'>
	<INPUT TYPE=HIDDEN NAME=forms_of_edition_statt_bk VALUE='<?echo $forms_of_edition_statt_bk ?>'>
	</TD></TR><BR><TR><TD><TD>
                  
        <b><u> PLACE AND NAME OF PUBLISHER :</u></b></TD></TD></TR>          
	<TR><TD>
        Name :</TD><TD>
<? 	for($i=0;$i<count($publisher_name);$i++){
		$pub_name .= $publisher_name[$i].'#';
		}
	$pub_name=substr($pub_name,0,strlen($pub_name)-1);
?>
	<INPUT TYPE=HIDDEN NAME=pub_name VALUE='<? echo $pub_name ?>'>
        <INPUT NAME=publisher_name1 TYPE=text SIZE=50 VALUE='<? echo $pub_name?>'> 
	</TD><TD><?php
        $result=pg_Exec($database,"SELECT * from place_and_publisher order by publisher_name");

	?></TD></TR>      
	<TR><TD>
        Place :</TD><TD>
<?	for($i=0;$i<count($place_of_publisher);$i++){
		$place_of_pub .= $place_of_publisher[$i].'#';
		}
	$place_of_pub = substr($place_of_pub,0,strlen($place_of_pub)-1);
?>
	<INPUT NAME=place_of_publisher1 TYPE=text SIZE=50 VALUE='<? echo $place_of_pub?>'>
	<INPUT TYPE=HIDDEN NAME=place_of_pub VALUE='<? echo $place_of_pub ?>'>
	</TD><TD><?php

?></TD></TR>      

<TR><TD>
        Address :</TD><TD>
<?	for($i=0;$i<count($address_of_publisher);$i++){
		$addr_of_publ .= $address_of_publisher[$i].'#';
		}
	$addr_of_publ = substr($addr_of_publ,0,strlen($addr_of_publ)-1);
?>
	<INPUT NAME=address_of_publisher1 TYPE=text SIZE=50 VALUE='<? echo $addr_of_publ?>'>
	<INPUT NAME=addr_of_publ TYPE=hidden VALUE='<? echo $addr_of_publ ?>'>
</TD></TR>
<TR><TD>
        Country :</TD><TD>
<? 	for($i=0;$i<count($country_of_publisher);$i++){
		$country_of_publ .= $country_of_publisher[$i].'#';
		}
	if(ereg("^(.+)NU#(.+)$",$country_of_publ))
	{	unset($country_of_publ);
	}
	else
	{
	$country_of_publ=substr($country_of_publ,0,strlen($country_of_publ)-1);
	}
?>
	<INPUT NAME=country_of_publisher1 TYPE=text SIZE=50 VALUE='<? echo $country_of_publ; ?>'>
<input type=hidden name=country_of_publ value='<? echo $country_of_publ?>'>
</TD><TD>
	</TD></TR><TR><TD>Publisher Details :</TD><TD>
	<SELECT NAME=publisher_details>
<?        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
		$result3=pg_Result($result,$i,1);
		$result5=pg_Result($result,$i,2);
		$result7=pg_Result($result,$i,3);
		$fin_res=$result3.'## '.$result5.'## '.$result7;
        for($j=($i+1); $j<pg_NumRows($result);$j++) {
                $result2=pg_Result($result,$j,0);
                $result4=pg_Result($result,$j,1);
                $result6=pg_Result($result,$j,2);
                $result8=pg_Result($result,$j,3);
		$fin_res1=$result4.'## '.$result6.'## '.$result8;
         if($fin_res1 == $fin_res)
{
               $pp=0;
          break;
}
}
if($pp > 0)
{
echo( "<option> $fin_res");

}
$pp = 1;
 }
$emacs='NULL##NULL##NULL';
echo("<option SELECTED>$emacs");
echo("</SELECT>");


?></TD></TR><BR>

               <TR><TD><TD><b><u> PLACE AND NAME OF DISTRIBUTOR :</u></b></TD></TD></TR>
                  
<TR><TD>
	Name :</TD><TD>
<?	for($i=0;$i<count($name_of_distributor);$i++){
	$distributor_name .= $name_of_distributor[$i].'#';
	}
	$distributor_name=substr($distributor_name,0,strlen($distributor_name)-1);
?>
	<INPUT NAME=name_of_distributor1 TYPE=text SIZE=50 VALUE='<? echo $distributor_name?>'>
	<input name=distributor_name type=hidden value='<? echo $distributor_name ?>'>
</TD></TR>
	<TR><TD>Place :</TD><TD>
<?	for($i=0;$i<count($place_of_distributor);$i++){
		$distri_place .= $place_of_distributor[$i].'#';
	}
	$distri_place=substr($distri_place,0,strlen($distri_place)-1);
?>
        <INPUT NAME=place_of_distributor1 TYPE=text SIZE=50 VALUE='<? echo $distri_place ?>'>
	<input type=hidden name=distri_place value='<? echo $distri_place ?>'>
</TD></TR><TR><TD>
        Address :</TD><TD>
<?	for($i=0;$i<count($address_of_distributor);$i++){
		$distri_addr .= $address_of_distributor[$i].'#';
	}
	$distri_addr=substr($distri_addr,0,strlen($publisher_addr)-1);
?>
        <INPUT NAME=address_of_distributor1 TYPE=text SIZE=50 VALUE='<? echo $distri_addr ?>'>
	<input type=hidden name=distri_addr value='<? echo $distri_addr ?>'>
</TD></TR> <TR><TD>
        Country :</TD><TD>
<?	for($i=0;$i<count($country_of_distributor);$i++){
		$distri_country .= $country_of_distributor[$i].'#';
	}
	$distri_country=substr($distri_country,0,strlen($distri_country)-1);
?>
        <INPUT NAME=country_of_distributor1 TYPE=text SIZE=50 VALUE='<?  echo $distri_country ?>'>
	<INPUT TYPE=HIDDEN NAME=distri_country VALUE='<? echo $distri_country ?>'>
</TD></TR><TR><TD>Distributor Details :</TD><TD>

<?php
        $result=pg_Exec($database,"SELECT * from place_and_distribution");
        echo("<SELECT NAME=distributor_details>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                $result3=pg_Result($result,$i,1);
                $result5=pg_Result($result,$i,2);
                $result7=pg_Result($result,$i,3);
		$fin_res=$result5.'## '.$result3.'## '.$result7;
        for($j=($i+1); $j<pg_NumRows($result);$j++) {
                $result2=pg_Result($result,$j,0);
                $result4=pg_Result($result,$j,1);
                $result6=pg_Result($result,$j,2);
                $result8=pg_Result($result,$j,3);
		$fin_res1=$result6.'## '.$result4.'## '.$result8;
         if($fin_res1 == $fin_res)
{
               $pp=0;
          break;
}
}
if($pp > 0)
{
echo( "<option> $fin_res");
}
$pp = 1;
}
echo("<option SELECTED>$emacs");
echo("</SELECT>");
?> </TD></TR><TR><TD>

	<INPUT TYPE=HIDDEN NAME="pagination_desc1" VALUE="Books">
	<BR><TD>
	<b><u>Description Of The Book..</u></b>
	</TD></TD></TR><BR><TR><TD>
        Preliminary (Optional)</TD><TD>
        <INPUT NAME=priliminary1 TYPE=text SIZE=10 VALUE='<? echo $preliminary ?>'>
	<input type=hidden name=preliminary value='<? echo $preliminary ?>'>
	</TD></TR><TR><TD>
        Textual :</TD><TD>
        <INPUT NAME=textual1 TYPE=text SIZE=10 VALUE='<? echo $textual?>'> 
	<input type=hidden name=textual value='<? echo $textual ?>'>
	<BR> 
	</TD></TR><TR><TD>
        <INPUT NAME="illustration1" TYPE="HIDDEN" VALUE="PCCE" > <BR>
        <INPUT NAME="l1" TYPE="HIDDEN" VALUE="8" >
        <INPUT NAME="d1" TYPE="HIDDEN" VALUE="8" >
        <INPUT NAME="h1" TYPE="HIDDEN" VALUE="8" >
        Accompanying Material :</TD><TD>
        <INPUT NAME=accomp_material1 TYPE=text SIZE=50 VALUE='<? echo $accomp_material ?>'>
	<input type=hidden  name=accomp_material value='<? echo $accomp_material?>'>
	<BR></TD></TR><TR><TD><TD><BR>

        <b><u> INVOICE DETAILS :</u></b><BR></TD></TR><TR><TD>

        Invoice No. :</TD><TD>
<?	$result=pg_Exec($database,"SELECT invoice_no,no_of_copies,".
		"price_per_unit from book_details WHERE ".
		"record_id='$record_id'");
	for($i=0;$i<pg_numrows($result);$i++)
	{
		$invoice_no=pg_result($result,$i,0);
		$no_of_copies=pg_result($result,$i,1);
		$price_per_unit=pg_result($result,$i,2);
	}
?>
        <INPUT NAME=invoice_no1 TYPE=text SIZE=10 VALUE='<? echo $invoice_no?>'>
	<input type=hidden name=invoice_no value='<?echo $invoice_no ?>'>
	<BR></TD></TR><TR><TD>

        No. Of Copies :</TD><TD>
        <INPUT NAME=copies TYPE=text SIZE=10 VALUE='<? echo $no_of_copies?>'>
	<INPUT TYPE=hidden name=no_of_copies VALUE='<? echo $no_of_copies?>'>
	<BR> </TD></TR><TR><TD>

        Price Per Book :</TD><TD>
	<INPUT NAME="amt" TYPE="text" SIZE="10" VALUE='<? echo $price_per_unit?>'>
	<input type=hidden name=price_per_unit value='<? echo $price_per_unit ?>'>
	<BR> </TD></TR><TR><TD>

        </TD><TD>
        <INPUT NAME="discount" TYPE="hidden" SIZE="10" VALUE=0>
	<BR> </TD></TR><TR><TD><TD><BR>


        <b><u>DETAILS OF SERIES :</u></b></TD></TD></TR><BR><TR><TD>
        ISSN :</TD><TD>
        <INPUT NAME=issn1 TYPE=text SIZE=50 VALUE='<? echo $issn?>'>
	<input type=hidden name=issn value='<? echo $issn?>'>
	<BR></TD></TR><TR><TD>
        Series Name :</TD><TD>
        <INPUT NAME=series_name1 TYPE=text SIZE=50 VALUE='<? echo $series_name?>'>
	<input type=hidden name=series_name value='<? echo $series_name ?>'>
	<BR> </TD></TR><TR><TD>
        Statement Of Responsibility :</TD><TD>
        <INPUT NAME=statt_of_resp_sr_stt1 TYPE=text SIZE=50 VALUE='<? echo $statt_of_resp_sr_stt?>'>
	<input type=hidden name=statt_of_resp_sr_stt value='<? echo $statt_of_resp_sr_stt?>'>
	<BR> </TD></TR><TR><TD>  
        <TD><BR><b><u> PART STATT :</u></b></TD></TD></TR><BR><TR><TD>
        Title Of Vol/Part :  </TD><TD>
        <INPUT NAME=part_statt1 TYPE=text SIZE=50 VALUE='<? echo $part_statt?>'>
	<input type=hidden value='<? echo $part_statt ?>' name=part_statt>
	<BR> </TD></TR><TR><TD>
        Vol/Part No.:</TD><TD>
        <INPUT NAME=volume_or_part_no1 TYPE=text SIZE=10 VALUE='<? echo $volume_or_part_no?>'>
	<input type=hidden value='<? echo $volume_or_part_no ?>' name=volume_or_part_no>
	<BR> </TD></TR><TR><TD><BR>
        Note <i>(Enter Keywords)</i>:</TD><TD>
        <INPUT NAME=note1 TYPE=text SIZE=50 VALUE='<? echo $note?>'>
	<input type=hidden name=note value='<? echo $note?>'>
	<BR></TD></TR><TR><TD></TABLE>
<?php        
              echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");
      
 ?>

		  <HR><H5 ALIGN=RIGHT>"*" indiactes compulsory fields</H5>
		  <HR> 
		  <DIV ALIGN=CENTER>
                    <INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>
  

                  </FORM> <BR>
 		  <FORM ACTION=updatebooks.php> 
		  
  
<?php	     
              echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");
         

 ?>

		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV><BR><HR><BR>
		  <TABLE ALIGN=CENTER WIDTH='100%'><TR><TD>
		  <A HREF=acqclerkentry.php><BIG>Goto Home Page<BIG>
		  </A></TD><TD>
		 <DIV ALIGN=LEFT>
		 <A HREF=updatebooks.php><BIG>Wrong Entry</BIG></A>
		 </DIV>
		 </TD><TD> &nbsp<DIV ALIGN=RIGHT>
		  <A HREF=logout.php ALIGN=RIGHT><BIG>Logout<BIG></A></DIV>
		  </TD></TR></TABLE>
		  </FORM>
      </BODY>
</HTML> 
                 





