<HTML>
<HEAD><TITLE>This is the starting page</TITLE>
<SCRIPT LANGUAGE="JavaScript">
<!-- check for name field
     function checkform( thisform){
     	     if (thisform.institute,value==null || thisform.institute.value==""){
		 alert("Please Enter The Name Of Institute");
		 thisform.institute.focus();
		 thisform.institute.select();
		 return false;
	     }
	     if (thisform.fname.value==null || thisform.fname.value==""){
                 alert("Please enter name");
                 thisform.fname.focus();
                 thisform.fname.select();
                 return false;
             }
             if (thisform.passwd.value==null || thisform.passwd.value==""){
                 alert("Please enter password");
                 thisform.passwd.focus();
                 thisform.passwd.select();
                 return false;
             }
             if (thisform.vpasswd.value==null || thisform.vpasswd.value==""){
                 alert("Please verify the password");
                 thisform.vpasswd.focus();
                 thisform.vpasswd.select();
                 return false;
             }
             return true
     }
//the end of function -->
</SCRIPT></HEAD>

<BODY bgcolor="#8AFF90" text="#316431">
    <BR><BR><HR>
<p><H2 ALIGn=CENTER>Please Read This Before going Ahead</h2></p>
<BIG><FONT color=WHITE><p>&nbsp&nbsp&nbsp&nbsp&nbsp
	This Program was designed to automate the function of a Library.<BR>
	Copyright (C) 2001 : &nbsp&nbsp&nbsp&nbsp
	<FONT COLOR=BLUE><UL><LI>  Hiren Lodhiya <BR>
	<li>   Gaurav Priyolkar<BR>
	<li>   Sharmad Naik </UL></FONT><BR>
	This Program is free software;you can redistribute it and/or modify
	it under the terms of GNU General Public License as published by Free 
	Software Foundation;either version 2 or any later version version.
	<BR><BR>
	This Program is distributed in the hope that it will be useful, but 
	WITHOUT ANY WARRANTY;even without the implied warranty of MERCHAN-
	TABILITY or FITNESS FOR A PARTICULAR PURPOSE.See GNU General Public 
	License for more details.
	<BR><BR>
	You should have recieved a copy of GNU General Public License along 
	with this program;if not , write to Free Software Foundation,Inc.,
	675 Mass Ave,Cambridge,MA 02139,USA.
	<BR><BR><TABLE><TR><TD>
	Any furthur queries may be forwarded at <b>glibs-people@lists.sourceforge.net</b></TD></TR></TABLE>
	<BR><BR>
</p></FONT></BIG><HR>
	<H2 ALIGN=CENTER>
	<FONT COLOR=RED>If You Do Wish To Go Furthur</FONT></H2>
<HR>
	<FORM METHOD=POST  ACTION=index.php onSubmit="return checkform( this)">
	<H1 ALIGN=CENTER>Administrator Information</H1>
	<HR><BR>
	<TABLE width="70%" ALIGN=CENTER><TR><TD>
	<b>Name Of Institute</b></TD><TD>
	<INPUT TYPE=text name=institute></TD></TR><TR><TD>
	<b>First name :</b></TD><TD>
	<INPUT TYPE=TEXT NAME=fname ></TD></TR><TR><TD>
	<b>Last name :</b></TD><TD>
	<INPUT TYPE=TEXT NAME=lname ></TD></TR><TR><TD>
	<b>Password :</b></TD><TD>
	<INPUT TYPE=PASSWORD NAME=passwd ></TD></TR><TR><TD>
	<b>Verify password :</b></TD><TD>
	<INPUT TYPE=PASSWORD NAME=vpasswd ></TD></TR><TR><TD>
	<b>Temporary address :</b></TD><TD>
	<INPUT TYPE=TEXT NAME=taddress ></TD></TR><TR><TD>
	<b>Permanent address :</b></TD><TD>
	<INPUT TYPE=TEXT NAME=paddress ></TD></TR><TR><TD>
	<b>Phone No.:</b></TD><TD>
	<INPUT TYPE=TEXT NAME=ph_no VALUE=0></TD></TR><TR><TD>
	<b>E - Mail :</b></TD><TD>
	<INPUT TYPE=TEXT NAME=email >
	</TD></TR></TABLE><BR><HR><BR>
	<DIV ALIGN=CENTER>
	<INPUT TYPE=SUBMIT VALUE=Submit NAME=Submit>
	<INPUT TYPE=RESET VALUE=Reset NAME=Reset><BR>
	</DIV>
	</FORM>

</BODY>
</HTML>

