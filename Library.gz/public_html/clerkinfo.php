<HTML>
<HEAD><TITLE>Member Updation Form</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316431">
<FORM ACTION=clerk_updated.php METHOD=POST>
<?php
	if($clerk_id){
        require("header.inc");
	echo("<BR><HR>");
	echo("<H2 ALIGN=CENTER><FONT COLOR=BROWN>");
	echo("Please Update The Following Information</FONT></H2>");
	$data=pg_connect("dbname=lms user=pro");
	$result=pg_Exec($data,"SELECT * FROM clerk where clerk='$clerk_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$surname=pg_Result($result,$i,2);
		$temporary_address=pg_Result($result,$i,4);
		$permenant_address=pg_Result($result,$i,5);
		$phone =pg_Result($result,$i,6);
		$email =pg_Result($result,$i,7);
	}
	echo("<BR><HR><BR>");
	echo("<TABLE ><TR><TD><H3>Welcome :</H3></TD><TD>"); 
	echo("<FONT COLOR=BLUE><u><B>$surname</B></u></FONT>");
	echo("</TD></TR></TABLE><BR>");
	echo("<H3 ALIGN=CENTER>Please Update The Following</H3>");
	echo("<TABLE WIDTH=65% ALIGN=CENTER><TR><TD>");
	echo("<B>Temporary Address</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=temporary_address VALUE='$temporary_address'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Permenant Address</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=permenant_address VALUE='$permenant_address'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Phone</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=phone VALUE='$phone'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>E - Mail</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=email VALUE='$email'>");
	echo("</TD></TR></TABLE>");	
	echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");
	echo("<DIV ALIGN=CENTER><BR><BR>");
	echo("<INPUT TYPE=SUBMIT NAME='Make Changes' VALUE='Make Changes'>");
	echo("</DIV>");
	echo("<BR><HR>");
	}
	else{
		header("Location:http://$HTTP_HOST/~pro/forbidden.html");
		exit();
	}
?>
</FORM>
</BODY>
</HTML>

