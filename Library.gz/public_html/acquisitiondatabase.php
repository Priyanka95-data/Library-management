<HTML>
         <HEAD><TITLE>Making entry for a Book.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
	require("header.inc");


$database = pg_connect("dbname=lms user=postgres");




        	$result = pg_Exec($database,
              "UPDATE book_details set title_bk_details='$title',isbn_bk_details='$isbn',author_bk_details='$author',edition_bk_details='$edition',publisher_bk_details='$publisher',no_of_copies='$copies' where title_bk_details='$titleb'");

    $j=$j+1;


        include("acquisitiondisplay.php");
?>
</body>
</html>