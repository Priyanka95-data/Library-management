<HTML>
<HEAD><TITLE>Book has been issued</TITLE></HEAD>  
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

  
    $reference='';
    $res = query("SELECT acc_no FROM ".
                 "reference_book WHERE acc_no='$acc_no'");
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            $reference= pg_Result($res,$i,0);
        }       
    if($reference == '')
        {
           $res = query("BEGIN WORK"); 
           $res = query("INSERT INTO in_or_out VALUES('$acc_no','$mem_id')");
           $entit = $entit - 1;
           $res = query("UPDATE mem_related_to_entitlement ".
                        "SET entitlement_withheld = '$entit' WHERE ".
                        "mem_entitl_id='$mem_entit_id'");

           $res = query("SELECT status.days_per_book FROM ".
                        "status,member WHERE member.mem_id='$mem_id' ".
                        "and status.status=member.status");
           for($i=0 ; $i<pg_NumRows($res);$i++)
               {
                   $days_per_book= pg_Result($res,$i,0);
               }          
           $res=query("SELECT ".
                      "(CURRENT_DATE+CAST('$days_per_book day' AS INTERVAL))");
           for($i=0 ; $i<pg_NumRows($res);$i++)
               {
                   $time= pg_Result($res,$i,0);
               }
           //see if something can be done here
           //postgresql error if same book issued same day
           //coz duplicate primary key
           $res = query("INSERT INTO mem_book VALUES ('$acc_no','$time',".
                        "'$mem_id','CURRENT_DATE',CAST('1010-10-10' AS DATE),".
                        "'$name','i',0)");

           //send email
           $res1=query("SELECT email FROM member WHERE ".
                       "mem_id='$mem_id' ");
           for($i=0;$i<pg_NumRows($res1);$i++){
               $to=pg_Result($res1,$i,0);
           }   

                $success=0;
                if($to)
                    {
                        $res2=query("SELECT email FROM clerk WHERE clerk='admin'");
                        $adminmail=pg_result($res2,0,"email");

                        $subj = LIBRARY . " - Issued book";

                        $header = "From: " . $adminmail;

                        $body = LIBRARY . " \r\n\r\nThis is to inform you that " . 
                             "the following book has been issued to you: \r\n " .
                             "\r\nAccession No.: " . $acc_no;
                        
                        $success = mail($to, $subj, $body, $header);
                    }
                echo("<H1 ALIGN=CENTER><u></u>Issue Sucessfull.</h1><BR><HR><BR>");
                if($success) {
                    echo("<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>");
		    echo("<H2 ALIGN=CENTER>Mail successfully sent to $mem_id</H2></TD><TD>");
		    echo("<IMG SRC=mail.gif></TD></TR></TABLE>");
                } else {
                    echo("<H2 ALIGN=CENTER>Mail could not be sent to $mem_id</H2><BR>");
		    echo("<IMG SRC=mail.gif></TD></TR></TABLE>");
                }
                //email sent

                echo("<H2 ALIGN=CENTER>Book with Accession No. $acc_no issued to $mem_id</H2>");
                $res = query("COMMIT WORK");

                
        } else {
            echo("<H2>Book with Accession No. $acc_no is a Reference Book and may not be issued</H2>");
        }

    echo("<FORM ACTION=issue.php><DIV ALIGN=CENTER><HR><BR>"); 
    echo("<INPUT TYPE=SUBMIT VALUE='Go Back' NAME='Go Back'></DIV><BR><HR>");
    echo("</FORM>");
    
}
?>
	
</BODY>
</HTML>


















