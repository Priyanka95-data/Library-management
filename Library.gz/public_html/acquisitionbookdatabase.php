<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">


	<HR>
	<BR>


	<?php
        	$database = pg_connect("dbname=lms user=postgres");

        	$result = pg_Exec($database,
        	"begin work;"); 


        	$result = pg_Exec($database,
              "UPDATE book_details set title_bk_details='$title',isbn_bk_details='$isbn',author_bk_details='$author',edition_bk_details='$edition',publisher_bk_details='$publisher',no_of_copies='$copies',price_per_unit='$price_per_book',total_price='$total',discount='$discount',net_price='$net',invoice_no='$invoiceno' where title_bk_details='$titleb'");

    $j=$j+1;


        	$result = pg_Exec($database,
        	"commit work;"); 


                echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt>");
       include("invoicedetails.php");
?>


       <FORM ACTION=acquisitiondisplay.php>   
<?php 
   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");
               echo("<INPUT NAME=book TYPE=HIDDEN VALUE='$book'><BR><BR>");
               echo("<INPUT TYPE=hidden VALUE='$orderno ' NAME=orderno >");
               echo("<INPUT NAME=j TYPE=HIDDEN VALUE='$j'><BR><BR>"); 
               echo("<INPUT NAME=l TYPE=HIDDEN VALUE='$l'><BR><BR>"); 
               echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk>");
               echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt>");
?>
             <DIV ALIGN=CENTER>
		 <INPUT NAME="Next" TYPE="submit" VALUE="Next">
		  </DIV>
		  </FORM>


         
</body>
</html>












