<HTML>
<HEAD><TITLE>This is the login jumper</TITLE></HEAD>
<BODY>

<?php 

include("header.inc");
include("common.php");

if(trim($name)=="" and trim($password)=="" ) {
    //    header("Location:http://$HTTP_HOST/~pro/error2.html");
    echo("SORRY ... NAME AND PASSWORD ARE EMPTY<BR>");
    exit();

}else { //authenticate user
    $password = md5($password);

    if (authenticate_user($membername, $password, 'Member')) {
        setcookie("membername", $membername,time()+60*60);
        setcookie("password", $password,time()+60*60);
        setcookie("option", 'Member',time()+60*60);
        //        setcookie("clerk_id", $clerk_id);
    } else {
        //login failed
        delete_cookies();
        header("Location: http://$HTTP_HOST/~pro/memauthfail.html");
    }
}


switch ($option) {
 case "Search and Reserve Books":
     header("Location: http://$HTTP_HOST/~pro/membersearch.php");
     break;

 case "Suggest Books":
     header("Location:http://$HTTP_HOST/~pro/suggestion.php");
     break;

 case "Update Profile":
     setcookie("name", $membername);
     echo("<INPUT TYPE=hidden NAME=nametochange VALUE='$membername'>");
     echo("<INPUT TYPE=hidden NAME=group VALUE='Member'>");
     header("Location:http://$HTTP_HOST/~pro/getprofile.php?nametochange=$membername&group=Member");
     //     header("Location:http://$HTTP_HOST/~pro/getprofile.php");
     break;
}

?>
</BODY>
</HTML>
