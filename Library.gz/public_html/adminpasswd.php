<HTML>
<HEAD><TITLE>Change passwords</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">
<?php

include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

	echo("<BR>");
	echo("<H1 ALIGN=CENTER>Change passwords</H1><BR><HR><BR>");

	echo("<FORM ACTION=passwordchange.php METHOD=POST>");
	echo("<TABLE width='40%' ALIGN=CENTER>");

	echo("<TR><TD>Change password for :</TD>");
	echo("<TD><SELECT NAME=group VALUE=group>");
    echo("<OPTION>Member</OPTION>");
    echo("<OPTION>Issue/Return Clerk</OPTION>");
    echo("<OPTION>Acquisition Clerk</OPTION>");
    echo("<OPTION>Member Clerk</OPTION>");
    echo("</SELECT></TD></TR><BR><BR><BR><BR><BR><BR>");

	echo("<TR><TD>Name :</TD>");
	echo("<TD><INPUT TYPE=TEXT NAME=nametochange></TD></TR>");

    echo("<TR><TD>Enter new password :</TD>");
	echo("<TD><INPUT TYPE=PASSWORD NAME=npasswd></TD></TR>");

    echo("<TR><TD>Verify new password :</TD>");
	echo("<TD><INPUT TYPE=PASSWORD NAME=vnpasswd></TD></TR>");

	echo("</TABLE>");
	echo("<BR><BR><HR><BR><BR>");

    
    echo("<DIV ALIGN=center>");
	echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit><BR><BR>");
	echo("<INPUT TYPE=RESET NAME=Reset VALUE=Reset>");	
    echo("</DIV>");
	echo("</FORM>");

    echo("<BR><HR><BR>");
    echo("<TABLE ALIGN=CENTER WIDTH='100%'><TR><TD>");
    echo("<A HREF=admin.php><b>Return to home page</b></A></TD><TD>");
    echo("<A HREF=logout.php><b>Logout</b></A></TD></TR></TABLE>");
}
else{
    echo("<BR><HR>");
    echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
    echo("<FORM ACTION=login.html>"); 
    echo("<DIV ALIGN=RIGHT>");
    echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
    echo("</DIV>");
    echo("</FORM>");
}


?>
</BODY>
</HTML>