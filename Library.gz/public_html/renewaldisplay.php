<HTML>
<HEAD><TITLE>Renew book</TITLE></HEAD>  
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

        require("memexist.php"); 
       
	$res = query("SELECT * FROM member ".
                  "WHERE mem_id='$mem_id'");		
	$using = pg_NumRows($res);
	if($mem_id && $using == 1)
	{
           echo("<DIV ALIGN=CENTER>");
           echo("<H1>Member's current holdings</H1>");
           echo("</DIV>");
           echo("<BR><HR><BR>");

           $res = query("SELECT in_or_out.acc_no,".
                        "common_to_books_and_thesis.title_bk, ".
                        "mem_book.date_of_return FROM ".
                        "common_to_books_and_thesis,common_to_three,rec_acc,".
                        "in_or_out, mem_book WHERE in_or_out.acc_no=rec_acc.acc_no ".
                        "and rec_acc.record_id=common_to_three.record_id and ".
                        "common_to_three.record_id=common_to_books_and_thesis.record_id ".
                        "and in_or_out.mem_id=member.mem_id and member.mem_id='$mem_id' " .
                        "AND (mem_book.status_mem_bk='i' OR mem_book.status_mem_bk='d') ".
                        "AND mem_book.acc_no=rec_acc.acc_no");
    
           echo("<BR><BR>");
           echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
           echo("<TR bgcolor='B0C4DE'>"); 
           echo("<TH>Sr.No</TH>");
           echo("<TH>Accession No.</TH>");
           echo("<TH>Title Of Book</TH>");
           echo("<TH>Due Date</TH>");

           for($i=0 ; $i<pg_NumRows($res);$i++)
               {
                   echo("<TR><TD ALIGN=CENTER><b>");
                   echo ($i+1);
                   echo("</b></TD>");
                   echo("<TD ALIGN=CENTER><b>");
                   echo (pg_Result($res,$i,0)); 
                   echo("</b></TD>");
                   echo("<TD ALIGN=CENTER><b>");
                   echo (pg_Result($res,$i,1));
                   echo("</b></TD>");
                   $due_date = pg_Result($res,$i,2);
                   $res1 = query("SELECT (CURRENT_DATE)");
                   $res2 = query("SELECT CAST('$due_date' AS DATE) ".
                                 "- CURRENT_DATE");
                   if((int)pg_Result($res2,0,0) >= 0) { //if due date has not passed
                       echo("<TD ALIGN=CENTER><b>");
                   } else { //book is overdue
                        echo("<TD ALIGN=CENTER bgcolor=\"#ff8888\"><b>");
                   }
                   echo (pg_Result($res,$i,2));
                   echo("</b></TD></TR>");
               } 
           echo("</TABLE>");
           
           echo("<BR><BR><BR><BR><BR><BR>");

           $res = query("SELECT ".
           "mem_related_to_entitlement.entitlement_withheld,".
           "mem_related_to_entitlement.fines,".
           "mem_related_to_entitlement.mem_entitl_id FROM ".
           "mem_related_to_entitlement,member WHERE ".
           "mem_related_to_entitlement.mem_entitl_id=member.mem_entitl_id ".
           "and member.mem_id='$mem_id'"); 

           echo("<TABLE width='45%' border='2' cellpadding='5' ALIGN=CENTER>");
           echo("<TR bgcolor='B0C4DE'>"); 
           echo("<TH>Entitlements available</TH>");
           echo("<TH>Pending fines</TH>");
           
           for($i=0 ; $i<pg_NumRows($res);$i++)
               {
                   echo("<TR><TD ALIGN=CENTER><b>");
                   echo (pg_Result($res,$i,0)); 
                   echo("</b></TD>");
                   echo("<TD ALIGN=CENTER><b>");
                   $entit= pg_Result($res,$i,0); 
                   $mem_entit_id= pg_Result($res,$i,2); 
                   echo (pg_Result($res,$i,1));
                   echo("</b></TD></TR>");
               }
           echo("</TABLE><BR><HR>");

           echo("<FORM ACTION=renewallast.php>");
           echo("<INPUT TYPE=hidden VALUE='$entit ' NAME=entit >"); 
           echo("<INPUT TYPE=hidden VALUE='$mem_entit_id ' NAME=mem_entit_id >"); 
           echo("<INPUT TYPE=hidden VALUE='$mem_id ' NAME=mem_id >"); 
           echo("<BR><BR><H2>Book to be renewed</H2>");
           echo("<BR><b> Accession No. : &nbsp&nbsp</b>");
           echo("<INPUT NAME=acc_no TYPE=text SIZE=15 MAXLENGTH = 15><BR>");
           echo("<BR><BR><INPUT NAME=back TYPE=submit VALUE=Enter>");
           echo("</FORM>");
           
           echo("<FORM ACTION=issue.php>"); 
           echo("<BR><INPUT TYPE=SUBMIT VALUE='Back' NAME='Back'>");
           echo("</FORM>");
    
	}
}
else{
    echo("<H2>Sorry You are not Allowed to Borrow Any Books.<H2>");
    echo("<H2>Please check the Member Identification Number.<H2>");
    echo("<FORM ACTION=renew.php>"); 
    
    echo("<INPUT TYPE=SUBMIT VALUE='Go Back' NAME='Go Back'>");
    echo("</FORM>");
}
?>

</BODY>
</HTML> 

  














