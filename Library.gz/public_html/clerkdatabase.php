<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>

	</DIV>

<?php
	$database=pg_connect("dbname=lms user=pro password=pro");
       	$result = pg_Exec($database,"begin work;"); 
        $pass=md5($passwd);
	$result = pg_Exec($database, 	
 	"insert into clerk values('$clerk_id','$pass','$surname',".
		"'$status','$temporary_address','$permanant_address',".
		"'$phone','$email','$date_of_registration')");

	if($picture_name){
		$result = pg_Exec($database,"INSERT INTO ".
        		"clerk_picture VALUES('$clerk_id','$picture_name')");
	}
        $result10 = pg_Exec($database,"commit work;"); 

echo("<H2 ALIGN=CENTER>Data has been sucessfully inserted into the database.</H2><BR>"); 
	echo("<DIV ALIGN=CENTER>");
	echo("<FORM ACTION=clerk.php>");
        echo("<INPUT TYPE=HIDDEN NAME=admin_id VALUE='$admin_id'>");
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
	echo("</FORM><HR></DIV><TABLE ALIGN=CENTER WIDTH='90%'><TR><TD>");
        echo("<A HREF=admin.php>Home</A></TD><TD><DIV ALIGN=CENTER>");
        echo("<A HREF=clerk.php>Add Another Clerk</A></DIV></TD><TD>");
        echo("<A HREF=logout.php>Logout</A></TD></TR></TABLE>");
?>
</BODY>
</HTML> 








