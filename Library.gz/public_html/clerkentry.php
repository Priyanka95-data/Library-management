<HTML>
<HEAD><TITLE> Issue/Return Clerk's Homepage</TITLE></HEAD>
<BODY BGCOLOR="#999999" TEXT="#000000">
<BR><HR><H1 ALIGN = CENTER>Issue/Return Clerk's Homepage</H1><BR><HR>


<?php
include("header.inc");
include("common.php");


if(authenticate_user($name, $password, $option)) {

?>

	<BR>
	<TABLE ALIGN=CENTER width='50%'>

    <TR><TD>
	<FORM ACTION=issue.php METHOD=POST> 
	<b>Issue Book:</b></TD><TD>
	<INPUT TYPE=SUBMIT NAME='   Issue Book  ' VALUE='Issue Book'>
	</TD></TR>
	</FORM>


    <TR><TD>
	<FORM ACTION=renew.php METHOD=POST> 
	<b>Renew Book:</b></TD><TD>
	<INPUT TYPE=SUBMIT NAME='   Renew Book  ' VALUE='   Renew Book  '>
	</TD></TR>
	</FORM>

    <TR><TD>
	<FORM ACTION=return.php METHOD=POST> 
	<b>Return Book:</b></TD><TD>
	<INPUT TYPE=SUBMIT NAME='Return Book' VALUE='Return Book'>
	</TD></TR><TR><TD>
	</FORM>

	<FORM ACTION=totalfine.php METHOD=POST> 
	<b>Accept Fines:</b></TD><TD>
	<INPUT TYPE=SUBMIT NAME='Accept Fines' VALUE='Accept Fines'>

	</TD></TR>
	</FORM><TR><TD>
    <FORM ACTION = getprofile.php METHOD=POST>
    <b>Update Profile</b></TD><TD>
    <?php echo("<INPUT TYPE=hidden NAME=nametochange VALUE='$name'>"); ?>
    <INPUT TYPE=hidden NAME=group VALUE='Issue/Return+Clerk'>
    <INPUT TYPE=SUBMIT NAME='Update Profile' VALUE='Update Profile'>
	</TD></TR></FORM>


</TABLE>


	<BR><HR><TABLE ALIGN=CENTER WIDTH='100%'><TR><TD>
	<A HREF=clerkentry.php><b>Goto Home Page</b></A></TD><TD>
	<A HREF=logout.php><b>Logout</b></A></TD></TR></TABLE>
	</DIV>


<?php
	}
	else{
	header("Location:http://$HTTP_HOST/~pro/error3.html");
	}
?>
</BODY>
</HTML>
	
