<?php

	$m=0;


   $query=pg_Exec($database,"SELECT ".
         "reservation_withheld from mem_related_to_entitlement where mem_entitl_id='$mem'");

   for($l=0;$l<pg_NumRows($query);$l++)
   {
       $reservation=pg_Result($query,$l,0);
       echo("Total Number Of Reservation Withheld : $reservation");     

    }



	    for($j=0;$j < $count1;$j++)
		{         
			if($reservation > 0){

                              if($a[$j] != 0){
                                $resp=pg_Exec($database,"INSERT ".
				"INTO reservation_book VALUES ".
				"('$mem_id','$a[$j]')");	
			$reservation=$reservation-1;
                         $a[$j]=0;
			}
			}
		}

	    $resp=pg_Exec($database,"UPDATE mem_related_to_entitlement ".
		"SET reservation_withheld='$reservation' WHERE ".
		"mem_entitl_id='$mem'");
	
			
	echo("<INPUT TYPE=HIDDEN VALUE='$mem_id' NAME=mem_id>"); 
	echo("<INPUT TYPE=HIDDEN VALUE='$mem' NAME=mem>"); 


    $reach=pg_Exec($database,"SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,count(rec_acc.record_id),rec_acc.record_id  from rec_acc,common_to_books_and_thesis where common_to_books_and_thesis.title_bk='$name' and common_to_books_and_thesis.record_id=rec_acc.record_id group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,rec_acc.record_id union SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,count(rec_acc.record_id),rec_acc.record_id  from rec_acc,common_to_books_and_thesis,common_to_three where common_to_three.parallel_title_id=parallel_title.parallel_title_id and parallel_title.parallel_title='$name' and common_to_books_and_thesis.record_id=rec_acc.record_id  group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,rec_acc.record_id union SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,count(rec_acc.record_id),rec_acc.record_id  from rec_acc,common_to_books_and_thesis,common_to_three where common_to_three.other_title=other_title.other_title_id and other_title.other_title='$name' and common_to_books_and_thesis.record_id=rec_acc.record_id  group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1,rec_acc.record_id ".
	   " LIMIT $count1,$offset");
if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 
        echo("<H3 ALIGN=CENTER>Books found matching search criteria<H3><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");
        echo("<TH>Reserve Book</TH>");

            for($i=0;$i<pg_NumRows($reach);$i++){
		    $title=pg_Result($reach,$i,0);
		    $rest=pg_Result($reach,$i,1);
		    $countz=pg_Result($reach,$i,2);
		    $record=pg_Result($reach,$i,3);
       $reach1=pg_Exec($database,
              "select primary_element,secondary_element,additional_element from name_of_person where person1='$rest'");
                 
 
                  $name5=" ";
            for($j=0;$j<pg_NumRows($reach1);$j++){
		    $name1=pg_Result($reach1,$j,0);
		    $name2=pg_Result($reach1,$j,1);
                    $name3=pg_Result($reach1,$j,2);

		    $name5 .= $name1;
                 
		        $name5 .=' ';
                	$name5 .=$name2;
	
		        $name5 .=' ';
                	$name5 .=$name3;
	

                    $name5 .=',';


}
     include("count.php");
		   echo("<TR><TD ALIGN=CENTER><b>");
           echo(++$m);
           echo("</b></TD>");
           echo("<TD ALIGN=CENTER><b>");
           echo $title; 
           echo("<b></TD>");
           echo("<TD ALIGN=CENTER><b>");
           echo $name5;
           echo("</b></TD>");
           echo("<TD ALIGN=CENTER><b>");
           echo $countz;
           echo("</b></TD>");
           //                  $left=$countz-$left;
           $left=0;
           
           echo("<TD ALIGN=CENTER><b>");
           if($left == 0 && $reservation!=0){
               echo("<input type=checkbox name='a[$i]' value='$record'>");
               
           }	
           echo("</TD></TR>");
           
           echo("</TABLE>");
            }
            
    }



?>


















