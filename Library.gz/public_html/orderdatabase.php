<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">


	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
	</DIV>

	<?php
        	$database = pg_connect("dbname=lms user=pro password=pro");

        	$result = pg_Exec($database,
        	"begin work;"); 


  $vendor = 0;


        	$result = pg_Exec($database,
                " SELECT vendor_id FROM vendor where vendor_name = '$name_of_vendor' and vendor_city = '$city' and vendor_ph_no = '$phone' ");

  for($i=0; $i<pg_NumRows($result);$i++) {
                $vendor=pg_Result($result,$i,0);
        
        }

         if($vendor == 0)
{

        	$result = pg_Exec($database,
              "INSERT INTO vendor VALUES (nextval('vendor_seq'),'$name_of_vendor','$city','$phone','$email','$priority')");

     	$result = pg_Exec($database,
                " SELECT vendor_id FROM vendor where vendor_name = '$name_of_vendor' and vendor_city = '$city' and vendor_ph_no = '$phone' ");

  for($i=0; $i<pg_NumRows($result);$i++) {
                $vendor=pg_Result($result,$i,0);
                
        }
}
      
  	$result = pg_Exec($database,
        "INSERT INTO map_book_details VALUES (nextval('book_details_seq'))");
    
      
  	$result = pg_Exec($database,
        "select currval('book_details_seq') from  map_book_details ");
    
        for($i=0; $i<pg_NumRows($result);$i++) {
                $book=pg_Result($result,$i,0);
                
        }
 
 	$result = pg_Exec($database,
        "INSERT INTO order_now VALUES ('$orderno','$vendor','$date_of_entry',currval('book_details_seq'),'$date_of_arival','$draft')");


        	$result = pg_Exec($database,
        	"commit work;"); 



      $temp=1;
 
//    include("orderbook.php");

?>
    
 <FORM ACTION=order.php> 
   <DIV ALIGN=CENTER>

<?php	$acq_clerk=$name;
	echo("<INPUT TYPE=hidden VALUE='$name' NAME=acq_clerk>");

 ?><BR>
<H1 ALIGN=CENTER>Order Entered Sucessfully</H1><BR> 
                       <INPUT NAME="Go Back" TYPE="submit" VALUE="Go Back">
                  </DIV>


  </FORM> <BR><HR>
<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
    <A HREF=acqclerkentry.php>Home Page</A></TD><TD>
    <DIV ALIGN=RIGHT>
    <A HREF=logout.php>Logout</A></DIV></TD></TR></TABLE>
</body>
</html>












