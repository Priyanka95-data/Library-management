<HTML>
  
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">


	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
	<H1>Remarks entered <H1>
	</DIV>

        <?php
if($acc_no && $remarks)
{

            echo("<FORM ACTION=remarksdatabase.php>");
 	    echo("<INPUT TYPE=hidden VALUE='$acc_no' NAME=acc_no >");
 	    echo("<INPUT TYPE=hidden VALUE='$remarks' NAME=remarks >");
   echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER><TR><TD>");
   echo("<b>Accession No. :</b>&nbsp $acc_no</TD><TD>");
   echo("<b>Remarks :</b>&nbsp $remarks</TD></TR>");
   echo("</TABLE>");           
	echo("<BR><BR><HR><BR>");
?>
	<DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>
<?
	echo ("<INPUT NAME=back TYPE=submit VALUE=Enter><BR>");
?>	
	</DIV>
<?
	echo("</FORM>");
	}
        else
        {
	echo("<DIV ALIGN=CENTER> <H1> Invalid data</H1></DIV>");
        }
 	echo("<FORM ACTION=remarks.php>");
?>
	<DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>
<?
	echo("<BR><INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'><BR>");
?>	
	</DIV>
<?


	echo("</FORM>");

        ?>
</BODY>
</HTML> 






















