<HTML>
<HEAD><TITLE>Please give the amount for converting book to reference here</TITLE></HEAD>
<BODY BGCOLOR="#18097F" TEXT="#F97235">
<FORM>
<?php
	include("header.inc");
	include("common.php");
if(authenticate_user($name,$password,$option)){

	echo("<H1 ALIGN = CENTER>Use This Page to Allocated Ticks for a Book</H1>");
	echo("<HR><BR><BR>");
        echo("<TABLE width='70%' ALIGN=CENTER>");
        echo("<TR><TD>");
       	echo("<b>The Count For book to be termed reserve :</b>");
        echo("</TD><TD> ");
	echo("<INPUT TYPE=TEXT NAME=ticks SIZE=6>");
        echo("</TD></TR>");
	echo("</TABLE><BR>");
	echo("<INPUT TYPE=HIDDEN VALUE='$admin_id' NAME=admin_id>");
	echo("<DIV ALIGN=CENTER>");
	echo("<INPUT TYPE=SUBMIT VALUE='Submit' NAME='Submit'>");
	echo("</DIV>");
	if($Submit){
        $database=pg_connect("dbname=lms user=pro password=pro");
	$result=pg_Exec($database,"DELETE FROM dynamic_reference;");
	$result=pg_Exec($database,"INSERT INTO dynamic_reference VALUES ('$ticks')");
	}
	}
	else{
	header("Location:http://$HTTP_HOST/~pro/error3.html");
	}

?>

</FORM><BR><HR>
<TABLE WIDTH=100% ALIGN=CENTER><TR><TD>
<A HREF=admin.php><b>Homepage</b></A></TD><TD>
<DIV ALIGN=RIGHT>
<A HREF=login.html><b>Logout</b></A></DIV></TD></TR></TABLE>

</BODY>
</HTML>







