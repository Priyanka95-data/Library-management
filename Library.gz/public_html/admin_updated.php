<HTML>
<HEAD><TITLE>The Administrator Database Has Been Updated</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316436">
<?php
	require("header.inc");
	if($admin_id){
	    	echo("<FORM ACTION=admin.php>");
		$data=pg_connect("dbname=lms user=pro");
		$database=pg_Exec($data,"UPDATE clerk SET ".
			"temporary_address='$temporary_address',".
			"permenant_address='$permenant_address',".
			"phone='$phone',email='$email' ".
			"WHERE clerk='$admin_id'");
		echo("<HR><H2 ALIGN=CENTER><u>$surname</u>,Your Information Has Been Updated </H2><BR>");
		echo("<H3 ALIGN=RIGHT><U>Thank You</U></H3>"); 
		echo("<DIV ALIGN=CENTER>");
		echo("<INPUT TYPE=HIDDEN NAME='clerk_id' VALUE='$admin_id'>");
		$clerk_id=$admin_id;
		echo("<INPUT TYPE=SUBMIT NAME='Home Page' VALUE='Home Page'>");
		echo("</DIV>");
		echo("</FORM><BR><HR>");
		echo("<DIV ALIGN=RIGHT>");
		echo("<A HREF=login.html><u>Logout</u></A>");
		echo("</DIV>");
	}
	else{
		header("Location:http://$HTTP_HOST/~pro/forbidden.html");
		exit();
	}
?>
</BODY>
</HTML>