<HTML>
         <HEAD><TITLE>Remarks Of Books.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
	include("header.inc");
	include("common.php"):
	if(authenticate_user($name,$password,$option){
?>

         <DIV ALIGN = CENTER> <H1>Enter Remarks </H1></DIV>
         <FORM ACTION=thesisremarksdisplay5.php METHOD=GET>
         <HR><DIV ALIGN=CENTER>
	 <H3>
         Enter Only One Record At The Time
         </H3></DIV>
	 <HR>
         <BR>
             <b>Accession No. * :</b>
                  <INPUT NAME="acc_no" TYPE="text" SIZE="50"><BR><BR> 
 <BR>
         <b>remarks * :</b>
            <INPUT NAME="remarks" TYPE="text" SIZE="65" MAXLENGTH = "15">


		  <DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>
                    <INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>
  


                  </FORM> <BR>
 		  <FORM ACTION=thesisremarks.php> 
  


		  <DIV ALIGN=CENTER>
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); ?>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>
<?php	}else {
	Header("Location:http://$HTTP_HOST/~pro/authfail.html");
	}
?>
      </BODY>
</HTML> 












