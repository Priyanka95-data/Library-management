<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    //        $database=pg_connect("dbname=lms user=postgres");      

    $res = query("SELECT mem_id,surname,first_name,temporary_address,phone,email,status FROM member WHERE mem_still_exist_or_no = 'y'");


    if(pg_numrows($res) == 0 ) {
        echo("<H1 ALIGN=CENTER>No members found<H1>");
    }else {
        echo("<H1 ALIGN=CENTER>Library Members<H1><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Member id</TH>");
        echo("<TH>Name</TH>");
        echo("<TH>Address</TH>");
        echo("<TH>Phone </TH>");
        echo("<TH>E-mail</TH>");
        echo("<TH>Status</TH>");
        echo("</TR>");        
        
        for($i=0; $i<pg_numrows($res);$i++) 
            {
                $r0=pg_result($res,$i,0);
                $r1=pg_result($res,$i,1);
                $r2=pg_result($res,$i,2);
                $r3=pg_result($res,$i,3);
                $r4=pg_result($res,$i,4);
                $r5=pg_result($res,$i,5);
                $r6=pg_result($res,$i,6);
                

                echo("<TR><TD ALIGN = CENTER> $r0 </TD>");
                echo("<TD ALIGN = CENTER> $r1 $r2 </TD>");
                echo("<TD ALIGN = CENTER> $r3 </TD>");
                echo("<TD ALIGN = CENTER> $r4 </TD>");
                echo("<TD ALIGN = CENTER> $r5 </TD>");
                echo("<TD ALIGN = CENTER> $r6 </TD></TR>");
                
                
            }
        echo("</TABLE>");
    } 
}
?>

</BODY>
</HTML>

