<HTML>
  
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
	<H1>Please Verify The Information. </H1>
	</DIV>

        <?php
         $temp=1;
         if($email != '')
        {
        $tel=$email;
        
        $t=$tel;
        $w=strlen($tel);
        $l=strcspn($tel,"@");        
        $a=strlen($t);
        $b=strcspn($t,".");        

        if($w == $l || $b == $a)
        {
        $temp=2;
      echo("<DIV ALIGN=CENTER> <H1> Wrong E-mail. </H1></DIV>");
	echo("\t");
        }
        }



  if( $orderno && ($name_of_vendor || $name_of_vendor1 != "DEFAULT") && ($city  || $city1 !="NULL") && $date_of_entry_mm && $date_of_entry_dd && $date_of_entry_yy && $date_of_arival_mm && $date_of_arival_dd && $date_of_arival_yy  && $temp == 1)
 { 
            echo("<FORM ACTION=orderdatabase.php>");

   $date_of_entry_mm .= "/";
        $date_of_entry_dd .= "/";
	$date_of_entry .=$date_of_entry_mm;
        $date_of_entry .=$date_of_entry_dd;
        $date_of_entry .=$date_of_entry_yy;

        $date_of_arival_mm .= "/";
        $date_of_arival_dd .= "/";
	$date_of_arival .=$date_of_arival_mm;
        $date_of_arival .=$date_of_arival_dd;
        $date_of_arival .=$date_of_arival_yy;

    echo("<INPUT TYPE=hidden VALUE='$date_of_entry' NAME=date_of_entry >");
    echo("<INPUT TYPE=hidden VALUE='$date_of_arival' NAME=date_of_arival >");
    echo("<INPUT TYPE=hidden VALUE='$admin_id' NAME=admin_id >");
    echo("<INPUT TYPE=hidden VALUE='$orderno' NAME=orderno >");


   echo("<TABLE width='70%' border='2' cellpadding='5' ALIGN=CENTER><TR><TD>");
   echo("<b>Order No. :</b></TD><TD><b>$orderno</b></TD></TR>");
   if($name_of_vendor)
{
   echo("<TR><TD><b>Name Of Vendor. :</b></TD><TD><b>$name_of_vendor</b></TD></TR>");
}
else
{ 
  echo("<TR><TD><b>Name Of Vendor. :</b></TD><TD><b> $name_of_vendor1</b></TD></TR>");
  $name_of_vendor=$name_of_vendor1;
}
    echo("<INPUT TYPE=hidden VALUE='$name_of_vendor' NAME=name_of_vendor >");
   if($city)
{
   echo("<TR><TD><b>City Of Vendor. :</b></TD><TD><b> $city</b></TD></TR>");
}
else
{ 
  echo("<TR><TD><b>City Of Vendor. :</b></TD><TD><b> $city1</b></TD></TR>");
  $city=$city1;
}
    echo("<INPUT TYPE=hidden VALUE='$city' NAME=city >");
   if($phone)
{
   echo("<TR><TD><b>Phone No. :</b></TD><TD><b> $phone</b></TD></TR>");
}
else
{ 
   echo("<TR><TD><b>Phone No. :</b></TD><TD><b> $phone1</b></TD></TR>");
   $phone=$phone1;
}
    echo("<INPUT TYPE=hidden VALUE='$phone' NAME=phone >");
   if($email)
{
   echo("<TR><TD><b>E-mail :</b></TD><TD><b> $email</b><td></TR>");
}
else
{ 
   echo("<TR><TD><b>E-mail :</b></TD><TD><b> $email</b><td></TR>");
    $email=$email1;
}
    echo("<INPUT TYPE=hidden VALUE='$email' NAME=email >");
   if($priority)
{
   echo("<TR><TD><b>Reliability :</b></TD><TD><b> $priority</b></TD></TR>");
}
else
{ 
   echo("<TR><TD><b>Reliability :</b></TD><TD><b> $priority</b></TD></TR>");
   $priority=$priority1;  
}
    echo("<INPUT TYPE=hidden VALUE='$priority' NAME=priority >");
   echo("<TR><TD><b>Order Date :</b></TD><TD><b>$date_of_entry</b></td></TR>");
   echo("<TR><TD><b>Estimated Arrival Date :</b></TD><TD><b>$date_of_arival</b></TD></TR>");
   echo("<TR><TD><b>Cheque No./Draft No. :</b></TD><TD><b>$draft</b></TD></TR>");

echo("<DIV ALIGN=CENTER>");
echo("<INPUT NAME=Enter TYPE=submit VALUE=Enter>");
echo("</DIV>");
echo("</FORM> <BR>");
  ?>
  <FORM ACTION=order.php> 
  
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk>");

 ?>

		  <DIV ALIGN=CENTER>

		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>
<?php
}
else
{
 
 echo("<H2> Invalid Data </H2>");
?>
  <FORM ACTION=order.php> 
  
<?php	echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk>");

 ?>

		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>
<?php
}
?>


</body>
</html>




