<HTML>
<HEAD><TITLE>Accept fines</TITLE></HEAD>  
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    require("memexist.php"); 

    echo("<DIV ALIGN=CENTER>");
    echo("<H2>Fine to be paid by $mem_id</H2>");
    echo("</DIV>");
    
    $res = query("SELECT ".
                 "mem_related_to_entitlement.fines,".
                 "mem_related_to_entitlement.mem_entitl_id FROM ".
                 "mem_related_to_entitlement,member WHERE ".
                 "mem_related_to_entitlement.mem_entitl_id=member.mem_entitl_id ".
                 "and member.mem_id='$mem_id'"); 
    
    echo("<BR><BR>");
    echo("<TABLE width='40%' border='2' cellpadding='5' ALIGN=CENTER>");
    echo("<TR bgcolor='B0C4DE'>"); 
    echo("<TH>Fine Amount</TH>");
    
    for($i=0 ; $i<pg_NumRows($res);$i++)
        {
            echo("<TR><TD ALIGN=CENTER><b>");
            $fine= pg_Result($res,$i,0); 
            echo($fine);
            echo("</b></TD></TR>");                    
            $mem_entit_id= pg_Result($res,$i,1); 
        }
    echo("</TABLE>");
    
    echo("<BR><BR><BR><BR><BR><HR>");
    
    if($fine > 0){
        echo("<FORM ACTION=totalfinelast.php>");
        echo("<INPUT TYPE=hidden VALUE='$fine ' NAME=fine >"); 
        echo("<INPUT TYPE=hidden VALUE='$mem_entit_id ' NAME=mem_entit_id >"); 
        echo("<INPUT TYPE=hidden VALUE='$mem_id ' NAME=mem_id >"); 
        echo("<BR><BR><H2>Fine paid</H2>");
        echo("<b> Receipt No. : &nbsp&nbsp</b>");
        echo("<INPUT NAME=receipt_no TYPE=text SIZE=15 MAXLENGTH = 15><BR>");
        echo("<BR><BR><INPUT NAME=back TYPE=submit VALUE=Enter>");
        echo("</FORM>");
        
        echo("<FORM ACTION=totalfine.php>"); 
        echo("<BR><INPUT TYPE=SUBMIT VALUE='Back' NAME='Back'>");
        echo("</FORM>");
    } else{
        echo("<H2>$mem_id does not have to pay any fine<H2>");
    }

} else{
    echo("<BR><HR>");
    echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
    echo("<DIV ALIGN=RIGHT>");
    echo("<A HREF=login.html><b>Logout</b></A>"); 
    echo("</DIV>");
}

?>

</BODY>
</HTML> 

  














