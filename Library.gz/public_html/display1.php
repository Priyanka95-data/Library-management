<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<BODY>

	<BR>
	<DIV  ALIGN = CENTER>

	<H1>Please verify the information. <H1>
	</DIV>


<?php
$temp=1;
if($email != '')
        {
            $tel=$email;
            
            $t=$tel;
            $w=strlen($tel);
            $l=strcspn($tel,"@");        
            $a=strlen($t);
            $b=strcspn($t,".");        
            
            if($w == $l || $b == $a) {
                $temp=2;
                echo("<DIV ALIGN=CENTER> <H1> Invalid E-mail. </H1></DIV>");
                echo("\t");
            }
        }
if($mem_id && $surname && $first_name && ($passwd == $verify) && $status && $date_of_registration_dd && $date_of_registration_mm && $date_of_registration_yy && $receipt_no && ($temp == 1))
{
    echo("<FORM ACTION=database.php>");

    $date_of_birth_mm .= "/";
    $date_of_birth_dd .= "/";
    $date_of_birth .=$date_of_birth_mm;
    $date_of_birth .=$date_of_birth_dd;
    $date_of_birth .=$date_of_birth_yy;
    if($date_of_birth == '//') {
        $date_of_birth = '10/10/1010';
    }
	echo("<DIV ALIGN=CENTER>");
	echo(
	"Member ID : $mem_id<BR>" .
	"Surname : $surname<BR>" .
 	"First Name : $first_name<BR>" .

	"Date Of Birth : $date_of_birth<BR>".
        "Status : $status<BR>" .
 	"Institution : $institution<BR>" .
 	"Course : $course<BR>" .
 	"Temporary Address : $temporary_address<BR>" .
 	"Permanent Address : $permanent_address<BR>" . 
 	"Phone No. : $phone<BR>" .
 	"E-mail : $email<BR>" .
 	"Date of Registration : $date_of_registration_mm/$date_of_registration_dd/$date_of_registration_yy<BR>" . 
 	"Date of Renewal : $date_of_renewal_mm/$date_of_renewal_dd/$date_of_renewal_yy<BR>" .
 	"Receipt No : $receipt_no<BR></DIV>" 
	);
      
    $date_of_registration_mm .= "/";
    $date_of_registration_dd .= "/";
    $date_of_registration .=$date_of_registration_mm;
    $date_of_registration .=$date_of_registration_dd;
    $date_of_registration .=$date_of_registration_yy;
    if($date_of_registration == '//') {
        $date_of_registration = '10/10/1010';
    }

    $date_of_renewal_mm .= "/";
    $date_of_renewal_dd .= "/";
    $date_of_renewal .=$date_of_renewal_mm;
    $date_of_renewal .=$date_of_renewal_dd;
    $date_of_renewal .=$date_of_renewal_yy;
    if($date_of_renewal == '//') {
        $date_of_renewal = '10/10/1010';
    }


    $file_dir = "picture";
	$file_url = "http://$HTTP_HOST";
	if (isset($fupload )){
        	if ($fupload_type == "image/jpg" ||$fupload_type == "image/jpeg")
                {
                    copy ($fupload, "$file_dir/$fupload_name") or die ("Couldn't copy");
                    $picture_name=$file_dir."/".$fupload_name;
                    echo("<INPUT TYPE=hidden VALUE='$picture_name ' NAME=picture_name>");
                }
	}
    echo("<INPUT TYPE=hidden VALUE='$mem_id' NAME=mem_id >");
    echo("<INPUT TYPE=hidden VALUE='$surname' NAME=surname >");
    echo("<INPUT TYPE=hidden VALUE='$first_name' NAME=first_name >");
    echo("<INPUT TYPE=hidden VALUE='$passwd' NAME=passwd >");
    echo("<INPUT TYPE=hidden VALUE='$date_of_birth' NAME=date_of_birth >");
    echo("<INPUT TYPE=hidden VALUE='$status' NAME=status >");
    echo("<INPUT TYPE=hidden VALUE='$institution' NAME=institution >");
    echo("<INPUT TYPE=hidden VALUE='$field' NAME=field >");
    echo("<INPUT TYPE=hidden VALUE='$temporary_address' NAME=temporary_address >");
    echo("<INPUT TYPE=hidden VALUE='$permanent_address' NAME=permanent_address >");
    echo("<INPUT TYPE=hidden VALUE='$date_of_registration' NAME=date_of_registration >");
    echo("<INPUT TYPE=hidden VALUE='$date_of_renewal' NAME=date_of_renewal >"); 

    echo("<INPUT TYPE=hidden VALUE='$receipt_no' NAME=receipt_no >");
    echo("<INPUT TYPE=hidden VALUE='$phone' NAME=phone >");
    echo("<INPUT TYPE=hidden VALUE='$email' NAME=email >");
    echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >");
    echo("<INPUT TYPE=hidden VALUE='$mem_still_exist_or_no' NAME=mem_still_exist_or_no >");
	echo("<BR><HR>");
    echo("<DIV ALIGN=CENTER>");
	echo ("<INPUT NAME=back TYPE=submit VALUE=Accept ALIGN=center><BR><BR>");
    echo("</DIV>");
	echo("</FORM>");
}

else
{
	echo("<DIV ALIGN=CENTER> <H1> Invalid data. </H1></DIV>");
	echo("<HR>");
}

if($passwd != $verify)
{
    echo("<DIV ALIGN=CENTER> <H1> Wrong password. </H1></DIV>");
	echo("\t");
}
?>


<FORM ACTION=member.php> 
<?php	
echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); 
?>
<DIV ALIGN=CENTER>
<INPUT NAME="reset" TYPE="submit" VALUE="Reset">
</DIV>
</FORM>
<BR><HR>


</BODY>
</HTML> 










