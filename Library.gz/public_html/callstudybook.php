<HTML>
<HEAD><TITLE>List Of All Books</TITLE></HEAD>

<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

<?php
include("header.inc");
include("common.php");



    //        $database=pg_connect("dbname=lms user=postgres");      


    $res=query("SELECT rec_acc.acc_no, common_to_books_and_thesis.person1, " .
                  "common_to_books_and_thesis.title_bk, " .
                  "common_to_three.subject_desc " .
                  "FROM rec_acc, common_to_books_and_thesis, common_to_three " . 
                  "WHERE common_to_books_and_thesis.record_id=rec_acc.record_id  " . 
                  "AND common_to_three.record_id=rec_acc.record_id " .
                  "GROUP BY rec_acc.acc_no, common_to_three.subject_desc, " .
                  "common_to_books_and_thesis.title_bk, " . 
                  "common_to_books_and_thesis.person1"); 
    
    if(pg_numrows($res) == 0 ) {
        echo("<H1 ALIGN=CENTER>No books found<H1>");
    }else {
        echo("<H1 ALIGN=CENTER>Library Books<H1><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Accession number</TH>");
        echo("<TH>Title</TH>");
        echo("<TH>Author(s)</TH>");
        echo("<TH>Call No.</TH>");
        echo("</TR>");        

        for($i=0; $i<pg_numrows($res);$i++) 
            {
                $r0=pg_result($res,$i,0); //acc_no
                $r1=pg_result($res,$i,1); //person1
                $r2=pg_result($res,$i,2); //title_bk
                $r3=pg_result($res,$i,3); //notation

                
            
                //get details of author of book using person1
                $res1=query("SELECT primary_element, " .
                               "secondary_element, additional_element " .
                               "FROM name_of_person WHERE person1='$r1' ");
                $r1="";
                
            for($j=0; $j<pg_NumRows($res1);$j++) 
                {
                        $s1=pg_Result($res1,$j,0); //primary_el
                        $s2=pg_Result($res1,$j,1); //sec_el
                        $s3=pg_Result($res1,$j,2); //addtnl_el
                        $r1 = $r1 . $s1 . " " . $s2 . " " . $s3 . "#";
                }
$t0 = (double)$r3 ;

          if($t0 >= $o && $t0 <= $t)
{

                $res2=query("SELECT mem_still_exist_or_no from reference_book where acc_no = '$r0' ");

                
            for($j=0; $j<pg_NumRows($res2);$j++) 
                {
                        $t1=pg_Result($res2,$j,0);
                }

             if( $t1 == 's')
{  

                $t1 = 'z';
                echo("<TR><TD ALIGN = CENTER> $r0 </TD>");
                echo("<TD ALIGN = CENTER> $r2 </TD>");
                echo("<TD ALIGN = CENTER> $r1 </TD>");
                echo("<TD ALIGN = CENTER> $r3 </TD>");
                echo("</TR>");
 }
}                            
            }
        echo("</TABLE>");        
    }
    

 
?>

</BODY>
</HTML>










