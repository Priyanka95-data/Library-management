<HTML>
<HEAD><TITLE>Suggestion noted</TITLE></HEAD>
<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($membername, $password, $option)) {

	$database=pg_connect("dbname=lms user=pro password=pro");
    
    $result = pg_Exec($database,"begin work"); 

    $temp =0;
    $result = pg_Exec($database,"SELECT name_of_book,".
    "author,publisher FROM suggested_books  WHERE name_of_book ='$name' and author = '$author' ".
    "and publisher = '$publisher'");
 
    $book='';
    for($i=0 ; $i<pg_NumRows($result);$i++)
    {
        $book= pg_Result($result,$i,0);
        $aut= pg_Result($result,$i,1);
        $pub= pg_Result($result,$i,2);
    } 
    if($book != '')
    {
        echo("<DIV ALIGN=center><H2>$name has already been suggested </H2></DIV>");
       $temp =1;
   }


    $result = pg_Exec($database,"SELECT name_of_book,".
    "author,publisher FROM rejected_books  WHERE name_of_book ='$name' and author = '$author' ".
    "and publisher = '$publisher'");
    $book='';
    for($i=0 ; $i<pg_NumRows($result);$i++)
    {
        $book= pg_Result($result,$i,0);
        $aut= pg_Result($result,$i,1);
        $pub= pg_Result($result,$i,2);
    } 
    if($book != '')
   {
      echo("<DIV ALIGN=center><H2>$name has been rejected, but will go for further consideration</H2></DIV>");
      $name .= "rejected book#"; 
   }

    if($temp==0)
    {
        $result=pg_Exec($database,"INSERT INTO suggested_books ".
        "VALUES('$membername','$name','$author','$publisher',CURRENT_DATE)");
    }
    
        $result = pg_Exec($database,"commit work"); 

    echo("<BR><BR><BR><DIV ALIGN=CENTER><H2>Your suggestion has been noted</H2></DIV><HR><BR><BR><BR>" ); 

	echo("<BR>");
	echo("<FORM ACTION=suggestion.php>");
	echo("<DIV ALIGN=center>");
	echo("<INPUT TYPE=SUBMIT NAME='Go Back' VALUE='Go Back'> \t");
	echo("</DIV>");
	echo("</FORM>"); 

} 
?>
</BODY>
</HTML>
