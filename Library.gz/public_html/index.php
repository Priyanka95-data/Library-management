<HTML>
<HEAD><TITLE>This Is The Index Page</TITLE></HEAD>
<BODY BGCOLOR="#A97C69" text="#316436" link="#ffffff" vlink="#ffffff" alink="#ffffff" >
<?php
	$num=0;
	include "common.php";
	if($Submit) {
		if($vpasswd==$passwd){
		$name=$fname." ".$lname;
		$lpasswd=md5($passwd);
		$result=query("INSERT INTO clerk VALUES ('admin',".
			"'$lpasswd','$name','Administrator','$taddress',".
			"'$paddress',$ph_no,'$email') ");			
		$result=query("INSERT INTO lib_name(l_name) VALUES (".
			"'$institute')");
		}
		elseif($vpasswd != $passwd){
			echo("<DIV  ALIGN = CENTER>");
			echo("</DIV><HR>");
			echo("<DIV ALIGN=CENTER>");
			echo("<H2>The Passwords Donot Verify </H2>");
			echo("<H3>Please Re-Enter Them </H3>");
			echo("<FORM ACTION=index.php METHOD=GET>");
			echo("<INPUT TYPE=SUBMIT VALUE=Reload NAME=Reload>");
			echo("</FORM>");
			echo("</DIV>");
		}
	}
	else{
        $result=query("SELECT * FROM clerk WHERE clerk='admin'");
        $num=pg_NumRows($result);
        $result=query("SELECT * FROM serial_frequency");
        $num1=pg_numrows($result);
        if($num==0 and $num1==0){
                include("script.php");
        }
	if($num==0){
		include "start.php";
		exit();
	}
	}
?>
	<HR>
	<FONT COLOR="#6E1131">
	<h1 align=center><BIG>Welcome To The Library Management System
	</BIG></h1>
	</FONT>
	<HR>
	<DIV ALIGN=CENTER>
		<TABLE ALIGN=CENTER WIDTH='45%'><TR><TD>
		<FONT COLOR=BLUE>
		
		<TABLE WIDTH='80%' ALIGN=CENTER><TR><TD>
		<BR><DIV ALIGN=CENTER><h3>
		<A HREF=search.html><BIG>Search the  Library
		</BIG></A></h3></DIV>
		</TD></TR><TR><TD>
		<DIV ALIGN=CENTER><h3>
		<A HREF=loginmember.html><BIG>Members Of Library
		</BIG></A></h3></DIV>
		</TD></TR><TR><TD>
		<DIV ALIGN=CENTER><h3>
		<A HREF=login.html><BIG>Staff Of The Library
		</BIG></A></h3></DIV>
		</TD></TR></TABLE>
		</FONT>
		</TD></TR></TABLE><BR>		
	</DIV>
	<BR>
<HR>
	<TABLE WIDTH='25%' ALIGN=RIGHT><TR><TD>
	<FONT COLOR=BLACK>Please Click On the above links to Proceed.</FONT>
	</TD></TR></TABLE><BR><BR><BR><BR>
<DIV ALIGN=CENTER>
	<A HREF="http://www.apache.org/" target="blank"><IMG SRC="apache00.gif" ALT="Apache Web Server" BORDER=0 HSAPCE=10></A><A HREF="http://www.php.net/" target="blank"><IMG SRC="php20000.gif" ALT="PHP Scripting Language" BORDER=0 HSPACE=10></A><A HREF="http://www.postgresql.org/" target="blank"><IMG SRC="postgresql.gif" BORDER=0 HSPACE=10 ALT="Web Site Powered by PostgreSQL" HEIGHT=45 WIDTH=100></A><A HREF="http://sourceforge.net/"><IMG SRC="sflogo-88-1.png" WIDTH=98 HEIGHT=43 border=0 ALT="SourceForge Logo"></A><br><br>
	<TABLE ALIGN=CENTER WIDTH="71%"><TR><TD><FONT COLOR=white>
	All Logos and Trademarks of the site are property of their respective owner. The comments are the property of the posters, all the rest @ 2000 by me.
</FONT></TD></TR></TABLE>
</DIV>
</BODY>
</HTML>
