<HTML>
<HEAD><TITLE>Allocate status</TITLE></HEAD>  
<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password,$option)) {

	echo("<HR>");

    if($status1 && $deposited_amt1 && $fees1 && $entitlement1 && $days_per_book1)
        {

       echo("<DIV ALIGN=CENTER><H1>Please verify the information<H1></DIV>");
       echo("<HR>");
            echo("<FORM ACTION=statusdatabase.php>");
            //            $status=$status1;		 	
            //            $deposited_amt=$deposited_amt1;
            //            $fees=$fees1;  
            //            $entitlement=$entitlement1;  
            //            $days_per_book=$days_per_book1;
            
            echo("<INPUT TYPE=hidden NAME=status VALUE='$status1'>");
            echo("<INPUT TYPE=HIDDEN NAME=deposited_amt VALUE='$deposited_amt1'>");
            echo("<INPUT TYPE=HIDDEN NAME=fees VALUE='$fees1'>");
            echo("<INPUT TYPE=HIDDEN NAME=entitlement VALUE='$entitlement1'>");
            echo("<INPUT TYPE=HIDDEN NAME=days_per_book VALUE='$days_per_book1'>");
            echo("<INPUT TYPE=HIDDEN NAME=entitlement2 VALUE='$entitlement2'>");
            echo("<INPUT TYPE=HIDDEN NAME=entitlement3 VALUE='$entitlement3'>"); 
            
            echo("<TABLE ALIGN=center WIDTH='50%'><TR><TD>" .
                 "Name of new status category           : </TD><TD>".
                 "$status1</TD></TR><TR><TD>" .
                 "Number of entitlements granted        : </TD><TD>".
		 "$entitlement1</TD></TR><TR><TD>" .
                 "Number of days for books to be issued : </TD><TD>".
		 "$days_per_book1</TD></TR><TR><TD>" .
                 "Number of renewals permitted          :  </TD><TD>".
		 "$entitlement3</TD></TR><TR><TD>" .
                 "Number of reservations permitted      : </TD><TD>".
                 "$entitlement2</TD></TR><TR><TD>" .
                 "Deposit amount                        : </TD><TD>".
		 "$deposited_amt1</TD></TR><TR><TD>" .
                 "Annual fee                            : </TD><TD>".
		 "$fees1" .
                 "</TD></TR></TABLE><BR>"
                 );
                 
            echo("<HR><DIV ALIGN=CENTER>");
            echo("<INPUT NAME=back TYPE=submit VALUE=Enter><BR><BR>");
            echo("</DIV>");
            echo("</FORM>");
            
            echo("<FORM ACTION=status.php>"); 
            echo("<DIV ALIGN=CENTER>");
            echo("<INPUT NAME=reset TYPE=submit VALUE='Go Back'>");
            echo("</DIV>");
            echo("</FORM><HR>");
	    echo("<TABLE WIDTH=90%><TR><TD>");
	    echo("<A HREF=admin.php>Home Page</A></TD><TD>");
	    echo("<A HREF=logout.php>Logout</A></TD></TR></TABLE>");
            
        }
	else
        {
            
            echo("<DIV ALIGN=CENTER><H1>Incomplete data<H1></DIV>");            
            echo("<FORM ACTION=status.php>"); 
            echo("<BR><BR><HR><DIV ALIGN=CENTER>");
            echo("<BR><BR><INPUT NAME=reset TYPE=submit VALUE='Go Back'><BR><BR><HR>");
            echo("</DIV>");
            echo("</FORM>");
            
        }
}

?>           
</BODY>
</HTML>

                  




