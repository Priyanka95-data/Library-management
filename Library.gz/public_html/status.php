<HTML>
<HEAD><TITLE>Allocate status</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {
    
       echo("<HR><DIV ALIGN = CENTER> ");
       echo("<H1>Create new status category</H1></DIV>");
       echo("<HR><BR>");
       
       echo("<FORM ACTION=statusdisplay.php METHOD=POST>");
       echo("<TABLE ALIGN=center WIDTH=65%>");

       echo("<TR><TD><b>Name of new status category :</b></TD>");
       echo("<TD><INPUT NAME=status1 TYPE=TEXT></TD></TR>");

       echo("<TR><TD><b>Number of entitlements granted :</b></TD>");
       echo("<TD><INPUT NAME=entitlement1 TYPE=text></TD></TR>");

       echo("<TR><TD><b>Number of days for books to be issued :</b></TD>");
       echo("<TD><INPUT NAME=days_per_book1 TYPE=text></TD></TR>"); 

       echo("<TR><TD><b>Number of renewals permitted :</b></TD>");
       echo("<TD><INPUT NAME=entitlement3 TYPE=text></TD></TR>");

       echo("<TR><TD><b>Number of reservations permitted :</b></TD>");
       echo("<TD><INPUT NAME=entitlement2 TYPE=text ></TD></TR>");

       echo("<TR><TD><b>Deposit amount :</b></TD>");
       echo("<TD><INPUT NAME=deposited_amt1 TYPE=TEXT></TD></TR>");

       echo("<TR><TD><b>Annual fee :</b></TD>");
       echo("<TD><INPUT NAME=fees1 TYPE= text ></TD></TR>");
       
       echo("</TABLE><BR><HR><BR>");
       echo("<DIV ALIGN=CENTER>");
       echo("<INPUT NAME=display TYPE=submit VALUE=Display>");
       echo("</DIV>");
       echo("</FORM> <BR>");
       
       echo("<FORM ACTION=status.php>"); 
       echo("<DIV ALIGN=CENTER>");
       echo("<INPUT NAME=reset TYPE=submit VALUE=Reset>");
       echo("</DIV>");
       echo("</FORM>");
       echo("<BR><HR><DIV ALIGN=right><A HREF='admin.php'>Return to home page</A></DIV>");

}else{
	echo("<BR><HR>");
	echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
	echo("<FORM ACTION=login.html>"); 
	      echo("<DIV ALIGN=RIGHT>");
	      echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
	      echo("</DIV>");
	echo("</FORM>");
	}
?>
</BODY>
</HTML> 







