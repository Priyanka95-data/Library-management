<HTML>
<HEAD><TITLE>Members Search</TITLE>
<BODY bgcolor="#8AFF90" text="#316431">

<SCRIPT LANGUAGE="JavaScript">
<!-- check for name field
     function checkform( thisform){
             if (thisform.name.value==null || thisform.name.value==""){
	         alert("Please enter the Search Field");
		 thisform.name.focus();
		 thisform.name.select();
		 return false;
	     }
	     return true
     }
//the end of function -->
</SCRIPT></HEAD>




<?php
include("header.inc");
include("common.php");

if(authenticate_user($membername, $password, $option)) {

?>

    <DIV ALIGN=CENTER>
        <P><H1>Search <?php LIBRARY ?> collection</H1></P>
    </DIV>

        <BR><BR><BR>        <BR><BR><BR>

    <TABLE width="70%" border="2" cellpadding="5" ALIGN=CENTER>
    <tr valign="top"> 
    <td> 
      <FORM METHOD=GET ACTION="membersearchdisplay.php" onSubmit="return checkform( this)">
      <DIV ALIGN=CENTER><BR>
          <DIV ALIGN=right>
	  <SELECT NAME="count" VALUE="count">
	  	<OPTION>10 records per page</OPTION>
		<OPTION>20 records per page</OPTION>
		<OPTION>25 records per page</OPTION>
		<OPTION SELECTED>50 records per page</OPTION>
	  </SELECT><BR><BR>
	  </DIV>  
	  <INPUT TYPE=HIDDEN NAME=offset VALUE=0>
              <INPUT NAME="name" TYPE=TEXT>
	      <P>On</P>
	      <SELECT NAME="selection">
	      	<OPTION>Title</OPTION>
		<OPTION>Call Number</OPTION>
		<OPTION>Keywords</OPTION>
		<OPTION>Journal Title</OPTION>
		<OPTION SELECTED>Author</OPTION>
	      </SELECT><BR><BR>
              <INPUT VALUE=0 NAME=variable TYPE=HIDDEN >
              <?      echo("<INPUT TYPE=HIDDEN NAME=mem_id VALUE='$mem_id'>");
                    echo("<INPUT TYPE=HIDDEN NAME=mem VALUE='$mem'>");
		?>
                   <INPUT VALUE="Submit" TYPE=SUBMIT >
&nbsp&nbsp&nbsp&nbsp
                   <INPUT TYPE=RESET VALUE=Reset><BR><BR>
      </DIV>
      </FORM>
    </TD>
    </TR>

    </TABLE><BR>

        <BR><BR><BR>        <BR><BR><BR>
    <HR><BR>

    <B><U>Search Tips :</U></B> 
    <TABLE BORDER="0" cellpadding=3 vspace=2>

    <TR>
<TD ALIGN=CENTER WIDTH=20 valign=top><img SRC="" BORDER=0 height=10 width=10>
</TD><TD valign=top>
<B>Author: Search for author's last name first.</B>
<BR>shakespeare william
<BR>ramesh gaonker</FONT></TD>

<TD ALIGN=CENTER WIDTH=20 valign=top><img SRC="" BORDER=0 height=10 width=10></TD>
<TD valign=top>
<B>Title: Enter as much of the title as you know.</B>
<BR>portrait of the artist
<BR>linux for dummies</FONT></TD>
</TR>

<TR>
<TD ALIGN=CENTER WIDTH=20 valign=top><img SRC="" BORDER=0 height=10 width=10></TD>
<TD valign=top><B>
Keywords : Enter a possible keyword regarding the search.</B>
<BR>literature modern 20th century
<BR>unix security internet </FONT></TD>

<TD ALIGN=CENTER WIDTH=20 valign=top><IMG SRC="" BORDER=0 height=10 width=10></TD>
<TD valign=top>
<B>Call number: Enter as much of the call number as you know.</B>
<BR>R4753 
<BR>2264.108
</FONT></TD>
</TR>
</FONT>
</TABLE>

<?php
	echo("<BR><HR><DIV ALIGN=RIGHT>");
	echo("<A HREF=logoutmember.php><b>Logout</b></A>");
	echo("</DIV>");

       } else{
        echo("<BR><HR>");
        echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
        echo("<FORM ACTION=login.html>"); 
              echo("<DIV ALIGN=RIGHT>");
              echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
              echo("</DIV>");
        echo("</FORM>");
        }

	?>
<BR><HR>
</BODY>
</HEAD>

	



