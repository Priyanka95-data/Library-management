<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

<BODY>
 <BR>

<?php

include("common.php");

if(authenticate_user($name, $password, $option)) {

//check to see that mem_id does not exist

$res = query("SELECT mem_id FROM member WHERE mem_id='$mem_id'");
if(pg_NumRows($res)>0) {
    echo("<H2 ALIGN=CENTER>Member id exists ... Please try another member id</H2><BR>");
} else {

//mem_id is unique .. we can continue

    query("BEGIN WORK");

    //get details about status 
$res = query("SELECT entitlement, reservation_bk FROM status WHERE status='$status';");

/*FOR TESTING OPERA!!
if(!$res || pg_NumRows($res)<1) {
    echo("SHIT HAPPENS<BR>");
    echo pg_errormessage($database);
} else {
    echo("select Successful!<BR>");
}
*/

//$i=pg_NumRows($res);
//echo("Num_rows: $i<BR>");
    for($i=0; $i<pg_numrows($res); $i++) {
        $entitlement=pg_result($res,$i,'entitlement');
        $reservation_bk=pg_result($res,$i,'reservation_bk');
    }
    
$res = query("INSERT INTO mem_related_to_entitlement " .
             "VALUES(nextval('mem_related_to_entitlement_seq'),'$entitlement','$reservation_bk',0)");
        
    //encrypt password
$passwd=md5($passwd);

    //create member
$res = query("INSERT INTO member " . 
             "VALUES('$mem_id','$surname','$first_name','$passwd','$date_of_birth','$status','$institution','$course','$temporary_address','$permanent_address','$phone','$email','$date_of_registration','$date_of_renewal','$receipt_no','$name','$mem_still_exist_or_no','$year',currval('mem_related_to_entitlement_seq'))"); 

if($picture_name){
    $res = query("INSERT INTO picture " .
                 "VALUES('$mem_id','$picture_name')");
}

if(!$res || pg_cmdtuples($res)<1) {
    echo("<H2 ALIGN=CENTER>Data has <B>not<B> been inserted into the database.</H2><BR>"); 
    echo(pg_errormessage($res) . "<BR>");
    query("ROLLBACK WORK"); 
} else {
    query("COMMIT WORK"); 
    echo("<H2 ALIGN=CENTER>Data has been sucessfully inserted into the database.</H2><BR>"); 
}
}
}
else {
	echo("<BR><HR>");
	echo("<H1 ALIGN=CENTER> Please login first</H1><HR>");

	echo("<FORM ACTION=login.html>"); 
    echo("<DIV ALIGN=RIGHT>");
    echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
    echo("</DIV>");
	echo("</FORM>");
	}

?>

<FORM ACTION=member.php> 

<DIV ALIGN=center>
<INPUT NAME="reset" TYPE="submit" VALUE="Add another member">
</DIV>
</FORM>

<BR><HR><DIV ALIGN=RIGHT>
<A HREF=logout.php><b>Logout</b></A>
</DIV>

</BODY>
</HTML> 








