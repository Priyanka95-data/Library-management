<HTML>
<HEAD><TITLE>The Database Is Updated.</TITLE></HEAD>
<BODY COLOR=#odba5>
<?
session_start();
 include "header.inc";
 include "common.php";
 if(authenticate_user($name,$password,$option){
	$res=query("begin work");
	if($set_bibliographic_level){
		$res=query("UPDATE common_to_books_and_serial SET ".
	"bibliographic_level=bibliographic_level('$bibliographic_level_desc1')".
	" WHERE record_id=$record_id");
	}
	if($set_date_of_entry1){
		$res=query("UPDATE common_to_three SET date_of_entry=".
		"'$date_of_entry' WHERE record_id=$record_id");
	}
	if($set_language_code){
		$res=query("UPDATE language_id SET language_code=". 
		"language_code('$language_code1') WHERE ".
		"language_id=$language_id");
	}
	if($set_phy_desc){
	   for($i=0;$i<count($physical_medium_desc1);$i++){
		$res=query("UPDATE physical_medium_m SET physical_medium=".
		"physical_medium('$physical_medium_desc1[$i]') WHERE ". 
		"physical_medium_id=$physical_medium_id");
	   }
	}
	if($set_tomd){
		$res=query("UPDATE common_to_books_and_thesis SET ".
		"type_of_material=type_of_material('$type_of_material1') ".
		"WHERE record_id=$record_id");
	}
	if($set_title_bk){
		$res=query("INSERT INTO title_bk VALUES ($title_bk_id,".
		"'$title_bk1',$statt_of_resp_ti_bk1,language_code('English'),".
		"script('English')");
		$res=query("UPDATE common_to_books_and_thesis SET ".
		"title_bk_id=$title_bk_id , title_bk='$title_bk1' WHERE ".
			"record_id=$record_id");
		$res=query("DELETE FROM title_bk WHERE title_bk='$title_bk' ".
			"AND title_bk_id='$title_bk_id'");
	}
	if($set_statt_of_resp_ti_bk)
	{
		$res=query("UPDATE title_bk SET statt_of_resp_ti_bk=".
		"'$statt_of_resp_ti_bk1' WHERE title_bk='$title_bk' AND ".
		"title_bk_id=$title_bk_id");
	}
	if($set_nop)
	{
		for($i=0;$i<count($additional_element)|$i<count($secondary_element)|$i<count($entry_element);$i++){
			$res=query("UPDATE name_of_person SET primary_element=".
			"'$primary_element[$i]',secondary_element=".
			"'$secondary_element[$i]',additional_element=".
			"'$additional_element[$i]',role1=70 WHERE ".
			"person1=$person1");
		}
	}
	if($set_subject_desc)
	{
		$res=query("UPDATE common_to_three SET subject_desc=".
		"'$subject_desc1' WHERE record_id=$record_id");
	}
	if($set_acc_no){
		$acc_no=explode(",",$acc_no1);
		$acc_no2=explode(",",$aacc_no);
		for($i=0;$i<count($acc_no);$i++){
		$res=query("UPDATE rec_acc SET acc_no='$acc_no[$i]'".
			" WHERE record_id=$record_id AND ".
			"acc_no='$acc_no2[$i]");
		}
	}
	if($set_reference){
		$ref_acc=explode(",",$reference);
		$ref_acc1=explode(",",$racc_no);
		for($i=0;$i<count($ref_acc1);$i++){
			$res=query("DELETE FROM reference_book WHERE acc_no".
			"='$ref_acc1[$i]' AND mem_still_exist_or_no='r'");
		}
		for($i=0;$i<count($ref_acc);$i++){
			$res=query("INSERT INTO reference_book VALUES ".
			"('$ref_acc[$i]','r'");
		}
	}
	if($set_study){
                $ref_acc=explode(",",$study);
                $ref_acc1=explode(",",$sacc_no);
                for($i=0;$i<count($ref_acc1);$i++){
                        $res=query("DELETE FROM reference_book WHERE acc_no".
                        "='$ref_acc1[$i]' AND mem_still_exist_or_no='s'");
                }
                for($i=0;$i<count($ref_acc);$i++){
                      $res=query("INSERT INTO reference_book VALUES ".
                       "('$ref_acc[$i]','s'");
               }									}
	if($set_isbn){
		$res=query("UPDATE isbn SET isbn='$isbn' WHERE isbn_id='$isbn_id'");
	}
	if($set_nocb){
		$res=query("DELETE FROM name_of_corporate_body WHERE ".
		"name_of_corporate_body_id='$name_of_corporate_body_id'");
		if($name_of_corporate_body2!='NULL'){
			$res=query("INSERT INTO name_of_corporate_body ".
			"(name_of_corporate_body_id,name_of_corporate_body) VALUES ".
			"('$name_of_corporate_body_id','$name_of_corporate_body2')");
		}
		else{
			for($i=0;$i<count($name_of_corp);$i++){
			$res=query("INSERT INTO name_of_corporate_body ".
			"(name_of_corporate_body_id,name_of_corporate_body) ".
			"VALUES ('$name_of_corporate_body_id',".
			"'$name_of_corp[$i]')");
			}
		}
	if($set_other_title){
		$res=query("UPDATE other_title SET other_title='$other_title1'".
		"WHERE other_title_id='$other_title_id'");
	}
	if($set_tot){
		$res=query("UPDATE other_title SET type_of_title=".
		"'$type_of_title1' WHERE other_title_id='$other_title_id'");
	}
	if($set_forms_of_statt1){
		$res=query("UPDATE edition_statt SET forms_of_edition_statt= ".
		"'$forms_of_statt1' WHERE edition_statt='$edition_statt'");
	}
	$pub_details=explode("##",$publisher_details);
	$distri_details=explode("##",$distributor_details);
	if($set_fpn | $set_fpa | $set_fpc | $set_fpp){
		if(count($pub_details)!=0){
		$res=query("DELETE FROM place_and_publisher WHERE ".
			"publisher_name_id=$publisher_name_id");
		$res=query("INSERT INTO place_and_publisher VALUES(".
			"$publisher_name_id,'$pub_details[0]',".	
	    		"'$pub_details[1]','$pub_details[2]',".
			"country('$pub_details[3]')");	
		}
		else{ 
		   $res=query("DELETE from place_and_publisher WHERE ".
		   	"publisher_name_id='$publisher_name_id'");
		   if($pub_name!=$publisher_name1 | $place_of_pub!=$place_of_publisher1 | $addr_of_publ!=$address_of_publisher1 | $country_of_publ!=$country_of_publisher1){
			$publisher=explode("#",$publisher_name1);
			$place=explode("#",$place_of_publisher1);
			$address=explode("#",$address_of_publisher1);
			$country=explode("#",$country_of_publisher1);
			for($i=0;$i<count($publisher) | $i<count($place) | $i<count($address) | $i<count($country);$i++){
			if(!$publisher[$i]){
				$publisher[$i]=$pub_name;
			}
			if(!$place){
				$place[$i]=$place_of_pub;
			}
			if(!$address){
				$address[$i]=$addr_of_publ;
			}
			if(!$country){
				$country[$i]=$country_of_publ;
			}
			$res=query("INSERT INTO place_and_publisher VALUES (".
			"$publisher_name_id,'$publisher[$i]','$place[$i]'".
			"'$address[$i]',country('$country[$i]')");
			}
		   }
		}
	}
        if($set_fdn | $set_fda | $set_fdc | $set_fdp){
            if(count($distri_details)!=0){
                $res=query("DELETE FROM place_and_distribution WHERE ".
                     "place_and_distribution_id=$place_and_distribution_id");
                $res=query("INSERT INTO place_and_publisher VALUES(".
                        "$place_and_distribution_id,'$distri_details[0]',".
                        "'$distri_details[1]','$distri_details[2]',".
                        "country('$distri_details[3]')");
            }
            else{
                  $res=query("DELETE from place_and_distribution WHERE ".
                     "place_and_distribution_id='$place_and_distribution_id'");
                 if($distributor_name!=$name_of_distributor1 | $distri_place!=$place_of_distributor1 | $distri_addr!=$address_of_distributor1 | $distri_country!=$country_of_distributor1){
                $distributor=explode("#",$name_of_distributor1);
	        $place=explode("#",$place_of_distributor1);
		$address=explode("#",$address_of_distributor1);
		$country=explode("#",$country_of_distributor1);
		for($i=0;$i<count($distributor) | $i<count($place) | $i<count($address) | $i<count($country);$i++){
		     if(!$distributor[$i]){
		                    $distributor[$i]=$pub_name;
		     }
		     if(!$place){
		                    $place[$i]=$place_of_pub;
		     }
		     if(!$address){
		                    $address[$i]=$addr_of_publ;
	             }
	             if(!$country){
	                            $country[$i]=$country_of_publ;
	             }
	             $res=query("INSERT INTO place_and_distribution VALUES (".
                  "$place_and_distribution_id,'$distributor[$i]','$place[$i]'".
	                 "'$address[$i]',country('$country[$i]')");
	             }
		     }
	    }
	}
	if($set_textual | $set_prelim){
		if($set_textual && $set_prelim){
			$tex=$textual1;
			$pre=$priliminary1;
		}
		elseif($set_textual){
			$tex=$textual1;
			$pre=$preliminary;
		}
		else{
			$tex=$textual;
			$pre=$prilimary1;
		}
		$res=query("INSERT INTO pagination ".
		"VALUES('$pre',$tex,0,'PCCE','{{"8"}{"8"}{"8"}}','$accomp_material')");
		$res=query("UPDATE common_to_books_and_tesis SET ".
		"SET preliminary='$pre' AND textual=$tex WHERE record_id=".
		"$record_id");
	}
	if($set_accomp_mat){
		$res=query("UPDATE pagination SET accomp_material=".
		"'$accomp_material1' WHERE preliminary=$preliminary AND ".
		"textual='$textual'");
	}
	if($set_invoice_no){
		$res=query("UPDATE common_to_books_and_serial SET invoice_no".
		"=0 WHERE record_id=$record_id");
		$res=query("UPDATE book_details SET invoice_no=0 WHERE ".
			"record_id=$record_id");
		$res=query("UPDATE invoice_details SET invoice_no=".
		"$invoice_no1 WHERE invoice_no=$invoice_no");
		$res=query("UPDATE common_to_books_and_serial SET invoice_no"
		"=$invoice_no1 WHERE record_id=$record_id");
		$res=query("UPDATE boook_details SET invoice_no=".
			"$invoice_no1 WHERE record_id=$record_id");
	}
	if($set_copies){
		$res=query("UPDATE book_details SET no_of_copies=$copies ".
		"WHERE record_id=$record_id");
	}
	if($set_amt){
		$res=query("UPDATE books_details SET price_per_unit='$amt'".
		"WHERE record_id=$record_id");
	}
	if($set_issn){
		$res=query("UPDATE books SET issn=0 WHERE record_id=".
		"$record_id"); 
		$res=query("SELECT * from series_statt WHERE issn=$issn");
		for($i=0;$i<pg_numrows($res);$i++){
			$is=pg_result($res,$i,0);
			$sn=pg_result($res,$i,1);
			$sorss=pg_result($res,$i,2);
			$pstn=pg_result($res,$i,3);
			$pstn_id=pg_result($res,$i,4);
		}
		$res=query("INSERT INTO series_statt VALUES ($issn1,'$sn',".
		"'$sorss','$pstn',$pstn_id)");
		$res=query("UPDATE books SET issn=$issn1 WHERE record_id=".
		"$record_id");
	}
	if($set_series_name){
		$res=query("UPDATE series_statt SET series_name=".
		"'$series_name1' WHERE issn=$issn");
	}
	if($set_statt_ors2){
		$res=query("UPDATE series_statt SET statt_of_resp_sr_statt=".
		"$statt_of_statt_sr_statt1");
	}
	if($set_vol_part_no1){
		$res=query("UPDATE part_statt SET volume_or_part_no=".
		"$volume_or_part_no1 WHERE part_statt_id=$part_statt_id"
	}
	if($set_part_statt1){
		$res=query("UPDATE part_statt SET part_statt='$part_statt1'".
		"WHERE part_statt_id='$part_statt_id'");
	}
	if($set_note1){
		$res=query("UPDATE common_to_three SET note='$note1' ".
		"WHERE record_id=$record_id")
	}
	$res=query("UPDATE common_to_three SET acq_clerk='$name' WHERE".
		"record_id=$record_id");
	$res=query("commit work");
?> 	<hr><br>
	<h1 align=center>The Database has been updated Successfully</h1><br><?
	include "includeacqclerk.php";
} else {
 Header("Location:http://$HTTP_HOST/~pro/authfail.html");
 }
?>
</BODY>
</HTML>
