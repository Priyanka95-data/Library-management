<HTML>
<HEAD><TITLE>List Of All Books</TITLE></HEAD>

<BODY bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">

<?php
include("header.inc");
include("common.php");

  $res=query("SELECT rec_acc.acc_no, common_to_books_and_thesis.person1," .
                  "common_to_books_and_thesis.title_bk," .
                  "common_to_three.subject_desc, ".
//                "other_title.other_title," .
		  "place_and_publisher.publisher_name, ".
		  "place_and_publisher.place, ".
		  "place_and_distribution.name_of_distributor,".
		  "common_to_books_and_thesis.preliminary, ".
		  "common_to_books_and_thesis.textual, ".

		  "book_details.invoice_no,book_details.price_per_unit ".
                  "FROM ".
//		  "other_title,".
		  "rec_acc,".
		  "place_and_publisher , ".
		  "common_to_books_and_thesis, common_to_three, ".
		  "map_distribution,place_and_distribution, ".
		  "common_to_books_and_serial, ".
		  
		  "book_details ".
 "WHERE common_to_books_and_thesis.record_id=common_to_three.record_id  " . 
        "AND common_to_three.record_id=rec_acc.record_id ".
//	"AND common_to_three.other_title=other_title.other_title_id " .
"AND common_to_three.publisher_name_id=map_publisher.publisher_name_id ".
"AND place_and_publisher.publisher_name_id = map_publisher.publisher_name_id ".
"AND common_to_books_and_serial.record_id = common_to_three.record_id AND ".
"common_to_books_and_serial.place_and_distribution =map_distribution.place_and_distribution_id AND ".
"map_distribution.place_and_distribution_id=place_and_distribution.place_and_distribution_id ".
"AND book_details.record_id=common_to_three.record_id ".
		  "GROUP BY rec_acc.acc_no,".
                  "common_to_books_and_thesis.person1,".
		  "common_to_books_and_thesis.title_bk," . 
                  "common_to_three.subject_desc,".
//		  "other_title.other_title,".
                 "place_and_publisher.publisher_name, ".
                  "place_and_publisher.place, ".
		  "place_and_distribution.name_of_distributor,".
		  "common_to_books_and_thesis.preliminary,".
		  "common_to_books_and_thesis.textual, ".
                  "book_details.invoice_no,book_details.price_per_unit ".
"ORDER BY CAST(rec_acc.acc_no AS INT)"); 
    
    if(pg_numrows($res) == 0 ) {
        echo("<H1 ALIGN=CENTER>No books found<H1>");
    }else {
        echo("<H1 ALIGN=CENTER>Library Books<H1><BR><HR><BR><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Accession number</TH>");
        echo("<TH>Title</TH>");
        echo("<TH>Author(s)</TH>");
        echo("<TH>Call No.</TH>");
        echo("<TH>Publisher</TH>");
        echo("<TH>Place Of Publisher</TH>");
        echo("<TH>Supplier</TH>");
        echo("<TH>Pages</TH>");
        echo("<TH>Source</TH>");
        echo("<TH>Order No.</TH>");
        echo("<TH>Bill No.</TH>");
        echo("<TH>Amount</TH>");
        echo("<TH>Remarks</TH>");
        echo("</TR>");        

        for($i=0; $i<pg_numrows($res);$i++) 
            {
                $r0=pg_result($res,$i,0); //acc_no
                $r1=pg_result($res,$i,1); //person1
                $r2=pg_result($res,$i,2); //title_bk
                $r3=pg_result($res,$i,3); //Call No
                $r4=pg_result($res,$i,4); //publisher_name
                $r6=pg_result($res,$i,5); //place_publisher
                $r7=pg_result($res,$i,6); //name_distributor
		$r8=pg_result($res,$i,7); //pages - prilim
		$r9=pg_result($res,$i,8); //pages - textual
		$r10=pg_result($res,$i,9); //invoice_no
		$r11=pg_result($res,$i,10); //net_price
		
              //get details of author of book using person1
                $res1=query("SELECT primary_element, " .
                               "secondary_element, additional_element " .
                               "FROM name_of_person WHERE person1='$r1' ");
                $r1="";
		                
                for($j=0; $j<pg_NumRows($res1);$j++) 
                    {
                        $s1=pg_Result($res1,$j,0); //primary_el
                        $s2=pg_Result($res1,$j,1); //sec_el
                        $s3=pg_Result($res1,$j,2); //addtnl_el
                        $r1 = $r1 . $s1 . " " . $s2 . " " . $s3 . ", ";
                    }
		$rema='';
		$res2=query("SELECT remarks FROM remarks WHERE acc_no='$r0'");
		for($j=0; $j<pg_NumRows($res2);$j++)
		        {
			$rema=pg_Result($res2,$j,0); //remark
			$rema=$rema.' ';
		        }
//		$resm=query("SELECT invoice_no,net_price ".
//			"FROM book_details WHERE record_id='$
                echo("<TR><TD ALIGN = CENTER> $r0 </TD>");
		$r5 = $r2 .';'.$r;
                echo("<TD ALIGN = CENTER> $r5 </TD>");
                echo("<TD ALIGN = CENTER> $r1 </TD>");
		ereg("([0-9\.]*)([A-Za-z\/\.0-9]*)",$r3,$reg);
		$r3=$reg[1].' '.$reg[2];
                echo("<TD ALIGN = CENTER> $r3 </TD>");
                echo("<TD ALIGN = CENTER> $r4 </TD>");
                echo("<TD ALIGN = CENTER> $r6 </TD>");
                echo("<TD ALIGN = CENTER> $r7 </TD>");
		$r8 = $r8.' '.$r9;
                echo("<TD ALIGN = CENTER> $r8 </TD>");
                echo("<TD ALIGN = CENTER> $blank </TD>");
                echo("<TD ALIGN = CENTER> $r </TD>");
                echo("<TD ALIGN = CENTER> $r10 </TD>");
                echo("<TD ALIGN = CENTER> $r11 </TD>");
                echo("<TD ALIGN = CENTER> $rema </TD>");
                echo("</TR>");
                             
            }
        echo("</TABLE>");        
    }
?>
</BODY>
</HTML>

