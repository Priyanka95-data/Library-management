<HTML>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    query("BEGIN WORK");

    $res = query("UPDATE mem_book SET status_mem_bk='d' WHERE date_of_return<='CURRENT_DATE' AND status_mem_bk='i'");

    //report status of operation
    if(!$res || pg_cmdtuples($res)<1) {
        echo("<BR><H1 ALIGN=CENTER>No books overdue today</H1><BR>"); 
        //        echo(pg_errormessage($res) . "<BR>");
        query("ROLLBACK WORK"); 
    } else {
        query("COMMIT WORK"); 
        echo("<BR><H1 ALIGN=CENTER>Overdue books found</H1><BR>"); 
    }
}
?>

</BODY>
</HTML>