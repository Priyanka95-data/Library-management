<HTML>
<HEAD><TITLE>This Is The Update Page For Books</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316431">
<?php
include("header.inc");
include "common.php";
if(authenticate_user($name,$password,$option)){
echo("<H1 ALIGN=CENTER><FONT COLOR=BROWN>This Page Allows To Update Existing Book</FONT></H1><BR><BR>");
	echo("<HR><BR>");
	echo("<FORM ACTION=bookupdt.php METHOD=GET>");
	echo("<TABLE ALIGN=CENTER><TR><TD>");
	echo("<B>Enter the Accession Number Of The Book :</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=acc_no>");
	echo("</TD></TR></TABLE><DIV ALIGN=CENTER><BR>");  
	echo("<INPUT TYPE=RESET NAME='Reset' VALUE='Reset'> ");
	echo("<INPUT TYPE=SUBMIT NAME='Submit' VALUE='Submit'>");
	echo("</DIV>");
	echo("</FORM>");
        echo("<BR><HR>");
?>
	<TABLE WIDTH=100% ALIGN=CENTER><TR><TD>
	<DIV ALIGN=LEFT>
		<A HREF=acq_clerkentry.php>
			<FONT COLOR=RED><b>Goto Home Page</b></FONT>
		</A></DIV></TD><TD>
	<DIV ALIGN=RIGHT>
		<A HREF=logout.php>
			<FONT COLOR=RED><b>Logout</B></FONT>
		</A></DIV></TD></TR></TABLE>
<?php
} else {
	Header("Location:http://$HTTP_HOST/~pro/authfail.html");
}
?>
</BODY>
</HTML>
