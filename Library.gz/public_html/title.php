<?php

       $database=pg_connect("dbname=lms user=pro");


    $reach=pg_Exec($database,"SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 from common_to_books_and_thesis where common_to_books_and_thesis.title_bk='linux' group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.statt_of_resp_ti_bk,common_to_books_and_thesis.person1 union SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 from common_to_books_and_thesis,common_to_three where common_to_three.parallel_title_id=parallel_title.parallel_title_id and parallel_title.parallel_title='NULL' group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.statt_of_resp_ti_bk,common_to_books_and_thesis.person1 union SELECT common_to_books_and_thesis.title_bk,common_to_books_and_thesis.person1 from common_to_books_and_thesis,common_to_three where common_to_three.other_title=other_title.other_title_id and other_title.other_title='' group by common_to_books_and_thesis.title_bk,common_to_books_and_thesis.statt_of_resp_ti_bk,common_to_books_and_thesis.person1") ;


            for($i=0;$i<pg_NumRows($reach);$i++){
		    $title=pg_Result($reach,$i,0);
		    $rest=pg_Result($reach,$i,1);
       $reach1=pg_Exec($database,
              "select primary_element,secondary_element,additional_element from name_of_person where person1='$rest'");
                 
             echo(" preson1 : $rest <BR>:");
            for($j=0;$j<pg_NumRows($reach1);$j++){
   		    $rest=pg_Result($reach,$i,1);
		    $primary_element=pg_Result($reach1,$j,0);
		    $secondary_element=pg_Result($reach1,$j,1);
                    $additional_element=pg_Result($reach1,$j,2);
               echo("title : $title primary_element :$primary_element<BR>");

}}
?>










