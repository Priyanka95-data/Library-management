<HTML>
  
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">

	<HR>
	<BR><BR>
	<DIV ALIGN=CENTER>
	<H1>Please Verify The Information. <H1>
	</DIV>

        <?php
 


  if( $acc_no1 && $bibliographic_level_desc1 && $location1 && $date_of_entry_mm1 && $date_of_entry_dd1 && $date_of_entry_yy1 && $language_code1 && $script1 && $translation_code1 && ($paper1 || $magnetic1 || $film1 || $laser1 || $braille1 || $other1) && $type_of_material_desc1 && $title_bk1 && $language_code_title_bk1 && $script_title_bk1 && $entry_element1 && $role_type1 && $date_of_publication_mm1 && $date_of_publication_dd1 && $date_of_publication_yy1 )

{ 
                 
            echo("<FORM ACTION=bookdatabase.php METHOD=POST>");
        	$database = pg_connect("dbname=lms user=pro password=pro");

if($invoice_no1 != 0)
{	
$invoice=0;



    $result=pg_Exec($database,"SELECT invoice_no from invoice_details where invoice_no= $invoice_no1  ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $invoice=pg_Result($result,$i,0);

        }
    echo("<INPUT TYPE=hidden VALUE='$invoice ' NAME=invoice >");
if($invoice == 0){
	 echo("<TABLE ALIGN=CENTER><TR><TD>");

         echo("<b> Name Of Grant :</b></TD><TD>");
         echo("<INPUT NAME=grant TYPE=text SIZE=15 MAXLENGTH = 300><BR>");
	 echo("</TD></TR><TR><TD>");

echo(" <b>Invoice Date * :</b></TD><TD><INPUT NAME='invoicedate' TYPE='text' SIZE='10' MAXLENGTH='10' ><BR></TD></TR><TR><TD> <b>Arrival Date * :</b> </TD><TD>  <INPUT NAME='arrivaldate' TYPE='text' SIZE='10' MAXLENGTH='10' ><BR></TD></TR></TABLE>");


}




$order=0;



    $result=pg_Exec($database,"SELECT order_no from order_now where order_no= '$orderno'  ");
        
        for($i=0; $i<pg_NumRows($result);$i++) {
                $order=pg_Result($result,$i,0);
        }

    echo("<INPUT TYPE=hidden VALUE='$order' NAME=order>");
// if($order == 0)

// echo("<b>Please Enter The Details Of Order No.</b>");
// exit;



            ///////////////

$total=$copies * $amt;
    echo("<INPUT TYPE=hidden VALUE='$total' NAME=total >");
$net = $total - $discount;
    echo("<INPUT TYPE=hidden VALUE='$discount' NAME=discount >"); 
 $p1=$role_type1;

}
else
{
    $invoice_no1 = 0;
}
           $subject_desc1=$subject_desc1.$subject_desc2;
//echo("ooo pp::$publisher_details");
//echo("ooo pp::$distributor_details");
if($publisher_details != 'NULL##NULL##NULL'){
	ereg("([A-Za-z0-9]*)([A-Za-z0-9]*)([A-Za-z0-9]*)",$publisher_details,$register);
	$publisher_name2=trim($register[1]);
	$place_of_publisher2=trim($register[2]);
	$address_of_publisher2=trim($register[3]);
//	$country_of_publisher2=trim($register[4]);
}
if($distributor_details != 'NULL##NULL##NULL'){
	ereg("([A-Za-z0-9]*)##([A-Za-z0-9]*)##([A-Za-z0-9]*)",$distributor_details,$register);
	$name_of_distributor2=trim($register[1]);
	$place_of_distributor2=trim($register[2]);
	$address_of_distributor2=trim($register[3]);
//	$country_of_distributor2=trim($register[4]);
}

if($name_of_corporate_body2 != 'NULL')
{
  $name_of_corporate_body1=$name_of_corporate_body2;
}
if($parent_body_name2 != 'NULL')
{
  $parent_body_name1=$parent_body_name2;
}
if($address_of_corporate_body2 != 'NULL')
{
  $address_of_corporate_body1=$address_of_corporate_body2;
}
if($coutry_of_corporate_body2 != 'null')
{
  $country_of_corporate_body1=$country_of_corporate_body2;
}
if($role_of_corporate_body2 != 'null')
{
  $role_of_corporate_body1=$role_of_corporate_body2;
}
if($publisher_name2)
{
  $publisher_name1=$publisher_name2;
}
if($place_of_publisher2)
{
  $place_of_publisher1=$place_of_publisher2;
}
if($address_of_publisher2)
{
  $address_of_publisher1=$address_of_publisher2;
}
if( $country_of_publisher)
{
  $country_of_publisher1=$country_of_publisher2;
}
if( $name_of_distributor2)
{
  $name_of_distributor1=$name_of_distributor2;
}
if( $place_of_distributor2 )
{
  $place_of_distributor1=$place_of_distributor2;
}
if( $address_of_distributor2)
{
  $address_of_distributor1=$address_of_distributor2;
}
if( $country_of_distributor2)
{
  $country_of_distributor1=$country_of_distributor2;
}
if($language_code_parallel_title2 != 'null')
{
  $language_code_parallel_title1=$language_code_parallel_title2;
}
if($script_parallel_title2 != 'NULL')
{
  $script_parallel_title1=$script_parallel_title2;
}
else
{
$script_parallel_title1='Roman';
}
if($language_code_other_title1 != "null")
{
  $language_code_other_title1=$language_code_other_title2;
}
if($type_of_title2 != 'NULL')
{
  $type_of_title1=$type_of_title2;
}
else
{
 $type_of_title1='Sub Title';
}

 	    echo("<INPUT TYPE=hidden VALUE='$record_id1' NAME=record_id >");
	    $record_id=$record_id1;		 	
 	    echo("<INPUT TYPE=hidden VALUE='$bibliographic_level_desc1' NAME=bibliographic_level_desc >");
	    $bibliographic_level_desc=$bibliographic_level_desc1;	
 	    echo("<INPUT TYPE=hidden VALUE='$location1' NAME='location' >");
	    $location=$location1;
 	    echo("<INPUT TYPE=hidden VALUE='$language_code1' NAME=language_code >");
	    $language_code=$language_code1;
 	    echo("<INPUT TYPE=hidden VALUE='$script1' NAME=script >");
	    $script=$script1;
 	    echo("<INPUT TYPE=hidden VALUE='$translation_code1' NAME=translation_code >");
	    $translation_code=$translation_code1;
 	    echo("<INPUT TYPE=hidden VALUE='$type_of_material_desc1' NAME=type_of_material_desc >");
	    $type_of_material_desc=$type_of_material_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$isbn1' NAME=isbn >");
	    $isbn=$isbn1;
 	    echo("<INPUT TYPE=hidden VALUE='$qualifier1' NAME=qualifier >");
	    $qualifier=$qualifier1;
 	    echo("<INPUT TYPE=hidden VALUE='$document_no1' NAME=document_no >");
	    $document_no=$document_no1;
 	    echo("<INPUT TYPE=hidden VALUE='$title_bk1' NAME=title_bk >");
	    $title_bk=$title_bk1;
 	    echo("<INPUT TYPE=hidden VALUE='$statt_of_resp_ti_bk1' NAME=statt_of_resp_ti_bk >");
	    $statt_of_resp_ti_bk=$statt_of_resp_ti_bk1;	
 	    echo("<INPUT TYPE=hidden VALUE='$language_code_title_bk1' NAME=language_code_title_bk >");
	    $language_code_title_bk=$language_code_title_bk1;
 	    echo("<INPUT TYPE=hidden VALUE='$script_title_bk1' NAME=script_title_bk >");
	    $script_title_bk=$script_title_bk1;
 	    echo("<INPUT TYPE=hidden VALUE='$parallel_title1' NAME=parallel_title >");
	    $parallel_title=$parallel_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$statement_of_resp1' NAME=statement_of_resp >");
	    $statement_of_resp=$statement_of_resp1;
 	    echo("<INPUT TYPE=hidden VALUE='$language_code_parallel_title1' NAME=language_code_parallel_title >");
	    $language_code_parallel_title=$language_code_parallel_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$script_parallel_title1' NAME=script_parallel_title >");
	    $script_parallel_title=$script_parallel_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$other_title1' NAME=other_title >");
	    $other_title=$other_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$type_of_title1' NAME=type_of_title >");
	    $type_of_title=$type_of_title1;

 	    echo("<INPUT TYPE=hidden VALUE='$language_code_other_title1' NAME=language_code_other_title >");
	    $language_code_other_title=$language_code_other_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$uniform_title1' NAME=uniform_title >");
	    $uniform_title=$uniform_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$language_code_uniform_title1' NAME=language_code_uniform_title >");
	    $language_code_uniform_title=$language_code_uniform_title1;
 	    echo("<INPUT TYPE=hidden VALUE='$forms_of_statt1' NAME=forms_of_statt >");
	    $forms_of_statt=$forms_of_statt1;
 	    echo("<INPUT TYPE=hidden VALUE='$statt_of_resp_bk1' NAME=statt_of_resp_bk >");
	    $statt_of_resp_bk=$statt_of_resp_bk1;
 	    echo("<INPUT TYPE=hidden VALUE='$role_type11' NAME=role_type1 >");
	    $role_type1=$role_type11;
 	    echo("<INPUT TYPE=hidden VALUE='$entry_element_author1' NAME=entry_element_author >");
	    $entry_element_author=$entry_element_author1;
 	    echo("<INPUT TYPE=hidden VALUE='$secondary_element_author1' NAME=secondary_element_author >");
	    $secondary_element_author=$secondary_element_author1;
 	    echo("<INPUT TYPE=hidden VALUE='$additional_element_author1' NAME=additional_element_author >");
	    $additional_element_author=$additional_element_author1;
 	    echo("<INPUT TYPE=hidden VALUE='$entry_element1' NAME=entry_element >");
	    $entry_element=$entry_element1;
 	    echo("<INPUT TYPE=hidden VALUE='$secondary_element1' NAME=secondary_element >");
	    $secondary_element=$secondary_element1;
 	    echo("<INPUT TYPE=hidden VALUE='$additional_element1' NAME=additional_element >");
	    $additional_element=$additional_element1;
if(role_type2 == " ")
{
$p1=$role_type2;
}
 	    echo("<INPUT TYPE=hidden VALUE='p1' NAME=role_type >");
	    $role_type=$p1;

 	    echo("<INPUT TYPE=hidden VALUE='$name_of_corporate_body1' NAME=name_of_corporate_body >");
	    $name_of_corporate_body=$name_of_corporate_body1;
 	    echo("<INPUT TYPE=hidden VALUE='$parent_body_name1' NAME=parent_body_name >");
	    $parent_body_name=$parent_body_name1;
 	    echo("<INPUT TYPE=hidden VALUE='$address_of_corporate_body1' NAME=address_of_corporate_body >");
	    $address_of_corporate_body=$address_of_corporate_body1;
 	    echo("<INPUT TYPE=hidden VALUE='$country_of_corporate_body1' NAME=country_of_corporate_body >");
	    $country_of_corporate_body=$country_of_corporate_body1;
 	    echo("<INPUT TYPE=hidden VALUE='$role_of_corporate_body1' NAME=role_of_corporate_body >");
	    $role_of_corporate_body=$role_of_corporate_body1;
 	    echo("<INPUT TYPE=hidden VALUE='$entry_element_meet1' NAME=entry_element_meet >");
	    $entry_element_meet=$entry_element_meet1;
		$no_of_element1=0;
 	    echo("<INPUT TYPE=hidden VALUE='$no_of_element1' NAME=no_of_element >");
	    $no_of_element=$no_of_element1;  
 	    echo("<INPUT TYPE=hidden VALUE='$country_of_meet1' NAME=country_of_meet >");
	    $country_of_meet=$country_of_meet1;
 	    echo("<INPUT TYPE=hidden VALUE='$sponsor_name1' NAME=sponsor_name >");
	    $sponsor_name=$sponsor_name1;
 	    echo("<INPUT TYPE=hidden VALUE='$place_of_meet1' NAME=place_of_meet >");
	    $place_of_meet=$place_of_meet1;
 	    echo("<INPUT TYPE=hidden VALUE='$publisher_name1' NAME= publisher_name>");
	    $publisher_name=$publisher_name1;
 	    echo("<INPUT TYPE=hidden VALUE='$place_of_publisher1' NAME=place_of_publisher >");
	    $place_of_publisher=$place_of_publisher1;
 	    echo("<INPUT TYPE=hidden VALUE='$address_of_publisher1' NAME=address_of_publisher >");
	    $address_of_publisher=$address_of_publisher1;
 	    echo("<INPUT TYPE=hidden VALUE='$country_of_publisher1' NAME=country_of_publisher >");
	    $country_of_publisher=$country_of_publisher1;
 	    echo("<INPUT TYPE=hidden VALUE='$name_of_distributor1' NAME=name_of_distributor >");
	    $name_of_distributor=$name_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$place_of_distributor1' NAME=place_of_distributor >");
	    $place_of_distributor=$place_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$address_of_distributor1' NAME=address_of_distributor >");
	    $address_of_distributor=$address_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$country_of_distributor1' NAME=country_of_distributor >");
	    $country_of_distributor=$country_of_distributor1;
 	    echo("<INPUT TYPE=hidden VALUE='$pagination_desc1' NAME=pagination_desc >");
	    $pagination_desc=$pagination_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$priliminary1' NAME=priliminary >");
	    $priliminary=$priliminary1;
 	    echo("<INPUT TYPE=hidden VALUE='$textual1' NAME=textual >");
	    $textual=$textual1;
 	    echo("<INPUT TYPE=hidden VALUE='$illustration1' NAME=illustration >");
	    $illustration=$illustration1;
 	    echo("<INPUT TYPE=hidden VALUE='$l1' NAME=l >");
	    $l=$l1;
 	    echo("<INPUT TYPE=hidden VALUE='$h1' NAME=h >");
	    $h=$h1;	
 	    echo("<INPUT TYPE=hidden VALUE='$d1' NAME=d >");
	    $d=$d1;
 	    echo("<INPUT TYPE=hidden VALUE='$accomp_material1' NAME=accomp_material >");
	    $accomp_material=$accomp_material1;
 	    echo("<INPUT TYPE=hidden VALUE='$price1' NAME=price >");
	    $price=$price1;
 	    echo("<INPUT TYPE=hidden VALUE='$currency_desc1' NAME=currency_desc >");
	    $currency_desc=$currency_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$binding1' NAME=binding >");
	    $binding=$binding1;
 	    echo("<INPUT TYPE=hidden VALUE='$name_of_vendor1' NAME=name_of_vendor >");
	    $name_of_vendor=$name_of_vendor1;
 	    echo("<INPUT TYPE=hidden VALUE='$city1' NAME=city >");
	    $city=$city1;
 	    echo("<INPUT TYPE=hidden VALUE='$invoice_no1' NAME=invoice_no >");
	    $invoice_no=$invoice_no1;
 	    echo("<INPUT TYPE=hidden VALUE='$amt_paid1' NAME=amt_paid >");
	    $amt_paid=$amt_paid1;
 	    echo("<INPUT TYPE=hidden VALUE='$name_of_grant1' NAME=name_of_grant >");
	    $name_of_grant=$name_of_grant1;
 	    echo("<INPUT TYPE=hidden VALUE='$part_statt1' NAME=part_statt >");
	    $part_statt=$part_statt1;
 	    echo("<INPUT TYPE=hidden VALUE='$volume_or_part_no1' NAME=volume_or_part_no >");
	    $volume_or_part_no=$volume_or_part_no1;
 	    echo("<INPUT TYPE=hidden VALUE='$issn1' NAME=issn >");
	    $issn=$issn1;
 	    echo("<INPUT TYPE=hidden VALUE='$series_name1' NAME=series_name >");
	    $series_name=$series_name1;
 	    echo("<INPUT TYPE=hidden VALUE='$statt_of_resp_sr_stt1' NAME=statt_of_resp_sr_stt >");
	    $statt_of_resp_sr_stt=$statt_of_resp_sr_stt1;
 	    echo("<INPUT TYPE=hidden VALUE='$note1' NAME= note>");
	    $note=$note1;
 	    echo("<INPUT TYPE=hidden VALUE='$bibliographic_note1' NAME=bibliographic_note >");
	    $bibliographic_note=$bibliographic_note1;
 	    echo("<INPUT TYPE=hidden VALUE='$notation1' NAME=notation >");
	    $notation=$notation1;
 	    echo("<INPUT TYPE=hidden VALUE='$edition_no1' NAME=edition_no >");
	    $edition_no=$edition_no1;
 	    echo("<INPUT TYPE=hidden VALUE='$identification1' NAME=identification >");
	    $identification=$identification1;
 	    echo("<INPUT TYPE=hidden VALUE='$c_s_c_desc1' NAME=c_s_c_desc >");
	    $c_s_c_desc=$c_s_c_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$subject_desc1' NAME=subject_desc >");
	    $subject_desc=$subject_desc1;
 	    echo("<INPUT TYPE=hidden VALUE='$acc_no1' NAME=acc_no >");
	    $acc_no=$acc_no1;

        $date_of_entry_mm1 .= "/";
        $date_of_entry_dd1 .= "/";
	$date_of_entry1 .=$date_of_entry_mm1;
        $date_of_entry1 .=$date_of_entry_dd1;
        $date_of_entry1 .=$date_of_entry_yy1;

if( $o_no_mm1 && $o_no_dd1 && o_no_yy1){
        $o_no_mm1 .= "/";
        $o_no_dd1 .= "/";
	$o_no1 .=$o_no_mm1;
        $o_no1 .=$o_no_dd1;
        $o_no1 .=$o_no_yy1;
}
else{
	$o_no1="10/10/1010";
}
if ($o_no1 != "10/10/1010"){
	$res=pg_Exec($database,"SELECT * FROM order_n WHERE order_no='$orderno' AND date='$o_no1'");
	if(pg_NumRows($res)==0){
		$res=pg_Exec($database,"INSERT INTO order_n VALUES('$orderno','$o_no1')");
}
}

 	    echo("<INPUT TYPE=hidden VALUE='$date_of_entry1' NAME=date_of_entry >");
	    $date_of_entry=$date_of_entry1;




        $date_of_price_mm1 .= "/";
        $date_of_price_dd1 .= "/";
	$date_of_price1 .=$date_of_price_mm1;
        $date_of_price1 .=$date_of_price_dd1;
        $date_of_price1 .=$date_of_price_yy1;
        if($date_of_price1 == '//')
        {
           $date_of_price1 = '10/10/1010';
        }

 	    echo("<INPUT TYPE=hidden VALUE='$date_of_price1' NAME=date_of_price >");
	    $date_of_price=$date_of_price1;




        $date_of_invoice_mm1 .= "/";
        $date_of_invoice_dd1 .= "/";
	$date_of_invoice1 .=$date_of_invoice_mm1;
        $date_of_invoice1 .=$date_of_invoice_dd1;
        $date_of_invoice1 .=$date_of_invoice_yy1;
        if($date_of_invoice1 == '//')
        {
           $date_of_invoice1 = '10/10/1010';
        }

 	    echo("<INPUT TYPE=hidden VALUE='$date_of_invoice1' NAME=date_of_invoice >");
	    $date_of_invoice=$date_of_invoice1;
    echo("<INPUT TYPE=hidden VALUE='$paper1' NAME=paper1 >");
    echo("<INPUT TYPE=hidden VALUE='$film1' NAME=film1 >");
    echo("<INPUT TYPE=hidden VALUE='$magnetic1' NAME=magnetic1 >");
    echo("<INPUT TYPE=hidden VALUE='$laser1' NAME=laser1 >");
    echo("<INPUT TYPE=hidden VALUE='$braille1' NAME=braille1 >");
    echo("<INPUT TYPE=hidden VALUE='$other1' NAME=other1 >");
    echo("<INPUT TYPE=hidden VALUE='$reference' NAME=reference >");
    echo("<INPUT TYPE=hidden VALUE='$study' NAME=study >");
    echo("<INPUT TYPE=hidden VALUE='$copies' NAME=copies >");
    echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt >");
    echo("<INPUT TYPE=hidden VALUE='$net' NAME=net >");
    echo("<INPUT TYPE=hidden VALUE='$orderno' NAME=orderno >");


        $date_mm1 .= "/";
        $date_dd1 .= "/";
	$date1 .=$date_mm1;
        $date1 .=$date_dd1;
        $date1 .=$date_yy1;
        if($date1 == '//')
        {
           $date1 = '10/10/1010';
        }


        echo("<INPUT TYPE=hidden VALUE='$date1' NAME=date>");
        $date=$date1;
   




        $date_of_meeting_mm1 .= "/";
        $date_of_meeting_dd1 .= "/";
	$date_of_meeting1 .=$date_of_meeting_mm1;
        $date_of_meeting1 .=$date_of_meeting_dd1;
        $date_of_meeting1 .=$date_of_meeting_yy1;
        if($date_of_meeting1 == '//')
        {
           $date_of_meeting1 = '10/10/1010';
        }



 	    echo("<INPUT TYPE=hidden VALUE='$date_of_meeting1' NAME=date_of_meeting >");
	    $date_of_meeting=$date_of_meeting1;




        $date_of_publication_mm1 .= "/";
        $date_of_publication_dd1 .= "/";
	$date_of_publication1 .=$date_of_publication_mm1;
        $date_of_publication1 .=$date_of_publication_dd1;
        $date_of_publication1 .=$date_of_publication_yy1;



 	    echo("<INPUT TYPE=hidden VALUE='$date_of_publication1' NAME=date_of_publication >");
	    $date_of_publication=$date_of_publication1;

   

echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER><TR><TD>");

if($bibliographic_level_desc){
echo("Bibliographic Level :$bibliographic_level_desc</TD><TD>");
}
if($location){
   echo("Location :$location</TD></TR>");
}
if($date_of_entry1){
   echo("<TR><TD>Date of Entry : $date_of_entry1</TD><TD>");            
}
if($language_code){
   echo("Language :$language_code</TD></TR>");
}
echo("<TR>");
if($script){
   echo("<TD>Script :$script</TD>");
}
if($translation_code){
   echo("<TD>Translation :$translation_code</TD>");
}
echo("</TR><TR>");
if($paper1 OR $film1 OR $magnetic1 OR $braille1){
   echo("<TD>Physical Medium :$paper1 $film1 $magnetic1
 $braille1</TD>");
}
if($type_of_material_desc){
    echo("<TD>Type Of Material :$type_of_material_desc</TD>");
}
echo("</TR><TR>");
if($isbn){
   echo("<TD>ISBN :$isbn</TD>");
}
echo("</TR><TR>");
if($qualifier){
   echo("<TD>Qualification(Optional) :$qualifier</TD>");
}
if($document_no){
   echo("<TD>Document No. :$document_no</TD>");
}
echo("</TR><TR>");
if($title_bk){
$title_bk=ucfirst($title_bk);
   echo("<TD>Title :$title_bk</TD>");
}
if($statt_of_resp_ti_bk){
   echo("<TD>Statement Of Responsibility :$statt_of_resp_ti_bk</TD>");
}
echo("</TR><TR>");
if($language_code_title_bk){
   echo("<TD>Language :$language_code_title_bk</TD>");
}
if($script_title_bk){
   echo("<TD>Script :$script_title_bk</TD>");
}
echo("</TR><TR>");
if($parallel_title){
$parallel_title=ucfirst($parallel_title);
    echo("<TD>Parallel Title :$parallel_title</TD>");
}
if($statement_of_resp){
   echo("<TD>Statement Of Responsibility :$statement_of_resp</TD>"); 
}
echo("</TR><TR>");
if($language_code_parallel_title){   
    echo("<TD>Language :$language_code_parallel_title</TD>");
}
if($script_parallel_title){
    echo("<TD>Script :$script_parallel_title</TD>");
}
echo("</TR><TR>");
if($other_title){
	$other_title=ucfirst($other_title);
   echo("<TD>Other Title :$other_title</TD>");
}
if($type_of_title){
   echo("<TD>Type Of Title :$type_of_title</TD>");
}
echo("</TR><TR>");
if($language_code_other_title){
   echo("<TD>Language :$language_code_other_title</TD>");
}
if($uniform_title){
$uniform_title=ucfirst($uniform_title);
   echo("<TD>Uniform Title :$uniform_title</TD>");
}
echo("</TR><TR>");
if($language_code_uniform_title){
   echo("<TD>Language :$language_code_uniform_title</TD>" );
}
if($forms_of_statt){
   echo("<TD>Edition Statement :$forms_of_statt</TD>" );
}
echo("</TR><TR>");
if($statt_of_resp_bk){ 
  echo("<TD>Statement Of Responsibility :$statt_of_resp_bk</TD>" );
}
if($role_type){
   echo("<TD>Role :$role_type</TD>");
}
echo("</TR>");
   echo("<TR><TD>NAME OF PERSON (Except Author)  :</TD></TR><TR>");
if($entry_element){
   echo("<TD>Entry Element :$entry_element</TD>" );
}
if($secondary_element){
   echo("<TD>Secondary Element :$secondary_element</TD>");
}
echo("</TR><TR>");
if($additional_element){
   echo("<TD>Additional Element :$additional_element</TD>" );
}
if($date1){
   echo("<TD>Date(date of birth,date of death,etc) : $date1</TD>");       
}
echo("</TR><TR>");
if($role_type){
   echo("<TD>Role :$role_type</TD>");   
}
if($name_of_corporate_body){
   echo("<TD>Name Of Corporate Body :$name_of_corporate_body</TD>");
}
echo("</TR><TR>");
if($parent_body_name){
   echo("<TD>Name Of Parent Body :$parent_body_name</TD>"); 
}
if($address_of_corporate_body){
   echo("<TD>Address :$address_of_corporate_body</TD>"); 
}
echo("</TR><TR>");
if($country_of_corporate_body){
   echo("<TD>Country :$country_of_corporate_body</TD>");
}
if($role_of_corporate_body){
   echo("<TD>Role :$role_of_corporate_body</TD>" );
}
echo("</TR><TR>");
   echo("<TD>NAME OF MEETING / CONFERENCE :</TD></TR><TR>");
if($entry_element_meet){
   echo("<TD>Entry Element :$entry_element_meet</TD>");
}
if($no_of_element){
   echo("<TD>No. Of Meeting :$no_of_element</TD>" );
}
echo("</TR><TR>");
if($country_of_meet){
   echo("<TD>Country :$country_of_meet</TD>");
}
if($sponsor_name){
   echo("<TD>Sponsor Name :$sponsor_name</TD>" );
}
echo("</TR><TR>");
if($place_of_meet){
   echo("<TD>Place :$place_of_meet</TD>");
}
if($date_of_meeting1){
   echo("<TD>Date : $date_of_meeting1</TD>");        
}
   echo("</TR><TR><TD>PLACE AND NAME OF PUBLISHER :</TD></TR><TR>");
if($publisher_name){
   echo("<TD>Name :$publisher_name</TD>" );
}
if($place_of_publisher){
   echo("<TD>Place :$place_of_publisher</TD>"); 
}
echo("</TR><TR>");
if($address_of_publisher){
   echo("<TD>Address :$address_of_publisher</TD>");
}
if($country_of_publisher){
    echo("<TD>Country :$country_of_publisher</TD>" );
}
   echo("</TR><TR><TD>PLACE AND NAME OF DISTRIBUTOR :</TD></TR><TR>");
if($name_of_distributor){
   echo("<TD>Name :$name_of_distributor</TD>" );
}
if($place_of_distributor){
   echo("<TD>Place :$place_of_distributor</TD>" ); 
}
echo("</TR><TR>");
if($address_of_distributor){
   echo("<TD>Address :$address_of_distributor</TD>");
}
if($country_of_distributor){
   echo("<TD>Country :$country_of_distributor</TD>" );
}
echo("</TR><TR>");
if($date_of_publication){
   echo("<TD>Date Of Publication :$date_of_publication1</TD>" );
}
   echo("</TR><TR><TD>PHYSICAL DESCRIPTION :</TD></TR><TR>" );
if($pagination_desc){
   echo("<TD>Pagination_Description :$pagination_desc</TD>" );
}
if($priliminary){
   echo("<TD>preliminary (Optional) :$priliminary</TD>" );
}
echo("</TR><TR>");
if($textual){
   echo("<TD>Textual :$textual</TD>" );
}
if($illustration){
   echo("<TD>illustration :$illustration</TD>" );
}
echo("</TR><TR>");
if($l OR $d OR $h){
   echo("<TD>Dimensions :$l $d $h</TD>" );
}
if($accomp_material){
   echo("<TD>Accompanying Material :$accomp_material</TD>");
}
   echo("</TR><TR><TD>PRICE AND BINDING</TD></TR><TR>" );
if($price){
   echo("<TD>Price :$price</TD>" );             
}
echo("</TR><TR>");
if($date_of_price1){
   echo("<TD>Date Of Price : $date_of_price1</TD>");
}
if($binding){
    echo("<TD>Binding :$binding</TD>");
}
   echo("</TR><TR><TD>INVOICE DETAILS :</TD></TR><TR>" );
if($name_of_vendor){
   echo("<TD>Name Of Vendor :$name_of_vendor</TD>" );
}
if($city){
   echo("<TD>City :$city</TD>" );
}
echo("</TR><TR>");
if($invoice_no){
   echo("<TD>Invoice No. :$invoice_no</TD>" );
}
if($date_of_invoice1){
   echo("<TD>Date Of Invoice :$date_of_invoice1</TD>" );             
}
echo("</TR><TR>");
if($currency_of_invoice OR $amt_paid){
   echo("<TD>Amount Paid :$currency_of_invoice $amt_paid</TD>" );
}
if($name_of_grant){
   echo("<TD>Name Of Grant :$name_of_grant</TD>" );
}
   echo("</TR><TR><TD>PART STATT :</TD></TR><TR>" );
if($part_statt){
   echo("<TD>Title Of Volume/Part :$part_statt</TD>");
}
if($volume_or_part_no){
   echo("<TD>Volume/Part No. :$volume_or_part_no</TD>");
}
   echo("</TR><TR><TD>DETAILS OF SERIES :</TD></TR><TR>");
if($issn){
   echo("<TD>ISSN :$issn</TD>");
}
if($series_name){
   echo("<TD>Series Name :$series_name</TD>");
}
echo("</TR><TR>");
if($statt_of_resp_sr_stt){
   echo("<TD>Statement Of Responsibility :$statt_of_resp_sr_stt</TD>");
}
if($note){
$note=strtolower($note);
   echo("<TD>Note :$note</TD>");
}
echo("</TR><TR>");
if($bibliographic_note){
   echo("<TD>Note On Bibliographic :$bibliographic_note</TD>");
}
   echo("</TR><TR><TD>CLASSIFICATION SCHEME NOTATION </TD></TR><TR>" );
if($notation){
   echo("<TD>Notation :$notation</TD>");
}
echo("</TR><TR>");
if($edition_no){
   echo("<TD>edition_no :$edition_no</TD>" );
}
if($identification){
   echo("<TD>Identification Of Classification Code :$identification</TD>" );
}
echo("</TR><TR>");
if($c_s_c_desc){
   echo("<TD>Classification Scheme Code :$c_s_c_desc</TD>");
}
if($subject_desc){
$subject_desc=$subject_desc;
   ereg("([0-9\.]*)([A-Za-z0-9\/\.]*)",$subject_desc,$reg);
	$pick=$reg[1].' ';
	$pick=$pick.$reg[2];
   echo("<TD>Call Number :$pick</TD>" );
}
echo("</TR><TR>");
if($acc_no){
   echo("<TD>Accession No. :$acc_no</TD></TR>");
}
   echo("</TABLE>");           
echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id>"); 
	echo("<BR><DIV ALIGN=CENTER>");
	echo ("<INPUT NAME=back TYPE=submit VALUE=Enter>");
	
	echo("</DIV></FORM>");
	}
        else
        {
	echo("<DIV ALIGN=CENTER> <H1> Inconvenient Data. </H1></DIV>");
        }

       	echo("\t");
 	echo("<DIV ALIGN=CENTER><FORM ACTION=book.php>");
	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id>"); 
	echo("<INPUT NAME='Go Back' TYPE=submit VALUE='Go Back'></DIV><BR>");
	echo("</FORM><HR>");

        ?>
</BODY>
</HTML> 
      


