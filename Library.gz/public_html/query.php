<HTML>
<HEAD><TITLE>Query Page</TITLE></head>
<BODY bgcolor="#8AFF90" text="#316431">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {


	echo("<H1 ALIGN=CENTER>Query</H1><BR><HR><BR>"); 

		echo("<FORM METHOD=POST>");
        //        echo("<INPUT TYPE=HIDDEN NAME='admin_id' VALUE='$admin_id'>");
		echo("<BR><H3 ALIGN=CENTER>Enter your query here</H3>");
		echo("<DIV ALIGN=CENTER>");
 		echo("<TEXTAREA ROWS=15 COLS=60 NAME='Input'></TEXTAREA>");
		echo("<BR><TABLE><TR><TD>");
		echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE='Submit'>");
		echo("</TD><TD>");
		echo("<INPUT TYPE=RESET NAME=Reset VALUE='Reset'>");
		echo("</TD></TR></TABLE></DIV><BR>");
		echo("</FORM>");
	if($Submit){
		echo("<BR><TABLE><TR><TD>");
		$Imput=stripslashes($Input);
		echo("<H3>The given query is :</H3></TD><TD>");
		echo ("<FONT COLOR=BLUE><U><B> $Imput </B></U></FONT>");
		echo("</TD></TR></TABLE><BR>");

		$data=pg_connect("dbname=lms user=pro password=pro");
		$result=pg_Exec($data,"$Imput");
		$cols=pg_numfields($result);
        echo("<TABLE ALIGN=CENTER BORDER=2 WIDTH='100%'>");

        echo("<TR bgcolor='B0C4DE'>"); 
        for($i=0;$i<pg_NumFields($result);$i++){
			$queryfieldname=pg_fieldname($result,$i);
                echo("<TH>");
				echo $queryfieldname;
                echo("</TH>");
        }
        echo("</TR>");        
                    
		for($i=0;$i<pg_NumRows($result);$i++){
			$query=pg_fetch_array($result,$i);
			echo("<TR ALIGN=center>");
			for($j=0;$j < $cols;$j++){
                echo("<TD>");
				echo $query[$j];
				echo("</TD>");
		}
		echo("</TR>");
	}
	echo("</TABLE>");	
	}	

    echo("<BR><HR>");
    echo("<DIV ALIGN=RIGHT><TABLE ALIGN=CENTER WIDTH='100%'><TR><TD>");
    echo("<A HREF=admin.php><b>Return to home page<b></A></TD><TD>");
    echo("<A HREF=login.php><b>Logout</b></A></TD></TR></TABLE>"); 
    echo("</DIV>");

}else{
    echo("<BR><HR>");
    echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
    echo("<DIV ALIGN=RIGHT>");
    echo("<A HREF=login.html><b>Logout</b></A>"); 
    echo("</DIV>");
}



?>
</BODY>
</HTML>
