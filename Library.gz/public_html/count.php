<?php


 $rest1=pg_Exec($database,"SELECT count(rec_acc.record_id) from rec_acc,in_or_out,common_to_books_and_thesis where rec_acc.record_id = common_to_books_and_thesis.record_id and rec_acc.acc_no = in_or_out.acc_no and rec_acc.record_id='$record'");

for($z=0;$z<pg_NumRows($rest1);$z++){
		    $left=pg_Result($rest1,$z,0);

}

?>
