<HTML>
<HEAD><TITLE>Import ISO 2709 data</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">

<DIV ALIGN = CENTER> <H1>Import ISO 2709 data</H1></DIV>
<HR><BR><BR>

<?php

if(copy($isodatafile, "/tmp/isodatafile") ) {
    
    echo("<H2>Importing ISO data</H2><BR>");

    //system("cat $isodatafile | /home/pro/public_html/iso.pl"); 
    passthru("/home/pro/public_html/iso.pl < $isodatafile"); 
    //system("/home/pro/public_html/tmp < $isodatafile"); 
    //    passthru("cat /tmp/isodatafile | /home/pro/public_html/tmp"); 

echo("<H2>Done</H2><BR>");

}else {
    echo("OOPS!");
}

?>