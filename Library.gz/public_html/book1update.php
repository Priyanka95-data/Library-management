<HTML>
<HEAD><TITLE>The Updates are reflected here</title><HEAD>
<BODY BGCOLOR="#0dba5">
<?
include "header.inc";
include "common.php";
include "array.php";
include "descrption.php";
if(authenticate_user($name,$password,$option)){
?>
<HR><br>
<h1 align=center><big>Please Check before making the Commits </big></h1>
<hr>
<FORM ACTION=updatedatabase.php METHOD=POST>
<TABLE BORDER=1 WIDTH=100% ALIGN=CENTER><TR>
<? label_names("Bibliographic Level");
 if($bibliographic_level_desc==$bibliographic_level_desc1){ 
	label_values($bibliographic_level_desc1,0); 
} else { 
	label_values($bibliographic_level_desc1);
	$set_bibliographic_level=1;
 }
label_names("Date Of Entry");
$date_of_entry_mm1=$month[$date_of_entry_mm1];
if($date_of_entry==($date_of_entry1=$date_of_entry_yy1."-".$date_of_entry_mm1."-".$date_of_entry_dd1)){
	label_values($date_of_entry1,0);
	} else {
	label_values($date_of_entry1);
	$set_date_of_entry=1;
}
label_names("Language Code");
if($language_desc_id == $language_code1){
	label_values($language_code1,0);
} else {
	label_values($language_code1);
	$set_language_code=1;
}
label_names("Physical Medium");
$physical_medium_desc_chk=1; // to tell it to change to red
for($i=0;$i<count($physical_medium_desc1);$i++){
	if(in_array($physical_medium_desc1[$i],$physical_medium_desc)){
		$physical_medium_desc_chk=0;
	} else {
		$physical_medium_desc_chk=1;
		$set_phy_desc=1;
		break;
	}
 }
label_values_for($physical_medium_desc1,$physical_medium_desc_chk);
label_names("Type Of Material");
if($type_of_material_desc1==$type_of_material_desc){
	label_values($type_of_material_desc1,0);	
} else {
	label_values($type_of_material_desc1);
	$set_tomd=1;
}
label_names("Title Of Book");
if($title_bk1==$title_bk){
	label_values($title_bk1,0);
} else {
	label_values($title_bk1);
	$set_title_bk=1;
}
label_names("Statement Of Responsibility");
if($statt_of_resp_ti_bk1==$statt_of_resp_ti_bk){
	label_values($statt_of_resp_ti_bk1,0);
} else {
	label_values($statt_of_resp_ti_bk1);
	$set_statt_of_resp_ti_bk=1;
} 
label_names("Name Of Person");
for_author_fc($element,$mrole,$additional_element1,$entry_element1,$secondary_element1);
label_names("Date Of Publication");
ereg("^(.+)-(.+)-(.+)$",$date_of_publication,$reg);
if($reg[1]==$date_of_publication_yy1){
	label_values($reg[1],0);
} else {
	label_values($reg[1]);
	$set_date_of_pub=1;
}
label_names("Call Number");
$subject_desca=$subject_desc1." ".$subject_desc2;
$subject_desc1=$subject_desc1.$subject_desc2;
?> <INPUT TYPE=hidden NAME=subject_desc1 VALUE='<?echo $subject_desc1 ?>'> <?
if($subject_desc1==$subject_desc){
	label_values($subject_desca,0);
} else {
	label_values($subject_desca);
	$set_subject_desc=1;
}
label_names("Accession Numbers");
for($i=0;$i<count($acc_no);$i++){
	$aacc_no.=$acc_no[$i].",";
	}
$aacc_no=substr($aacc_no,0,strlen($aacc_no)-1);
if($acc_no1==$aacc_no){
	label_values($acc_no1,0);
} else {
	label_values($acc_no1);
	$set_acc_no=1;
}
label_names("Reference Books");
if($reference==$racc_no){
	label_values($reference,0);
} else {
	label_values($reference);
	$set_reference=1; ?>
	<input type=hidden name=reference value='<? echo $reference ?>'>
	<input type=hidden name=racc_no value='<? echo $racc_no ?>'>
<?
}
label_names("Study Room Books");
if($sacc_no==$study){
	label_values($study,0);
} else {
	label_values($study);
	$set_study=1;
?>
	<INPUT TYPE=hidden name=study VALUE='<? echo $study ?>'>
	<INPUT TYPE=hidden Name=sacc_no VALUE='<? echo $sacc_no ?>'>
<?
}
label_names("ISBN Number");
if($isbn1==$isbn){
	label_values($isbn1,0);
} else {
	label_values($isbn1);
?>	<input type=hidden name=isbn1 value='<? echo $isbn1 ?>'>
<? $set_isbn=1;
}
label_names("Name Of Corporate Body");
$name_of_corp=explode("#",$name_of_corporate_body1);
$chk_nocb=0; // this is to keep it unmarked
for($i=0;$i<count($name_of_corp);$i++){
	if(in_array($name_of_corp[$i],$name_of_corporate_body)){
		$chk_nocb=0; //unmarked is maintained (green color)
	} else {
		$chk_nocb=1; // green => red
		break;
	}
}
if(($name_of_corporate_body2=='NULL') and !$chk_nocb)
{ ?> <TD><FONT> <?
} else {
?>	<TD BGCOLOR=RED><FONT COLOR=WHITE> 
<?
	$set_nocb=1;
} ?> <UL> <?
for($i=0;$i<count($name_of_corp);$i++){
	if($name_of_corporate_body2==NULL){ ?>
		<LI> <? echo $name_of_corporate_body2;
?>		<input type=hidden name=name_of_corporate_body2 value='<? echo $name_of_corporate_body2 ?>'>
<?		break;
	} else { ?>
		<LI> <? echo $name_of_corp[$i];
?>		<INPUT type=hidden name=name_of_corp[] value='<?echo $name_of_corp[$i]?>'>
<?
	}
}
?> </UL></FONT></TD> <?
label_names("Other Title");
if($other_title==$other_title1){
	label_values($other_title1,0);
} else {
	label_values($other_title1);
	$set_other_title=1; ?>
	<input type=hidden name=other_title1 value='<? echo $other_title1 ?>'>
<?
}
label_names("Type Of Title");
if($type_of_title2!=='NULL'){
	label_values($type_of_title2);
?>	<input type=hidden name=type_of_title2 value='<?echo $type_of_title2 ?>'>	
<?	$set_tot=1;
}else if($t_o_t_desc==$type_of_title1) {
	label_values($type_of_title1,0);
} else {
	label_values($type_of_title1);
?>	<INPUT type=hidden name=type_of_title1 value='<? echo $type_of_title1 ?>'>	
<?	
	$set_tot=1;
}
label_names("Edition Statement");
if($forms_of_statt1==$forms_of_edition_statt_bk){
	label_values($forms_of_statt1,0);
} else {
	label_values($forms_of_statt1);
?>	<INPUT TYPE=hidden name=forms_of_statt1 value=<? echo $forms_of_statt1 ?>'>
<?	$set_form_of_statt=1;
}
$pud_details=explode("##",$publisher_details);
$set_fpn=for_publisher_distri_name("Publisher",$pub_name,$publisher_name1,$pud_details[0]);
?> <input type=hidden name=pub_name value='<? echo $pub_name?>'>
   <input type=hidden name=publisher_name1 value='<? echo $publisher_name1 ?>'>
<?
$set_fpp=for_publisher_distri_place("Publisher",$place_of_pub,$place_of_publisher1,$pud_details[1]);
?> <input type=hidden name=addr_of_publ value='<? echo $addr_of_publ?>'>
   <input type=hidden name=place_of_publisher1 value='<? echo $place_of_publisher1 ?>'>
   <input type=hidden name=place_of_pub value'<? echo $place_of_pub?>'>
<?
$set_fpa=for_publisher_distri_addr("Publisher",$addr_of_publ,$address_of_publisher1,$pud_details[2]);
?>
<input type=hidden name=address_of_publisher1 value='<?echo $address_of_publisher1 ?>'>
<?
$set_fpc=for_publisher_distri_con("Publisher",$country_of_publ,$country_of_publisher1,$pud_details[3]);
?>
<input type=hidden value='<? echo $country_of_publ?>'> name=country_of_publ>
<input type=hidden name=country_of_publisher1 value='<?echo $country_of_publisher1 ?>'>
<?
$distri_details=explode("##",$distributor_details);
$set_fdn=for_publisher_distri_name("Distributor",$distributor_name,$name_of_distributor1,$distri_details[0]);
?> <input type=hidden name=name_of_distributor1 value='<? echo $name_of_distributor1?>'>
   <input type=hidden name=distributor_name value='<? echo $distributor_name ?>'>
   <?
$set_fdp=for_publisher_distri_place("Distributor",$distri_place,$place_of_distributor1,$distri_details[1]);
?> <input type=hidden name=distri_addr value='<? echo $distri_addr?>'>
<input type=hidden name=place_of_distributor1 value='<? echo $place_of_distributor1 ?>'>
  <input type=hidden name=distri_place value'<? echo $distri_place?>'>
<?
$set_fda=for_publisher_distri_addr("Distributor",$distri_addr,$address_of_distributor1,$distri_etails[2]);
?>
<input type=hidden name=address_of_distributor1 value='<?echo $address_of_distributor1 ?>'>
<?
$set_fdc=for_publisher_distri_con("Distributor",$distri_country,$country_of_distributor1,$distri_details[3]);
?>
<input type=hidden value='<? echo $distri_country?>'> name=distri_country>
<input type=hidden name=country_of_distributor1 value='<?echo $country_of_distributor1 ?>'>
<input type=hidden name=publisher_details value='<? echo $publisher_details?>'>
<input type=hidden name=distributor_details value='<? echo $distributor_details?>'>
<?

label_names("Preliminary Pages");
if($preliminary==$priliminary1){
	label_values($priliminary1,0);
} else {
	label_values($priliminary1);
?>	<input type=hidden name=priliminary1 value='<? echo $priliminary1?>'>
<?
	$set_prelim=1;
}
label_names("Textual Pages");
if($textual==$textual1){
	label_values($textual1,0);
} else {
	label_values($textual1);
?>	<input type=hidden name=textual1 value='<? echo $textual1?>'>
<?
	$set_textual=1;
}
label_names("Accompanying Material");
?>
<input type=hidden name=accomp_material value=<? echo $accomp_material?> <?
if($accomp_material==$accomp_material1){
	label_values($accomp_material1,0);
} else {
	label_values($accomp_material1);
?>	<input type=hidden name=accomp_material1 value='<? echo $accomp_material1?>'>
<?
	$set_accomp_mat=1;
}
label_names("Invoice Number");
if($invoice_no1==$invoice_no){
	label_values($invoice_no1,0);
} else {
	label_values($invoice_no1);
?>	<input type=hidden name=invoice_no1 value='<? echo $invoice_no1?>'>
	<input type=hidden name=invoice_no value='<? echo $invoice_no ?>'>
<?
	$set_invoice_no=1;
}
label_names("Number Of Copies");
if($copies==$no_of_copies){
	label_values($copies,0);
} else {
	label_values($copies);
?>	<input type=hidden name=copies value='<? echo $copies ?>'>
<?
	$set_copies=1;
}
label_names("Price Per Unit");
if($price_per_unit==$amt){
	label_values($amt,0);
} else {
	label_values($amt);
?>	<input type=hidden name=amt value='<? echo $amt ?>'>
<?
	$set_amt=1;
}
label_names("Issn");
if($issn==$issn1){
	label_values($issn1,0);
} else {
	label_values($issn1);
?>	<input type=hidden name=issn1 value='<? echo $issn1?>'>
	<input type=hidden name=issn value='<? echo $issn?>'>
<?
	$set_issn=1;
}
label_names("Series Name");
if($series_name1==$series_name){
	label_values($series_name1,0);
} else {
	label_values($series_name1);
?>	<input type=hidden name=series_name1 value='<? echo $series_name1?>'>
<?
	$set_series_name=1;
}
label_names("Statement Of Responsibility");
if($statt_of_resp_sr_stt1== $statt_of_resp_sr_stt){
	label_values($statt_of_resp_sr_stt1,0);
} else {
	label_values($statt_of_resp_sr_stt1);
?>	<input type=hidden name=statt_of_resp_sr_stt1 value='<? echo $statt_of_resp_sr_stt1?>'>
<?
	$set_statt_ors2=1;
}
label_names("Vol/Part Number");
if($volume_or_part_no==$volume_or_part_no1){
	label_values($volume_or_part_no1,0);
} else {
	label_values($volume_or_part_no1);
?>      <input type=hidden name=volume_or_part_no1 value='<? echo $volume_or_part_no1 ?>'>
<? 
	$set_vol_part_no1=1;
}
label_names("Title Of Vol/Part");
if($part_statt1==$part_statt){
	label_values($part_statt1,0);
} else {
	label_values($part_statt1);
?>	<input type=hidden name=part_statt1 value='<? echo $part_statt1 ?>'>
<?	$set_part_statt1=1;
}
label_names("Keywords/Note");
if($note1==$note){
	label_values($note1,0);
} else {
	label_values($note1);
?> 	<input type=hidden name=note1 value='<<? echo $note1 ?>'>	
<?	$set_note1=1;
}
?>
</TD>
</TR></TABLE>

<INPUT TYPE=HIDDEN NAME=record_id VALUE='<?echo $record_id ?>'>
<INPUT TYPE=HIDDEN NAME=bibliographic_level_desc1 VALUE='<? echo $bibliographic_level_desc1 ?>'>
<INPUT TYPE=HIDDEN NAME=date_of_entry1 VALUE='<? echo $date_of_entry1?>'>
<INPUT TYPE=HIDDEN NAME=language_code1 VALUE='<? echo $language_code1?>'>
<? for($i=0;$i<count($physical_medium_desc1);$i++) { ?>
<INPUT TYPE=HIDDEN NAME=physical_medium_desc1[] VALUE='<? echo $physical_medium_desc1[$i]?>'>
<? } 
for($i=0;$i<count($additional_element1)|$i<count($secondary_element1)|$i<count($entry_element1;$i++){ ?>
<INPUT TYPE=HIDDEN NAME=additional_element1[] VALUE='<? echo $additional_element1[$i]?>'>
<INPUT TYPE=HIDDEN NAME=entry_element1[] VALUE='<?echo $entry_element1[$i] ?>'>
<INPUT TYPE=HIDDEN NAME=secondary_element1[] VALUE='<? echo $secondary_element1[$i] ?>'>
<INPUT TYPE=HIDDEN NAME=role[] VALUE='<? echo $role[$i]?>'>
<? } ?>
<INPUT TYPE=HIDDEN NAME=acc_no1 VALUE='<? echo $acc_no1?>'>
<INPUT TYPE=HIDDEN NAME=aacc_no VALUE='<? echo $aacc_no?>'>
<? } 
 ?>
<INPUT TYPE=SUBMIT Name=Submit>
</FORM>
<?
include "includeacqclerk.php";
}
else{
	Header("Location:http://$HTTP_HOST/~pro/authfail.html");
}
?>
</BODY>
</HTML>
