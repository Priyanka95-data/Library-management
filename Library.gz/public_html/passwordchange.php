<HTML>
<HEAD><TITLE>Updated *** Password ***</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">

<?php
include_once("header.inc");
include_once("common.php");

if(authenticate_user($name, $password, $option)) {

//check to see that member by that name does exist

    echo("<BR><BR><HR><BR><BR>");

    if($group=='Member') {
        $res = query("SELECT mem_id FROM member WHERE mem_id='$nametochange'");
    } else if($group=='Acquisition Clerk') {
        $res = query("SELECT acq_clerk FROM acquisition_clerk WHERE acq_clerk='$nametochange'");
    } else {
        $res = query("SELECT clerk FROM clerk WHERE clerk='$nametochange'");
    }

    if(pg_NumRows($res)==0) {
        echo("<H2 ALIGN=CENTER>No $group by the name $nametochange exists.</H2><BR>");
    } else {
        //member does exist .. we can continue

    if($npasswd==$vnpasswd) {
        //encrypt the new password
        $npasswd=md5($npasswd);

        query("BEGIN WORK");

    if($group=='Member') {
        $res = query("UPDATE member " .
                     "SET mem_passwd='$npasswd' " .
                     "WHERE mem_id='$nametochange' ");
    } else if($group=='Acquisition+Clerk') {
        $res = query("UPDATE acquisition_clerk " .
                     "SET acq_clerk_passwd='$npasswd' " .
                     "WHERE acq_clerk='$nametochange'");
    } else {
        $res = query("UPDATE clerk " .
                     "SET clerk_passwd='$npasswd' " .
                     "WHERE clerk='$nametochange'");
    }
    
    //report status of password change operation
    if(!$res || pg_cmdtuples($res)<1) {
        echo("<H2 ALIGN=CENTER>Password has <B>not<B> been updated.</H2><BR>"); 
        echo(pg_errormessage($res) . "<BR>");
        query("ROLLBACK WORK"); 
    } else {
        query("COMMIT WORK"); 
        echo("<H2 ALIGN=CENTER>Password has been sucessfully updated.</H2><BR>"); 
    }
    }else {
        echo("<H2 ALIGN=CENTER>Passwords don't match ... please re-enter.</H2><BR>");
        
    }
    
    }//done

    echo("<BR><BR><HR><BR><BR>");           
    if($group=='Member') {
        echo("<FORM ACTION=loginmember.html>");
    } else {
        echo("<FORM ACTION=login.html>");
    }
    echo("<DIV ALIGN=center><INPUT NAME='Re-Login' TYPE=submit VALUE='Re-Login'></DIV>");
    echo("</FORM>");
    echo("<BR><BR><HR><BR><BR>");           


    /*
      }
	echo("<FORM ACTION=admin.php>");
	echo("<DIV ALIGN=CENTER>");
	echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$admin_id'>");
	echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
	echo("</DIV>");
	echo("</FORM>");
	}
    */
}
else{
	echo("<H1 ALIGN=CENTER>Please Enter through Login Form.</H1>");
	echo("<DIV ALIGN=CENTER>");
	echo("<FORM ACTION=login.html>");
	echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
	echo("</FORM>");
	echo("</DIV>");
}
?>
</BODY>
</HTML>				

