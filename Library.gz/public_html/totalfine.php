<HTML>
<HEAD><TITLE>Accept fines</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

         echo("<DIV ALIGN = CENTER> <H1>Accept fines </H1>");
 
         echo("<BR><HR><BR>");
         echo("<FORM ACTION=totalfinedisplay.php METHOD=POST><BR>"); 
         echo("<BR><b> Member Id : &nbsp&nbsp</b>");
         echo("<INPUT NAME=mem_id TYPE=text SIZE=15 MAXLENGTH = 15><BR><BR>");
         echo("</DIV>");

         echo("<BR><HR><BR>");
         echo("<DIV ALIGN=CENTER>");
         echo("<INPUT NAME=display TYPE=submit VALUE=Display>");
         echo("</DIV>");
         echo("</FORM> <BR>");

         echo("<FORM ACTION=totalfine.php>"); 
         echo("<DIV ALIGN=CENTER>");
         echo("<INPUT NAME=reset TYPE=submit VALUE=Reset>");
         echo("</DIV>");
         echo("</FORM>");

         echo("<BR><HR>");
         echo("<DIV ALIGN=RIGHT>");
         echo("<A HREF='clerkentry.php'>Return to home page</A>");
         echo("</DIV>");


	}else{
	echo("<BR><HR>");
	echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
	echo("<FORM ACTION=login.html>"); 
	      echo("<DIV ALIGN=RIGHT>");
	      echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
	      echo("</DIV>");
	echo("</FORM>");
	}
?>
</BODY>
</HTML> 

