<?php

  $database=pg_connect("dbname=lms user=pro");


 $rest=pg_Exec($database,"SELECT count(rec_acc.record_id) from rec_acc,in_or_out where rec_acc.record_id = $record and rec_acc.acc_no = in_or_out.acc_no");



for($j=0;$j<pg_NumRows($rest);$j++){
		    $left=pg_Result($rest,$j,0);
}

?>
