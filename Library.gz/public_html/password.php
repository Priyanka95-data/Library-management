<HTML>
<HEAD><TITLE>Updated *** Password ***</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">
<?php
	require("header.inc");
	if($Submit){
        $database=pg_connect("dbname=lms user=pro");
	switch($value){
		case "Administrator":
			if($mpasswd==$mvpasswd){
			$mpasswd1=md5($mpasswd);
			$result=pg_Exec($database,"UPDATE clerk ".
			"SET clerk_passwd='$mpasswd1' WHERE clerk='admin'");
			echo("<H2 ALIGN=CENTER>Updated Password Sucessfully</H2>");
			}
			else{
			echo("<H2>Couldn't Update Password </H2>");
			}
			break;
		case "Clerk":
			if($mpasswd==$mvpasswd){
			$mpasswd1=md5($mpasswd);
			$result=pg_Exec($database,"UPDATE clerk ".
			"SET clerk_passwd='$mpasswd1' WHERE clerk='$name' ");
			echo("<H2 ALIGN=CENTER>Updated Password Sucessfully</H2>");
			}
			else{
			echo("<H2>Couldn't Update Password </H2>");
			}
			break;
		case "Acquisition Clerk":
			if($mpasswd==$mvpasswd){
			$mpasswd1=md5($mpasswd);
			$result=pg_Exec($database,"UPDATE acquisition_clerk ".
			"SET acq_clerk_passwd='$mpasswd1' WHERE acq_clerk='$name' ");
			echo("<H2 ALIGN=CENTER>Updated Password Sucessfully</H2>");
			}
			else{
			echo("<H2>Couldn't Update Password </H2>");
			}
			break;
		case "Member":
			if($mpasswd==$mvpasswd){
			$mpasswd1=md5($mpasswd);
			$result=pg_Exec($database,"UPDATE member ".
			"SET mem_passwd='$mpasswd1' WHERE mem_id='$name'");
			echo("<H2>Updated Password Sucessfully</H2>");
			}
			else{
			echo("<H2 ALIGN=CENTER>Couldn't Update Password </H2>");
			}
			break;
		default:
			break;	
	}
	echo("<FORM ACTION=admin.php>");
	echo("<DIV ALIGN=CENTER>");
	echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$admin_id'>");
	echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
	echo("</DIV>");
	echo("</FORM>");
	}
	else{
	echo("<H1 ALIGN=CENTER>Please Enter through Login Form.</H1>");
	echo("<DIV ALIGN=CENTER>");
	echo("<FORM ACTION=login.html>");
	echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
	echo("</FORM>");
	echo("</DIV>");
	}
?>
</BODY>
</HTML>				

