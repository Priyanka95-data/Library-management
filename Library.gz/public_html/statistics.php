<HTML>
<HEAD><TITLE>Statistics Page</TITLE></head>
<BODY bgcolor="#8AFF90" text="#316431">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {


	echo("<H1 ALIGN=CENTER>Statistics</H1><BR><HR><BR>"); 
	echo("<TABLE ALIGN=CENTER WIDTH='95%'><TR><TD>");

	echo("<FORM ACTION=itod.php METHOD=POST>");
	echo("<b>Run script to find defaulters :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Due Date Passed' VALUE='Due Date Passed'>");
	echo("</TD></TR></FORM><TR><TD>");

	echo("<FORM ACTION=duemail.php METHOD=POST>");
	echo("<b>Inform members about overdue books and fines by e-mail :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Notify Members' VALUE='Notify Members'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=totalmember.php METHOD=POST>");
	echo("<b>List all members :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='All Members' VALUE='All Members'>");
	echo("</TD></TR></FORM><TR><TD>");

	echo("<FORM ACTION=totalbook.php METHOD=POST>");
	echo("<b>List all books :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='All Books' VALUE='All Books'>");
	echo("</TD></TR></FORM><TR><TD>");

	echo("<FORM ACTION=totalreference.php METHOD=POST>");
	echo("<b>List Of Total No. Of Reference Books :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total Reference' VALUE='Total Reference'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=totalstudy.php METHOD=POST>");
	echo("<b>List Of Total No. Of Study Room Books :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total Study' VALUE='Total Study'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=totaltext.php METHOD=POST>");
	echo("<b>List Of Total No. Of Text Books :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total Text' VALUE='Total Text'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=acc.php METHOD=POST>");
	echo("<b>List Of Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Books On Acc No.' VALUE='Books On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=call.php METHOD=POST>");
	echo("<b>List Of Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Books On Call No.' VALUE='Books On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=date.php METHOD=POST>");
	echo("<b>List Of Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Books On Entry Date' VALUE='Books On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=accref.php METHOD=POST>");
	echo("<b>List Of Reference Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Reference On Acc No.' VALUE='Reference On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=callref.php METHOD=POST>");
	echo("<b>List Of Reference Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Reference On Call No.' VALUE='Reference On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=dateref.php METHOD=POST>");
	echo("<b>List Of Reference Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Reference On Entry Date' VALUE='Reference On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=accstudy.php METHOD=POST>");
	echo("<b>List Of Study Room Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Study Room On Acc No.' VALUE='Study Room On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=callstudy.php METHOD=POST>");
	echo("<b>List Of Study Room Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Study Room On Call No.' VALUE='Study Room On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=datestudy.php METHOD=POST>");
	echo("<b>List Of Study Room Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Study Room On Entry Date' VALUE='Study Room On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=acctext.php METHOD=POST>");
	echo("<b>List Of Text Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Text Books Based On Acc No.' VALUE='Text Books Based On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=calltext.php METHOD=POST>");
	echo("<b>List Of Text Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Text Books Based On Call No.' VALUE='Text Books Based On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=datetext.php METHOD=POST>");
	echo("<b>List Of Text Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Text Books Based On Entry Date' VALUE='Text Books Based On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=noacc.php METHOD=POST>");
	echo("<b>Total No. Of Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Books On Acc No.' VALUE='Total No. Of Books On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nocall.php METHOD=POST>");
	echo("<b>Total No. Of  Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Books On Call No.' VALUE='Total No. Of Books On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nodate.php METHOD=POST>");
	echo("<b>Total No. Of Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Books On Entry Date' VALUE='Total No. Of Books On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=noaccref.php METHOD=POST>");
	echo("<b>Total No. Of Reference Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Reference On Acc No.' VALUE='Total No. Of Reference On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nocallref.php METHOD=POST>");
	echo("<b>Total No. Of Reference Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Reference On Call No.' VALUE='Total No. Of Reference On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nodateref.php METHOD=POST>");
	echo("<b>Total No. Of Reference Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Reference On Entry Date' VALUE='Total No. Of Reference On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=noaccstudy.php METHOD=POST>");
	echo("<b>Total No. Of Study Room Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Study Room On Acc No.' VALUE='Total No. Of Study Room On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nocallstudy.php METHOD=POST>");
	echo("<b>Total No. Of Study Room Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Study Room On Call No.' VALUE='Total No. Of Study Room On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nodatestudy.php METHOD=POST>");
	echo("<b>Total No. Of Study Room Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Study Room On Entry Date' VALUE='Total No. Of Study Room On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=noacctext.php METHOD=POST>");
	echo("<b>Total No. Of Text Books Based On Acc No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Text Books Based On Acc No.' VALUE='Total No. Of Text Books Based On Acc No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nocalltext.php METHOD=POST>");
	echo("<b>Total No. Of Text Books Based On Call No. :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Text Books Based On Call No.' VALUE='Total No. Of Text Books Based On Call No.'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=nodatetext.php METHOD=POST>");
	echo("<b>Total No. Of Text Books Based On Entry Date :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Total No. Of Text Books Based On Entry Date' VALUE='Total No. Of Text Books Based On Entry Date'>");
	echo("</TD></TR></FORM><TR><TD>");


	echo("<FORM ACTION=issuemember.php METHOD=POST>");
	echo("<b>List of members who issued books today :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Books Issued Today' VALUE='Books Issued Today'>");
	echo("</TD></TR></FORM><TR><TD>");

	echo("<FORM ACTION=returnmember.php METHOD=POST>");
	echo("<b>List of members who returned books today :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Returned Today' VALUE='Returned Today'>");
	echo("</TD></TR></FORM><TR><TD>");

	echo("<FORM ACTION=duemember.php METHOD=POST>");
	echo("<b>List of members holding overdue books :</b></TD><TD>");
	echo("<INPUT TYPE=SUBMIT NAME='Overdue Books' VALUE='Overdue Books'>");
	echo("</TD></TR></FORM>");

    echo("</TABLE>");
    echo("<BR><HR>");
    echo("<DIV ALIGN=RIGHT>");
    echo("<A HREF='admin.php'>Return to home page</A>");
    echo("</DIV>");
    

}else{
    echo("<BR><HR>");
    echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
    echo("<DIV ALIGN=RIGHT>");
    echo("<A HREF=login.html><b>Logout</b></A>"); 
    echo("</DIV>");
}
?>
</BODY>
</HTML>
	