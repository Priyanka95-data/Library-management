<?php
$database = pg_connect("dbname=lms user=postgres");

      $result = pg_Exec($database,"UPDATE invoice_details ".
	     "set amt_paid='$amt' where invoice_no='$invoiceno' ");
?>