<HTML>
<HEAD><TITLE>Book has been renewed</TITLE></HEAD>  
<BODY BGCOLOR="#C5A9FF" TEXT="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
	
<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    $res = query("SELECT acc_no from nonrenewal_books WHERE acc_no='$acc_no'");
    $nonrenew=0;
    for($i=0;$i<pg_NumRows($res);$i++) {	
		$nonrenew=pg_Result($res,$i,0);
    }
    if($nonrenew !=0){             
		echo("<H2 ALIGN=CENTER>Book with Accession No. $acc_no may not be renewed</H2>");
		exit();
    }

    $res=query("SELECT record_id FROM reservation_book ".
               "WHERE record_id=(SELECT record_id FROM rec_acc WHERE acc_no='$acc_no')");
    $nonrenew=0;
          for($i=0;$i<pg_NumRows($res);$i++){	
		$nonrenew=pg_Result($res,$i,0);
	  }
	  if($nonrenew !=0){
		echo("<H2 ALIGN=CENTER>Book with Accession No. $acc_no has been reserved</H2>");
		exit();
	  }

	  $res=query("SELECT no_of_renewals FROM status ". 
                 "WHERE status=(SELECT status FROM member WHERE mem_id='$mem_id')");
	  for($i=0;$i<pg_NumRows($res);$i++){	
          $noofrenewal=pg_Result($res,$i,0);
	  }

	  $res=query("SELECT date_of_issue,date_of_return,renewal FROM mem_book ". 
                 "WHERE acc_no='$acc_no' AND (status_mem_bk='i' or status_mem_bk='d')");
	  for($i=0;$i<pg_NumRows($res);$i++){	
		$date_of_issue=pg_Result($res,$i,0);	  
		$date_of_return=pg_Result($res,$i,1);
		$renewal=pg_Result($res,$i,2);
	  }
		 
      $res=query("SELECT (CURRENT_DATE)");
      for($i=0 ; $i<pg_NumRows($res);$i++) {
          $returned_date= pg_Result($res,$i,0);
      }

      $fine=0;
      if($noofrenewal>$renewal) {
          if( $days > 3)
              {
                  $res=query("SELECT days,fine from admin_fine");
                  for($i=0; $i<1;$i++) {
                      $res1=pg_Result($res,$i,0);
                      $res2=pg_Result($res,$i,1);
                  }
                  if($days <= $res1)
                      {
                          $fine = $fine + $res2 * $days;
                      } 
                  else
                      {
                          $fine = $fine + $res2 * $res1;
                          $days = $days - $res1;
                      }
                  if($days > 0)
                      {
                          $res=query("SELECT days,fine from admin_fine");
                          for($i=0; $i<2;$i++) {
                              $res1=pg_Result($res,$i,0);
                              $res2=pg_Result($res,$i,1);
                          }
                          if($days <= $res1)
                              {
                                  $fine = $fine + $res2 * $days;
                              } 
                          else
                              {
                                  $fine = $fine + $res2 * $res1;
                                  $days = $days - $res1;
                              }
                      }
                  if($days > 0)
                      {
                          $res=query("SELECT days,fine from admin_fine");
                          for($i=0; $i<3;$i++) {
                              $res1=pg_Result($res,$i,0);
                              $res2=pg_Result($res,$i,1);
                          }
                          if($days <= $res1)
                              {
                                  $fine = $fine + $res2 * $days;
                              } 
                      }
                  $fines=$fines+$fine;
              }
          

          $res = query("UPDATE mem_related_to_entitlement SET ".
                       "entitlement_withheld = '$entit',fines ='$fines' WHERE".
                       " mem_entitl_id='$mem_entit_id'");
          
          $res = query("SELECT status.days_per_book FROM ".
                       "status,member WHERE member.mem_id='$mem_id' ".
                       "and status.status=member.status");
          for($i=0 ; $i<pg_NumRows($res);$i++) {
              $days_per_book= pg_Result($res,$i,0);
          }          

          $res=query("SELECT ".
                      "(CURRENT_DATE+CAST('$days_per_book day' AS INTERVAL))");
          for($i=0 ; $i<pg_NumRows($res);$i++) {
              $time= pg_Result($res,$i,0);
          }

          $renewal=$renewal+1;
          
          $res=query("UPDATE mem_book ".
                     "SET date_of_return='$time', date_of_issue='CURRENT_DATE', ".
                     "clerk='$name', status_mem_bk='i', renewal='$renewal' ".
                     "WHERE acc_no='$acc_no' AND mem_id='$mem_id' ".
                     "AND (status_mem_bk='i' OR status_mem_bk='d')");

        echo("<H2 ALIGN=>Book with Accession No. $acc_no has been renewed</H2>");

           //send email
           $res1=query("SELECT email FROM member WHERE ".
                       "mem_id='$mem_id' ");
           for($i=0;$i<pg_NumRows($res1);$i++){
               $to=pg_Result($res1,$i,0);
           }   

                $success=0;
                if($to)
                    {
                        $res2=query("SELECT email FROM clerk WHERE clerk='admin'");
                        $adminmail=pg_result($res2,0,"email");

                        $subj = LIBRARY . " - Renewed book";

                        $header = "From: " . $adminmail;

                        $body = LIBRARY . " \r\n\r\nThis is to inform you that " . 
                             "the following book has been renewed by you: \r\n " .
                             "\r\nAccession No.: " . $acc_no;
                        
                        $success = mail($to, $subj, $body, $header);
                    }
                
                if($success) {
                    echo("<H2>Mail successfully sent to $mem_id</H2><BR>");
                } else {
                    echo("<H2>Mail could not be sent to $mem_id</H2><BR>");
                }
                //email sent

                echo("<H2>Book with Accession No. $acc_no renewed by $mem_id</H2>");
                $res = query("COMMIT WORK");

    //		   echo("<IMG SRC=mail.gif ALIGN=CENTER>");

                echo("<BR><H3>Date of return:&nbsp $time </H3>");
                $no= $noofrenewal - $renewal;
                echo("<H3>Number of renewals left for this book:&nbsp $no</H3>");


      }	else{
          echo("<H2 ALIGN=CENTER>Renewal limit for this book has been reached</H2>");
          echo("<H2 ALIGN=CENTER>$mem_id may not renew this book</H2>");
      }

echo("<FORM ACTION=renew.php>"); 
echo("<INPUT TYPE=SUBMIT VALUE='Go Back' NAME='Go Back'>");
echo("</FORM>");
}

?>
</BODY>
</HTML>


