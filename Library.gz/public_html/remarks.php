<HTML>
<HEAD><TITLE>Remarks</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">
<?php
include("header.inc");
include("common.php");
if(authenticate_user($name,$password,$option)){
?>
<DIV ALIGN = CENTER> <H1>Remarks </H1></DIV>
<FORM ACTION=remarksdisplay5.php METHOD=GET>
<HR><BR><BR>

<TABLE>

<TR><TD> <b>Accession No. :</b> </TD>
<TD> <INPUT NAME="acc_no" TYPE="text" SIZE="50"> </TD></TR>
<BR><BR><BR>
        
<TR><TD> <b>Remarks :</b> </TD>
<TD> <TEXTAREA NAME="remarks" ROWS=4 COLS=50 WRAP="off"> </TEXTAREA></TD></TR>

</TABLE>
<BR><BR><HR><BR><BR>

<DIV ALIGN=CENTER>
<INPUT NAME="display" TYPE="submit" VALUE="Display">
</DIV>
  
</FORM> <BR>
 		  
<FORM ACTION=remarks.php> 
<DIV ALIGN=CENTER>
<INPUT NAME="reset" TYPE="submit" VALUE="Reset">
</DIV>
<?php	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id >"); ?>
</FORM>
<br><HR><br>
<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
<DIV ALIGN=left><A HREF=acqclerkentry.php>
	<b><FONT COLOR=RED>Goto Home Page</FONT></b></A>
</DIV></TD><TD>
<DIV ALIGN=right><A HREF=logout.php>
	<b><FONT COLOR=RED>Logout</FONT></B></A>
	</DIV>
	</TD></TR></TABLE>
<? }else {
	Header("Location:http://$HTTP_HOST/~pro/auth_fail.html");
}
?>
</BODY>
</HTML> 












