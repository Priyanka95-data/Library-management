<?php

//echo("<B>Common.php is in da house</B><BR>");

//connect to postgres database
$conn=pg_pconnect("user=pro dbname=lms password=pro"); 

$result=pg_exec($conn,"SELECT l_name FROM lib_name");
if($result){
	for($i=0;$i<pg_numrows($result);$i++)
		{
		$lib_name=pg_result($result,$i,0);
		}
	if($lib_name=='')
		{	
		define ("LIBRARY","PCCE LIBRARY");
		}
}
else {
	define ("LIBRARY", "PCCE LIBRARY");
}

//see if our connection was successful
if (!$conn) {
    //connection failed-exit the page with an
    //error
    //you could also try to proceed without the
    //database-it's up to you
    echo("NO CONNECTION - " . pg_errormessage($conn) );
    exit;
}

//a simple wrapper to reduce the code needed
//for each postgres query 
function query($sql) {
    global $conn;
    $result = pg_exec($conn,$sql);

if (!$result) {
    echo("QUERY ERROR - " . pg_errormessage($conn) );
    exit;
}else {
    return $result;
}
}

function authenticate_user($name, $password, $option) {

    if($option=='Member') {
        $res = query("SELECT mem_id, mem_passwd FROM " .
                     "member WHERE mem_id='$name'");
    } else if($option=='Acquisition Clerk') {
        $res = query("SELECT acq_clerk, acq_clerk_passwd FROM " .
                     "acquisition_clerk WHERE acq_clerk='$name'");
    } else if($option=='Administrator') {
        $res = query("SELECT clerk, clerk_passwd FROM " .
                     "clerk WHERE clerk='admin'");      
    }
    else {
        $res = query("SELECT clerk, clerk_passwd FROM " .
                     "clerk WHERE clerk='$name'");
    }
    
    if(pg_numrows($res) && $password == pg_result($res,0,1) 
       && $name == pg_result($res,0,0) ) {
        return 1;
    } else {
        return 0;
        echo pg_errormessage($res);
    }
}

function delete_cookies() {

    setcookie("name", "");
    setcookie("password", "");
    setcookie("option", "");
}

?>
