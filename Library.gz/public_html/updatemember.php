<HTML>
<HEAD><TITLE>Member Updation Form</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316431">
<FORM ACTION=member_updated.php METHOD=POST>
<?php
	if($mem_id){
        require("header.inc");
	echo("<BR><HR>");
	echo("<H2 ALIGN=CENTER><FONT COLOR=BROWN>");
	echo("Please Update The Following Information</FONT></H2>");
	$data=pg_connect("dbname=lms user=pro");
	$result=pg_Exec($data,"SELECT * FROM member where mem_id='$mem_id'");
	for($i=0;$i<pg_NumRows($result);$i++)
	{
		$mem_id=pg_Result($result,$i,0);
		$surname=pg_Result($result,$i,1);
		$first_name=pg_Result($result,$i,2);
		// drop next three here
		$institution=pg_Result($result,$i,6);
		$field=pg_Result($result,$i,7);
		$temporary_address=pg_Result($result,$i,8);	
		$permanent_address=pg_Result($result,$i,9);
		$phone=pg_Result($result,$i,10);
		$email=pg_Result($result,$i,11);	
		$year =pg_Result($result,$i,17);
	}
	echo("<BR><HR><BR>");
	echo("<TABLE ><TR><TD><H3>Welcome :</H3></TD><TD>"); 
	echo("<FONT COLOR=BLUE><u><B>$first_name $surname</B></u></FONT>");
	echo("</TD></TR></TABLE><BR>");
	echo("<H3 ALIGN=CENTER>Please Update The Following</H3>");
		// drop next three here
	echo("<TABLE WIDTH=65% ALIGN=CENTER><TR><TD>");
	echo("<B>Institution</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=institution VALUE='$institution'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Stream/Field</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=field VALUE='$field'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Temporary Address</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=temporary_address VALUE='$temporary_address'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Permenant Address</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=permanent_address VALUE='$permanent_address'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Phone</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=phone VALUE='$phone'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>E - Mail</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=email VALUE='$email'>");
	echo("</TD></TR><TR><TD>");	
	echo("<B>Year</B></TD><TD>");
	echo("<INPUT TYPE=TEXT NAME=year VALUE='$year'>");
	echo("</TD></TR></TABLE><BR><BR>");
	echo("<DIV ALIGN=CENTER>");
	echo("<INPUT TYPE=HIDDEN NAME='mem_id' VALUE='$mem_id'>");
	echo("<INPUT TYPE=SUBMIT NAME='Make Changes' VALUE='Make Changes'>");
	echo("</DIV><BR><HR>");
	}
	else{
		header("Location:http://$HTTP_HOST/~pro/forbidden.html");
		exit();
	}
?>
</FORM>
</BODY>
</HTML>

