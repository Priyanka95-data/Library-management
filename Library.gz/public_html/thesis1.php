<HTML>
<HEAD><TITLE>Add new theses</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">

         <DIV ALIGN = CENTER><H1>Add new theses to database </H1></DIV>
         <FORM ACTION=thesisdisplay5.php METHOD=POST>
	     <HR><BR>


   <TABLE><TR><TD>
         <b>Bibliographic Level :</b>
            <TD><SELECT NAME="bibliographic_level_desc1">
             <OPTION value=Monograph>Monograph
             <OPTION value=Serial>Serial
             <OPTION value=Component part>Component Part
             <OPTION value=Multivolume>Multivolume
             <OPTION value=Made-up Collection>Made-up Collection
            </SELECT></TD></TR><TR><TD>
             <b>Location :</b></TD>
            <TD><INPUT NAME="location1" TYPE="text" SIZE="15" MAXLENGTH = "15">

          </TD></TR><TR><TD><b>Date Of Entry :</b> </TD>
          <TD><SELECT NAME="date_of_entry_mm1" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>             
          <SELECT NAME="date_of_entry_dd1" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="date_of_entry_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" >
	  </TD></TR><TR><TD>
          <b>Language :</b> </TD><TD>
<?php
        $database=pg_connect("dbname=lms user=pro password=pro");
        $result=pg_Exec($database,"SELECT language_desc from language_code");
        echo("<SELECT NAME=language_code1 value='$language_code1'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR><TR><TD>
      <b>Script :</b></TD>
        <TD><SELECT NAME="script1">
           <OPTION value=Roman>Roman
           <OPTION  value=Cyrillic>Cyrillic
           <OPTION value=Japanese-script unspecified>Japanese-script unspecified
           <OPTION value=Japanese-kanji>Japanese-kanji
           <OPTION value=Chinese>Chinese
           <OPTION value=Arabic>Arabic
           <OPTION value=Greek>Greek
           <OPTION value=Hebrew>Hebrew
           <OPTION value=Thai>Thai
           <OPTION value=Devanagari>Devanagari
           <OPTION value=Korean>Korean
           <OPTION value=Tamil>Tamil
           <OPTION value=Other>Other
        </SELECT></TD></TR><TR><TD>

           <b>Translation :</b></TD><td>
<?php
        $result=pg_Exec($database,"SELECT language_desc from language_code");
        echo("<SELECT NAME=translation_code1 value='$translation_code1'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR><TR><TD>
    <b>Physical Medium :</b></TD><TD>
     <UL>
       <LI><INPUT TYPE="checkbox" NAME="paper1" VALUE="paper" CHECKED> Paper
       <LI><INPUT TYPE="checkbox" NAME="magnetic1" VALUE="magnetic"> Magnetic
       <LI><INPUT TYPE="checkbox" NAME="film1" VALUE="film"> Film
       <LI><INPUT TYPE="checkbox" NAME="laser1" VALUE="laser/optical"> Laser/Optical
       <LI><INPUT TYPE="checkbox" NAME="braille1" VALUE="braille"> Braille
       <LI><INPUT TYPE="checkbox" NAME="other1" VALUE="other"> Other
    </UL></TD></TR><TR><TD>

            <b>Type Of Material :</b></TD>
               <TD><SELECT NAME="type_of_material_desc1">
                <OPTION value=textual>textual
                <OPTION value=report/technical report>report/technical report
                <OPTION value=thesis/dissertation>thesis/dissertation
                <OPTION value=meeting document>meeting document
                <OPTION value=periodical>periodical
                <OPTION value=newspaper>newspaper
                <OPTION value=annual>annual
                <OPTION value=patent document>patent document
                <OPTION value=standard>standard
                <OPTION value=irregual serial>irregual serial
                <OPTION value=monograhic series>monograhic series
                <OPTION value=other textual materials>other textual materials
                <OPTION value=non-textual materials>non-textual materials
               </SELECT></TD></TR><TR><TD>


            <b>Title :</b>
                <TD><INPUT NAME="title_bk1" TYPE="text" SIZE="50"></TD></TR>
<TR><TD>
       <b>Statement Of Responsibility :</b></TD>
          <TD><INPUT NAME="statt_of_resp_ti_bk1" TYPE="text" SIZE="50">
  </TD></TR><TR><TD>

            <b>Language :</b></TD><TD>

<?php
        $result=pg_Exec($database,"SELECT language_desc from language_code");
        echo("<SELECT NAME=language_code_title_bk1 value='$language_code_title_bk1'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR><TR><TD>

            <b>Script :</b></TD>
<TD>
               <SELECT NAME="script_title_bk1">
               <OPTION value=Roman>Roman
               <OPTION  value=Cyrillic>Cyrillic
               <OPTION value=Japanese-script unspecified>Japanese-script unspecified
               <OPTION value=Japanese-kanji>Japanese-kanji
               <OPTION value=Chinese>Chinese
               <OPTION value=Arabic>Arabic
               <OPTION value=Greek>Greek
               <OPTION value=Hebrew>Hebrew
               <OPTION value=Thai>Thai
               <OPTION value=Devanagari>Devanagari
               <OPTION value=Korean>Korean
               <OPTION value=Tamil>Tamil
               <OPTION value=Other>Other
               </SELECT></TD></TR>

<TR><TD>
             <H3>NAME OF PERSON (Author,Illustrator,..) :</H3>
                </TD></TR><TR><TD>
             <b>Surname(s) of Person(s)  :</b></TD>
                 <TD><INPUT NAME=entry_element1 TYPE=text SIZE="50" >
		 </TD></TR><TR><TD>
             First Name(s) of Person(s) :
           <TD><INPUT NAME=secondary_element1 TYPE=text SIZE="50" >
	   </TD></TR><TR><TD>
                Last Name(s) of Person(s) :
           <TD><INPUT NAME=additional_element1 TYPE=text SIZE="50" >
	   </TD></TR><TR><TD>
                Date(date of birth,date of death,etc):
         <TD><SELECT NAME="date_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>
         <SELECT NAME="date_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	  <INPUT NAME="date_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" >
	  </TD></TR><TR><TD>
             <b>Role (Non-Coded)  :</b></TD>
	  <TD><INPUT NAME="rolee" TYPE="text" ></TD></TR><TR><TD>

             <b>Role :</b>
</TD><TD>
<?php
        $result=pg_Exec($database,"SELECT role_type from role");
        echo("<SELECT NAME=role_type1 value='$role_type1'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR><TR><TD>


      <b>Date Of Publication :</b></TD>
        <TD> <SELECT NAME="date_of_publication_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>
         <SELECT NAME="date_of_publication_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
 <INPUT NAME="date_of_publication_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" >
 </TD></TR><TR><TD>

             <b>Subject Descriptor :</b></TD>
         <TD><INPUT NAME="subject_desc1" TYPE="text" SIZE="10"> &nbsp &nbsp
         <INPUT NAME="subject_desc2" TYPE="text" SIZE="10"></TD></TR>
	<TR><TD>

        <b>Accession No. :</b></TD>
        <TD><INPUT NAME="acc_no1" TYPE="text" SIZE="50">
	</TD></TR><TR><TD>

             <b>Starting Date :</b></TD>
         <TD><SELECT NAME="date_of_price_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>
         <SELECT NAME="date_of_price_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
 <INPUT NAME="date_of_price_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" >
 </TD></TR><TR><TD>
            <b>Ending Date :</b></TD>
          <TD><SELECT NAME="date_of_invoice_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>
         <SELECT NAME="date_of_invoice_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	<INPUT NAME="date_of_invoice_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" >
	</TD></TR><TR><TD>
             <b>Date Of Award (mm/dd/yyyy):</b></TD>
	  <TD><INPUT NAME="award" TYPE="text" ></TD></TR>
 	 <TR></TR><HR><TR><TD>

             <b>Accession No. Of Reference Book  :</b></TD>
          <TD><INPUT NAME="reference" TYPE="text" SIZE="50"></TD></TR>
	  <TR><TD>
	 </TD></TR><TR><TD>
             <b>Accession No. Of Study Room Book  :</b></TD>
         <TD><INPUT NAME="study" TYPE="text" SIZE="50"></TD></TR><TR><TD>
 </TD><TR>

 <TR><TD>
	Name Of Corporate Body :
                 <TD><INPUT NAME="name_of_corporate_body1" TYPE="text" SIZE="50" >
</TD><TD>
<?php
        $result=pg_Exec($database,"SELECT name_of_corporate_body from name_of_corporate_body");
        echo("<SELECT NAME=name_of_corporate_body2 value='$name_of_corporate_body2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> </TD><TR>


 <TR><TD>
		Name Of Parent Body :
                 <TD><INPUT NAME="parent_body_name1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT parent_body_name from name_of_corporate_body");
        echo("<SELECT NAME=parent_body_name2 value='$parent_body_name2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>  </TD><TR>

 <TR><TD>
              Address :</TD>
        <TD><INPUT NAME="address_of_corporate_body1" TYPE="text" SIZE="50" >
</TD><TD><?php
         $result=pg_Exec($database,"SELECT address from name_of_corporate_body");
        echo("<SELECT NAME=address_of_corporate_body2 value='$address_of_corporate_body2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>  <TR><TD>
</TD></TR>
 <TR><TD>
          Country :</TD>
         <TD><INPUT NAME="country_of_corporate_body1" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT country_desc from country");
        echo("<SELECT NAME=country_of_corporate_body2 value='$country_of_corporate_body2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>  <TR><TD>
</TD></TR>
 <TR><TD>
          Role :</TD>
          <TD><INPUT NAME="role_of_corporate_body1" TYPE="text" SIZE="50" >
</TD><TD>
<?php
        $result=pg_Exec($database,"SELECT role from name_of_corporate_body");
        echo("<SELECT NAME=role_of_corporate_body2 value='$role_of_corporate_body2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> <TR><TD>

               Document No. :</TD>
               <TD><INPUT NAME="document_no1" TYPE="text" SIZE="30" >
	       </TD></TR><TR><TD>

               Parallel Title :</TD>
               <TD><INPUT NAME="parallel_title1" TYPE="text" SIZE="50" >
	       </TD></TR><TR><TD>

               Statement Of Responsibility :</TD>
               <TD><INPUT NAME="statement_of_resp1" TYPE="text" SIZE="50" >
	       </TD></TR>

 <TR><TD>
      Language :</TD>
     <TD><INPUT NAME="language_code_parallel_title1" TYPE="text" SIZE="50" >
</TD><TD><?php
     $result=pg_Exec($database,"SELECT language_desc from language_code");

    echo("<SELECT NAME=language_code_parallel_title2 value='$language_code_parallel_title2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR><TR><TD>
</TD></TR>
	 <TR><TD>
               Script :</TD>
               <TD><INPUT NAME="script_parallel_title1" TYPE="text" SIZE="50" >
              </TD><TD>

               <SELECT NAME="script_parallel_title2">
               <OPTION value=Roman>Roman
               <OPTION  value=Cyrillic>Cyrillic
               <OPTION value=Japanese-script unspecified>Japanese-script unspecified
               <OPTION value=Japanese-kanji>Japanese-kanji
               <OPTION value=Chinese>Chinese
               <OPTION value=Arabic>Arabic
               <OPTION value=Greek>Greek
               <OPTION value=Hebrew>Hebrew
               <OPTION value=Thai>Thai
               <OPTION value=Devanagari>Devanagari
               <OPTION value=Korean>Korean
               <OPTION value=Tamil>Tamil
               <OPTION value=Other>Other
               </SELECT>
               </TD></TR>
               <TR><TD>

               Other Title :</TD>
            <TD><INPUT NAME="other_title1" TYPE="text" SIZE="50" ></TD></TR>

	 <TR><TD>
               Type Of Title :</TD>
                <TD><INPUT NAME="type_of_title1" TYPE="text" SIZE="50" >
               </TD><TD>
	       <SELECT NAME="type_of_title2">
	         <OPTION value='NULL'>NULL
	         <OPTION value=Sub Title>Sub Title
                 <OPTION value=Spine Title>Spine Title
                 <OPTION value=Cover Title>Cover Title
                 <OPTION value=Added Title>Added Title
                 <OPTION value=Running Title>Running Title
                 <OPTION value=Other Title/Unknown Title>Other Title/Unknown Title
               </SELECT>
               </TD></TR>
               <TR><TD>

            Language :</TD>
           <TD><INPUT NAME="language_code_other_title1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT language_desc from language_code");
        echo("<SELECT NAME=language_code_other_title2 value='$language_code_other_title2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>

<TR><TD><h3>
                PLACE AND NAME OF PUBLISHER :</h3>
                  </TD></TR><TR><TD>
 
                Name :</TD>
          <TD><INPUT NAME="publisher_name1" TYPE="text" SIZE="50" >
	  </TD><TD><?php
        $result=pg_Exec($database,"SELECT publisher_name from place_and_publisher");
        echo("<SELECT NAME=publisher_name2 value='$publisher_name2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>

 <TR><TD>
                Place :</TD>
                  <TD><INPUT NAME="place_of_publisher1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT place from place_and_publisher");
        echo("<SELECT NAME=place_of_publisher2 value='$place_of_publisher2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>

 <TR><TD>
                Address :</TD>
            <TD><INPUT NAME="address_of_publisher1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT address from place_and_publisher");
        echo("<SELECT NAME=address_of_publisher2 value='$address_of_publisher2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> 

 <TR><TD>
                Country :</TD>
                  <TD><INPUT NAME="country_of_publisher1" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT country_desc from country");
        echo("<SELECT NAME=country_of_publisher2 value='$country_of_publisher2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> 

<TR><TD><h3>    PHYSICAL DESCRIPTION :</h3></TD></TR><TR><TD>
                Pagination_Description :
                <TD> <SELECT NAME="pagination_desc1">
		  <OPTION value=Books>Books
                  <OPTION value=Maps>Maps
                  <OPTION value=Globes>Globes
                  <OPTION value=Audio Cassettes>Audio Cassettes
                  <OPTION value=Film Reels>Film Reels
                  <OPTION value=Video Cassettes>Video Cassettes
                  <OPTION value=Magnetic Tapes>Magnetic Tapes
                  <OPTION value=Magnetic Disks>Magnetic Disks
                  <OPTION value=Charts>Charts
                  <OPTION value=Posters>Posters
                  <OPTION value=Slides>Slides
                  <OPTION value=Photographs>Photographs
                  <OPTION value=Drawings>Drawings
                  <OPTION value=Pictures>Pictures
                  <OPTION value=CD-Rom>CD-Rom
                  <OPTION value=Micro Films>Micro Films
                 </SELECT></TD></TR><TR><TD>
                Preliminary (Optional)</TD>
                  <TD><INPUT NAME="priliminary1" TYPE="text" SIZE="10" ></TD>
		</TR><TR><TD>
		Textual :</TD><TD>
                  <INPUT NAME="textual1" TYPE="text" SIZE="10" > </TD></TR>
		 <TR><TD> 
                Illustration :</TD>
            <TD><INPUT NAME="illustration1" TYPE="text" SIZE="50" > </TD></TR>
	    <TR><TD><h4>
                DIMENSIONS :</h4></TD></TR><TR><TD>
                Length :</TD>
                   <TD><INPUT NAME="l1" TYPE="text" SIZE="5" ></TD></TR><TR><TD>
                Breath :</TD><TD>
                   <INPUT NAME="d1" TYPE="text" SIZE="5" ></TD></TR><TR><TD>
                Height :</TD><TD>
                   <INPUT NAME="h1" TYPE="text" SIZE="5" ></TD></TR><TR><TD>
             Accompanying Material :</TD>
             <TD><INPUT NAME="accomp_material1" TYPE="text" SIZE="50" > 
	     </TD></TR><TR><TD>

                Abstract :</TD>
                   <TD><INPUT NAME="abstract" TYPE="text" SIZE="50" > 
		   </TD></TR><TR><TD>
                Language Of Abstract  :</TD>
             <TD><INPUT NAME="language_of_abstract" TYPE="text" SIZE="50" >
	     </TD></TR><TR><TD>
                <b>Reserved Field For Thesis</b></TD></TR><TR><TD>
                Type Of Degree :</TD>
              <TD><INPUT NAME="degree" TYPE="text" SIZE="50" > 
	      </TD></TR><TR><TD>

                Type Of Research :</TD>
              <TD><INPUT NAME="research" TYPE="text" SIZE="50" > </TD></TR>
	      <TR><TD>

                Research  Funds:</TD>
             <TD><INPUT NAME="funds" TYPE="text" SIZE="50" > </TD></TR><TR><TD>

                Address Of Research Team:</TD>
            <TD><INPUT NAME="team" TYPE="text" SIZE="50" > </TD></TR><TR><TD>


                Note <i>(Enter Keywords)</i>:</TD>
                  <TD><INPUT NAME="note1" TYPE="text" SIZE="50"></TD></TR>
<TR><TD><h3>
                CLASSIFICATION SCHEME NOTATION <h3></TD></TR><TR><TD>
                Notation :</TD>
                  <TD><INPUT NAME="notation1" TYPE="text" SIZE="30">
                </TD><TR><TD>Edition_no :</TD>
               <TD><INPUT NAME="edition_no1" TYPE="text" SIZE="50">
	       </TD></TR><TR><TD>
                Identification Of Classification Code :</TD>
               <TD><INPUT NAME="identification1" TYPE="text" SIZE="50">
	       </TD></TR><TR><TD>
                Classification Scheme Code :</TD>
                 <TD> <SELECT NAME="c_s_c_desc1">

                   <OPTION value='D'>Dewey Decimal
                   <OPTION value='C'>Colon Classification
                   <OPTION value='L'>Library Of Congress
                   <OPTION value='U'>Universal Decimal
                  </SELECT></TD></TR>
        </TABLE>


          <BR><HR><BR>                   
		  <DIV ALIGN=CENTER>
                    <INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>
                  </FORM>
<BR>
 		  <FORM ACTION=thesis.php>

		  <DIV ALIGN=CENTER>
		        <TD><INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
	  </FORM>

      <BR><HR><BR> 

    <DIV ALIGN=RIGHT>
    <A HREF='acqclerkentry.php'>Return to home page</A>
    </DIV>

</BODY>
</HTML> 








