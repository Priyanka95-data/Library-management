<HTML>
<HEAD><TITLE>Update Profile</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316431">
<FORM ACTION=updateprofile.php METHOD=POST>

<?php

include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {

    echo("<INPUT TYPE=hidden NAME=nametochange VALUE='$nametochange'>");
    echo("<INPUT TYPE=hidden NAME=group VALUE='$group'>");
    

	echo("<BR><H1 ALIGN=CENTER>Update Profile</H1>");
    echo("<BR><HR><BR>");

//retrieve existing profile

    if($group=='Member') {
        $res = query("SELECT * FROM member WHERE mem_id='$nametochange'");

        for($i=0;$i<pg_NumRows($res);$i++)
            {
                $memname=pg_Result($res,$i,'first_name') . " " . pg_Result($res,$i,'surname');
                $temporary_address=pg_Result($res,$i,'temporary_address');
                $permanent_address=pg_Result($res,$i,'permanent_address');
                $phone=pg_Result($res,$i,'phone');
                $email=pg_Result($res,$i,'email');
            }
    } else 

    if($group=='Acquisition+Clerk') {
        $res = query("SELECT * FROM acquisition_clerk WHERE acq_clerk='$nametochange'");

        for($i=0;$i<pg_NumRows($res);$i++)
            {
                $name=pg_Result($res,$i,'name_of_acq_clerk');
                $temporary_address=pg_Result($res,$i,'temporary_address');
                $permanent_address=pg_Result($res,$i,'permanent_address');
                $phone=pg_Result($res,$i,'phone');
                $email=pg_Result($res,$i,'email');
            }

    } else {
        $res = query("SELECT * FROM clerk WHERE clerk='$nametochange'");

        for($i=0;$i<pg_NumRows($res);$i++)
            {
                $name=pg_Result($res,$i,'name_of_clerk');
                $temporary_address=pg_Result($res,$i,'temporary_address');
                $permanent_address=pg_Result($res,$i,'permenant_address');
                $phone=pg_Result($res,$i,'phone');
                $email=pg_Result($res,$i,'email');
            }

    }

	echo("<TABLE><TR><TD><H3>Welcome : </H3></TD><TD>"); 
	echo("<H3><FONT COLOR=#000000>$memname</FONT></H3>");
	echo("</TD></TR></TABLE><BR>");
	echo("<BR><H3 ALIGN=CENTER>Please update your profile&nbsp&nbsp(edit fields you 
wish to change)</H3>");
	echo("<TABLE WIDTH=50% ALIGN=CENTER><TR>");
	echo("<TD>Temporary Address</TD>");
	echo("<TD><INPUT TYPE=TEXT NAME=temporary_address VALUE='$temporary_address'></TD>");
	echo("</TR><TR>");	
	echo("<TD>Permanent Address</TD>");
	echo("<TD><INPUT TYPE=TEXT NAME=permanent_address VALUE='$permanent_address'></TD>");
	echo("</TR><TR>");	
	echo("<TD>Phone</TD>");
	echo("<TD><INPUT TYPE=TEXT NAME=phone VALUE='$phone'></TD>");
	echo("</TR><TR>");	
	echo("<TD>E - Mail</TD>");
	echo("<TD><INPUT TYPE=TEXT NAME=email VALUE='$email'></TD>");
    echo("</TABLE>");

    echo("<BR><BR><DIV ALIGN=CENTER><HR WIDTH=65%></DIV><BR>");
	echo("<H3 ALIGN=CENTER>Change password&nbsp&nbsp(leave empty if you do not
 wish to change)</H3>");
	echo("<TABLE WIDTH=50% ALIGN=CENTER><TR>");
    echo("<TR><TD>New Password</TD>");
    echo("<TD><INPUT TYPE=PASSWORD NAME=npasswd VALUE='$npasswd'></TD>");
    echo("<TR><TD>Verify Password</TD>");
    echo("<TD><INPUT TYPE=PASSWORD NAME=vnpasswd VALUE='$vnpasswd'></TD></TR>");
	echo("</TABLE><BR>");	

	echo("<BR><HR><BR><DIV ALIGN=center> <INPUT TYPE=SUBMIT NAME='Make Changes' VALUE='Make Changes'></DIV>");
	echo("<BR><BR><HR>");
?>
	  <TABLE WIDTH=100% ALIGN=CENTER><TR><TD>
	     <A HREF=clerkentry.php>Home Page</A></TD><TD>
	     <A HREF=logout.php>Logout</A></TD></TR></TABLE>
<?php	
} else{
    //login failed
    header("Location: http://$HTTP_HOST/~pro/memauthfail.html");
	}
?>
</FORM>
</BODY>
</HTML>

