<HTML>
<HEAD><TITLE>Members Can Change their Password Now</TITLE></HEAD>
<BODY BGCOLOR="#18097F" TEXT="#F97235">
<?php
	require("header.inc"); 
	if($clerk_id){
	echo("<FORM ACTION=clerk_change.php METHOD=POST><BR><BR><HR>");
	echo("<TABLE width='70%' ALIGN=CENTER><TR><TD>");
	echo("<b>Please Enter New Password :</b></TD><TD>");
	echo("<INPUT TYPE=PASSWORD NAME=mpasswd></TD></TR><TR><TD>");
	echo("<BR><b>Verify Password :</b></TD><TD>");
	echo("<INPUT TYPE=PASSWORD NAME=mvpasswd></TD></TR></TABLE>");
	echo("<DIV ALIGN=CENTER>");
	echo("<INPUT TYPE=HIDDEN NAME=clerk_id VALUE='$clerk_id'>");
	echo("<INPUT TYPE=SUBMIT NAME=Submit VALUE=Submit>");
	echo("</DIV>");
	echo("</FORM>");
	}
	else{
	header("Location:http://$HTTP_HOST/~pro/error3.html");
	}
	
?>
</BODY>
</HTML>
