<?php

include("common.php");

if (authenticate_user($name, $password, $option)) {
    //    setcookie("name", "");
    //    setcookie("password", "");
    //    setcookie("option", "");
    delete_cookies();
    header("Location:http://$HTTP_HOST/~pro/login.html");
}
?>
