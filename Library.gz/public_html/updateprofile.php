<HTML>
<HEAD><TITLE>Profile Has Been Updated</TITLE></HEAD>
<BODY BGCOLOR="#8AFF90" text="#316436">

<?php

include("header.inc");
include("common.php");

if(authenticate_user($name, $password, $option)) {



    if($group=='Member') {
        echo("<FORM ACTION=loginmember.html>");

        $res = query("UPDATE member SET ".
                         "temporary_address='$temporary_address',".
                         "permanent_address='$permanent_address',".
                         "phone='$phone',email='$email' ".
                         "WHERE mem_id='$nametochange'");

    } else if($group=='Acquisition+Clerk') {

        echo("<FORM ACTION=login.html>");

        $res = query("UPDATE acquisition_clerk SET ".
                         "temporary_address='$temporary_address',".
                         "permanent_address='$permanent_address',".
                         "phone='$phone',email='$email' ".
                         "WHERE acq_clerk='$nametochange'");
    }  else {
        echo("<FORM ACTION=login.html>");
        
        $res = query("UPDATE clerk SET ".
                     "temporary_address='$temporary_address',".
                     "permenant_address='$permanent_address',".
                     "phone='$phone',email='$email' ".
                     "WHERE clerk='$nametochange'");
    }            

    echo("<HR><H2 ALIGN=CENTER>Profile for <u>$nametochange</u> has been updated.</H2><BR>");
    
    if($npasswd){
        include("passwordchange.php");
        delete_cookies();
        exit();
    }
    
    echo("<DIV ALIGN=CENTER>");
    echo("<INPUT TYPE=SUBMIT NAME='Logout' VALUE='Logout'>");
    echo("</DIV>");
    echo("</FORM><BR><HR>");
	
} else{
    //login failed
    header("Location: http://$HTTP_HOST/~pro/memauthfail.html"); 
}

?>
</BODY>
</HTML>