<HTML>
<HEAD><TITLE>Search Result</TITLE></HEAD> 
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F
9424">
<TABLE ALIGN=CENTER WIDTH=50%><TR><TD>
	<H1 ALIGN=CENTER>Search Results</H1></TD><TD><IMG SRC=find.gif>
	</TD></TR></TABLE><HR>
    <?php
	if($wname)
	{
	$name=$wname;
	}
	if (trim($name)==""){
	  header("Location:http://$HTTP_HOST/~pro/error2.html");
	  exit();
       } 
       else {
       echo("<FORM ACTION=searchdisplay.php>");
	$timeparts=explode(" ",microtime());
	$starttime=$timeparts[1].substr($timeparts[0],1);
	switch ($count) {
		case '10 records per page' :
			$count1=10;       
			break;
		case '20 records per page' :
			$count1=20;
			break;
		case '25 records per page' :
			$count1=25;
			break;
		case '50 records per page' :
			$count1=50;
			break;
		default :
			break;
		}
       $database=pg_connect("dbname=lms user=pro password=pro");
       $temp=0;
      	if(!$count1){ 
		$count1=50;
		}
      if($Next){
       	$offset+=$count1;
	}
	if($Previous){
	$offset-=$count1;
	}
	$wname=$name;
       switch ($selection) {

       case 'Author' :
       //$name=ucfirst($name);
       $namee=$name;   
       $name1='';
       $name2='';
    	$tel=$namee;
        $w=strlen($tel);
        $l=strcspn($tel,",");
	$name=substr($tel,0,$l);
        $namee=substr($tel,$l+1,strlen($tel));
      

       	$tel=$name;
        $w=strlen($tel);
        $l=strcspn($tel," ");
	$name=substr($tel,0,$l);
	$name1=substr($tel,$l+1,strlen($tel));

	if(strlen($name1)>0){
        $tel=$name1;
        $w=strlen($tel);
        $l=strcspn($tel," ");
	$name1=substr($tel,0,$l);
	$name2=substr($tel,$l+1,strlen($tel));
        }

      	$name=ucfirst($name);
	$name1=ucfirst($name1);
	$name2=ucfirst($name2);
	$namee=ucfirst($namee);
	$reach2=pg_Exec($database,"SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc,name_of_person,common_to_books_and_thesis where common_to_books_and_thesis.record_id=rec_acc.record_id and common_to_books_and_thesis.person1=name_of_person.person1 and name_of_person.primary_element LIKE '%$name%'  group by name_of_person.person1,common_to_books_and_thesis.title_bk union  SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc, name_of_person,title_bk where common_to_books_and_thesis.record_id=rec_acc.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and name_of_person.additional_element LIKE '%$name%'  group by name_of_person.person1,common_to_books_and_thesis.title_bk union  SELECT common_to_books_and_thesis.title_bk,name_of_person.person1,count(rec_acc.record_id) from rec_acc, name_of_person,title_bk where common_to_books_and_thesis.record_id=rec_acc.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and name_of_person.secondary_element LIKE '%$name%' group by name_of_person.person1,common_to_books_and_thesis.title_bk");

	if(pg_NumRows($reach2) == 0 ){
		echo("<H1 ALIGN=CENTER>No Record <H1>");
	}else {

        echo("<H4 ALIGN=left>Books found matching search criteria :</H4><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");

        if($name1=="")
        {
          include("author.php");
	}
	elseif($name2==""){
	  include("author1.php");
	}
	else{
	  include("author2.php");
	}

		echo("</TABLE><FORM>");
		echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
		echo("<INPUT TYPE=HIDDEN NAME=m VALUE='$m'>");
		echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
		echo("<INPUT TYPE=HIDDEN NAME=wname VALUE='$wname'>");
		echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>");
?>
	<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
<?
	$cam1=$offset+$count1;
	if($cam1<pg_NumRows($reach2)){
	             echo("<DIV ALIGN=LEFT>");
		     echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next></DIV>");
	}
        echo("</TD><TD>");
	$cam=$offset-$count1;
	if($cam>=0){
               echo("<DIV ALIGN=RIGHT>");
                echo("<INPUT TYPE=SUBMIT NAME=Previous VALUE=Previous></DIV>");
                }
               echo("</TD></TR></TABLE>");

	echo("</FORM><BR>");
	}
	$num=pg_NumRows($reach2);
 	break;
       case 'Title' :
	$name=ucfirst($name);
	$reach=pg_Exec($database,"SELECT ".
"count(rec_acc.acc_no),common_to_books_and_thesis.title_bk,name_of_person.primary_element,name_of_person.secondary_element,name_of_person.additional_element from rec_acc,name_of_person,common_to_books_and_thesis where rec_acc.record_id=common_to_books_and_thesis.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and common_to_books_and_thesis.title_bk= (select common_to_books_and_thesis.title_bk from common_to_books_and_thesis where common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis where common_to_books_and_thesis.title_bk='$name' or common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis,common_to_three,parallel_title where common_to_three.record_id=common_to_books_and_thesis.record_id and common_to_three.parallel_title_id=parallel_title.parallel_title_id and parallel_title.parallel_title='$name' or common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis,common_to_three,other_title where common_to_three.record_id=common_to_books_and_thesis.record_id and common_to_three.other_title=other_title.other_title_id and other_title.other_title='$name' or common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis,common_to_books_and_serial where common_to_books_and_thesis.record_id=common_to_books_and_serial.record_id and  common_to_books_and_serial.uniform_title='$name' group by common_to_books_and_thesis.title_bk )group by common_to_books_and_thesis.title_bk) group by common_to_books_and_thesis.title_bk) group by common_to_books_and_thesis.title_bk) group by common_to_books_and_thesis.title_bk)group by name_of_person.primary_element,common_to_books_and_thesis.title_bk,name_of_person.secondary_element,name_of_person.additional_element ORDER BY ".
	   "common_to_books_and_thesis.title_bk");

	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 
        echo("<H4 ALIGN=left>Books found matching search criteria :</H4><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");

       $result=pg_Exec($database,"SELECT ".
"count(rec_acc.acc_no),common_to_books_and_thesis.title_bk,name_of_person.primary_element,name_of_person.secondary_element,name_of_person.additional_element from rec_acc,name_of_person,common_to_books_and_thesis where rec_acc.record_id=common_to_books_and_thesis.record_id and name_of_person.person1=common_to_books_and_thesis.person1 and common_to_books_and_thesis.title_bk= (select common_to_books_and_thesis.title_bk from common_to_books_and_thesis where common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis where common_to_books_and_thesis.title_bk='$name' or common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis,common_to_three,parallel_title where common_to_three.record_id=common_to_books_and_thesis.record_id and common_to_three.parallel_title_id=parallel_title.parallel_title_id and parallel_title.parallel_title='$name' or common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis,common_to_three,other_title where common_to_three.record_id=common_to_books_and_thesis.record_id and common_to_three.other_title=other_title.other_title_id and other_title.other_title='$name' or common_to_books_and_thesis.title_bk=(SELECT common_to_books_and_thesis.title_bk from common_to_books_and_thesis,common_to_books_and_serial where common_to_books_and_thesis.record_id=common_to_books_and_serial.record_id and  common_to_books_and_serial.uniform_title='$name' group by common_to_books_and_thesis.title_bk )group by common_to_books_and_thesis.title_bk) group by common_to_books_and_thesis.title_bk) group by common_to_books_and_thesis.title_bk) group by common_to_books_and_thesis.title_bk)group by name_of_person.primary_element,common_to_books_and_thesis.title_bk,name_of_person.secondary_element,name_of_person.additional_element ORDER BY ".
	   "common_to_books_and_thesis.title_bk LIMIT $count1,$offset");
           
	    $name='';
	    $j=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,1);
		    $name1=pg_Result($result,$i,2);
		    $name2=pg_Result($result,$i,3);
		    $name3=pg_Result($result,$i,4);
		    $count=pg_Result($result,$i,0);
                 
		    $name .= $name1;
                    if($name2 !=''){
		        $name .=' ';
                	$name .=$name2;
		    }
                    if($name3 !=''){
		        $name .='.';
                	$name .=$name3;
		    }

                    $name .=',';
		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$j);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo (substr($name,0,strlen($name)-1));
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $count;
                	    echo("</b></TD></TR>");
		    }
		  
             }
        echo("</TABLE><FORM>");
	echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>");
	echo("<INPUT TYPE=HIDDEN NAME=wname VALUE='$wname'>");
	echo("<INPUT TPE=HIDDEN NAME=j VALUE='$j'>");
	echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
	?>
	<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
	<?
	$cam1=$offset+$count1;
        if($cam1<pg_NumRows($reach)){
             echo("<DIV ALIGN=LEFT><INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        echo("</DIV>");
	}
        echo("</TD><TD>");
	$cam=$offset-$count1;
	if($cam>=0){
	            echo("<DIV ALIGN=RIGHT>");
	                echo("<INPUT TYPE=SUBMIT NAME=Previous VALUE=Previous></DIV>");
	               }
	 echo("</TD></TR></TABLE>");
	echo("</FORM>");
	echo("<BR>");
	}
	break;
       case 'Call Number' :
       $reach=pg_Exec($database,"SELECT count(rec_acc.acc_no) ,".
	   "common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element ,name_of_person.secondary_element,".
	   "name_of_person.additional_element ".
	   "from rec_acc,common_to_three,common_to_books_and_thesis,map,".
	   "name_of_person where name_of_person.person1=map.person1 and ".
	   "map.person1=common_to_books_and_thesis.person1 and ".
	   "common_to_books_and_thesis.record_id=common_to_three.record_id ".
	   "and rec_acc.record_id=common_to_three.record_id ".
       "AND (common_to_three.subject_desc = '$name' ) ".
	   "GROUP BY common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element,name_of_person.secondary_element,".
	   "name_of_person.additional_element ORDER BY ".
	   "common_to_books_and_thesis.title_bk ");



	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 
        echo("<H2 ALIGN=left>Books found matching search criteria :<H2><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");

        $result=pg_Exec($database,"SELECT count(rec_acc.acc_no) ,".
        "common_to_books_and_thesis.title_bk,".
        "name_of_person.primary_element,name_of_person.secondary_element,".
        "name_of_person.additional_element ".
        "from rec_acc,common_to_three,common_to_books_and_thesis,map, ".
        "name_of_person where name_of_person.person1=map.person1 and ".
        "map.person1=common_to_books_and_thesis.person1 and ".
        "common_to_books_and_thesis.record_id=common_to_three.record_id ".
        "and rec_acc.record_id=common_to_three.record_id ".
        "AND (common_to_three.subject_desc = '$name' ) ".
        "GROUP BY common_to_books_and_thesis.title_bk,".
        "name_of_person.primary_element,name_of_person.additional_element,".
        "name_of_person.secondary_element ORDER BY ".
        "common_to_books_and_thesis.title_bk LIMIT $count1,$offset");

	    $name='';
	    $j=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,1);
		    $name1=pg_Result($result,$i,2);
		    $name2=pg_Result($result,$i,3);
		    $name3=pg_Result($result,$i,4);
		    $count=pg_Result($result,$i,0);
                 
		    $name .= $name1;
                    if($name2 !=''){
		        $name .=' ';
                	$name .=$name2;
		    }
                    if($name3 !=''){
		        $name .='.';
                	$name .=$name3;
		    }

                    $name .=',';
		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$j);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo (substr($name,0,strlen($name)-1));
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $count;
                	    echo("</b></TD></TR>");
		    }
		  
             }
	echo("</TABLE><FORM>");
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>");
	echo("<INPUT TYPE=HIDDEN NAME=j VALUE='$j'>");
	echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
	echo("<INPUT TYPE=HIDDEN NAME=wname VALUE='$wname'>");
	?>
	<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
	<?
	$cam1=$offset+$count1;
	if($cam1<pg_NumRows($reach)){	
             echo("<DIV ALIGN=LEFT><INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        echo("</DIV>");
	}
        echo("</TD><TD>");
	$cam=$offset-$count1;
        if($cam>=0){
                echo("<DIV ALIGN=RIGHT>");
                echo("<INPUT TYPE=SUBMIT NAME=Previous VALUE=Previous></DIV>");
                }
               echo("</TD></TR></TABLE>");
	echo("</FORM>");
echo("<BR>");
	}
	break;
       case 'Keywords' :
       $name=strtolower($name);
       $reach=pg_Exec($database,"SELECT count(rec_acc.acc_no),".
	   "common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element,name_of_person.secondary_element,".
	   "name_of_person.additional_element ".		  
	   "from rec_acc,common_to_three,common_to_books_and_thesis,map,".
	   "name_of_person where name_of_person.person1=map.person1 and ".
	   "map.person1=common_to_books_and_thesis.person1 and ".
	   "common_to_books_and_thesis.record_id=common_to_three.record_id ".
	   "and rec_acc.record_id=common_to_three.record_id ".
	   "and common_to_three.note LIKE '%$name%' ".
	   "GROUP BY common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element,name_of_person.additional_element,".
	   "name_of_person.secondary_element ORDER BY ".
	   "common_to_books_and_thesis.title_bk");

	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{
        echo("<H2 ALIGN=left>Books found matching search criteria :<H2><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");

	$result=pg_Exec($database,"SELECT count(rec_acc.acc_no),".
	   "common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element,name_of_person.secondary_element,".
	   "name_of_person.additional_element ".
	   "from rec_acc,common_to_three,common_to_books_and_thesis, ".
	   "name_of_person,map where name_of_person.person1=map.person1 and ".
	   "map.person1=common_to_books_and_thesis.person1 and ".
	   "common_to_books_and_thesis.record_id=common_to_three.record_id ".
	   "and rec_acc.record_id=common_to_three.record_id ".
	   "and common_to_three.note LIKE '%$name%' ".
	   "GROUP BY common_to_books_and_thesis.title_bk,".
	   "name_of_person.primary_element,name_of_person.additional_element,".
	   "name_of_person.secondary_element ORDER BY ".
	   "common_to_books_and_thesis.title_bk LIMIT $count1,$offset");

	    $name='';
	    $j=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,1);
		    $name1=pg_Result($result,$i,2);
		    $name2=pg_Result($result,$i,3);
		    $name3=pg_Result($result,$i,4);
		    $count=pg_Result($result,$i,0);
                 
		    $name .= $name1;
                    if($name2 !=''){
		        $name .=' ';
                	$name .=$name2;
		    }
                    if($name3 !=''){
		        $name .='.';
                	$name .=$name3;
		    }
                    $name .=',';
		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$j);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo (substr($name,0,strlen($name)-1));
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $count;
                	    echo("</b></TD></TR>");
		    }
		  
             }
	     echo("</TABLE><FORM>");
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>");
	echo("<INPUT TYPE=HIDDEN NAME=j VALUE='$j'>");
	echo("<INPUT TYPE=HIDDEN NAME=selection VALUE='$selection'>");
	echo("<INPUT TYPE=HIDDEN NAME=wname VALUE='$wname'>");
	?>
	<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
	<?
	$cam1=$offset+$count1;
	if($cam1<pg_NumRows($reach)){
		echo("<DIV ALIGN=LEFT>");
             echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next></DIV>");
        }
	echo("</TD><TD>");
	$cam=$offset-$count1;
	if($cam>=0){
		echo("<DIV ALIGN=RIGHT>");
		echo("<INPUT TYPE=SUBMIT NAME=Previous VALUE=Previous></DIV>");
		}
		echo("</TD></TR></TABLE>");
	echo("</FORM>");
	echo("<BR>");
	}
	break;
       case 'Journal Title' :

	//    $reach=pg_Exec($database,"SELECT ".

	  // "common_to_books_and_thesis.title_bk");

	if (pg_NumRows($reach) == 0){
		echo("<H3 ALIGN=CENTER> No Records Present Pertaining Your Search </H3>");
		echo("<H4 ALIGN=CENTER> Please Enter New Search.</H4>");
	}
	else{ 
        echo("<H2 ALIGN=left>Books found matching search criteria :<H2><BR>");
        echo("<TABLE width='90%' border='2' cellpadding='5' ALIGN=CENTER>");
        echo("<TR bgcolor='B0C4DE'>"); 
        echo("<TH>Sr.No</TH>");
        echo("<TH>Title Of Book</TH>");
        echo("<TH>Author Name</TH>");
        echo("<TH>Number of Copies</TH>");


//	$result=pg_Exec($database,"SELECT ".

	    $name='';
	    $j=0;
            for($i=0;$i<pg_NumRows($result);$i++){
		    $title=pg_Result($result,$i,1);
		    $name1=pg_Result($result,$i,2);
		    $name2=pg_Result($result,$i,3);
		    $name3=pg_Result($result,$i,4);
		    $count=pg_Result($result,$i,0);
                 
		    $name .= $name1;
                    if($name2 !=''){
		        $name .=' ';
                	$name .=$name2;
		    }
                    if($name3 !=''){
		        $name .='.';
                	$name .=$name3;
		    }
                    $name .=',';
		    if($i==(pg_NumRows($result)-1) || pg_Result($result,$i,1)!=pg_Result($result,($i+1),1)){
			    echo("<TR><TD ALIGN=CENTER><b>");
			    echo(++$j);
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $title;
			    echo("<b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo (substr($name,0,strlen($name)-1));
			    echo("</b></TD>");
			    echo("<TD ALIGN=CENTER><b>");
        	            echo $count;
                	    echo("</b></TD></TR>");
		    }
		  
             }
        echo("<INPUT TYPE=HIDDEN NAME=offset VALUE='$offset'>");
        echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>");
        if($offset+$count1<pg_NumRows($reach)){
             echo("<INPUT TYPE=SUBMIT NAME=Next VALUE=Next>");
        }
	echo("</TABLE>");
	echo("<BR>");
	}
	break;
       default :
	break;
       }
	$timeparts=explode(" ",microtime());
	$endtime=$timeparts[1].substr($timeparts[0],1);
	$notime=substr(($endtime-$starttime),0,6);
}	
    
	echo("<DIV ALIGN=RIGHT>");
        echo("<A HREF=search.html><h6>New Search</h6></a></DIV>");
	echo("<TABLE BORDER=0 WIDTH=100% ALIGN=CENTER><TR><TD BGCOLOR=#8517C0>");
	echo("<DIV ALIGN=RIGHT><FONT COLOR =WHITE>Your query took </FONT>");
	echo("<FONT COLOR=#FBFB17><U><i>  $notime  sec</i></U></FONT>");
	echo("<FONT COLOR=WHITE> to be executed.</FONT></DIV></TD></TR></TABLE>");
	?> <HR>
	<FORM METHOD=POST>
	<? echo("<INPUT TYPE=HIDDEN NAME=count1 VALUE='$count1'>"); ?>
	<INPUT TYPE=hidden VALUE=0 NAME=offset>
	<TABLE ALIGN=CENTER BORDER=2><TR><TD BGCOLOR=#6666cc>
	<TABLE ALIGN=CENTER WIDTH=75%><TR><TD>
	<INPUT NAME=name TYPE=TEXT></TD><TD><SELECT NAME=selection>
		<OPTION>Title</OPTION>
		<OPTION>Call Number</OPTION>
		<OPTION>Keywords</OPTION>
		<OPTION SELECTED>Author</OPTION></SELECT></TD></TR>
		<TABLE ALIGN=CENTER WIDTH=20%><TR><TD></TD><BR><TD>
		<INPUT TYPE=SUBMIT NAME=SUBMIT VALUE=SUBMIT></TD><TD>
		<INPUT TYPE=RESET NAME=RESET VALUE=RESET></TD></TR></TABLE>
		</TABLE>
	</TABLE>
	</TD></TR></TABLE>
	</FORM>
	
	 </BODY>
</HTML>

