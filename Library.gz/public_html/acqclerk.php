<HTML>
<HEAD><TITLE>Create a Acquisition  Clerk</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">

<?php
include("header.inc");
include("common.php");

if(authenticate_user($name, $password,$option)) {

       echo("<BR><HR>");
         echo("<DIV ALIGN = CENTER> <H1>Create a New Acquisition Clerk </H1></DIV>");
	 echo("<HR>");
?>
	 <TABLE ALIGN=CENTER><TR><TD>
         <FORM ACTION=acqclerkdisplay.php METHOD=POST>
         <b>Acq. Clerk Id :</b></TD><TD>
         <INPUT NAME=clerk_id TYPE=TEXT></TD></TR>
	 <TR><TD>
         <b>Password :</b></TD><TD>
         <INPUT NAME=passwd TYPE=password></TD></TR>
	 <TR><TD>
         <b>Verify Password :</b></TD><TD>
         <INPUT NAME=verify TYPE=password></TD></TR>
	 <TR><TD>
         <b>Surname :</b></TD><TD>
         <INPUT NAME=surname TYPE=text></TD></TR>
	 <TR><TD>
         <b>First Name :</b></TD><TD>
         <INPUT NAME=first_name TYPE= text ></TD></TR>
	 <TR><TD>
	
         <b> Designation :</b></TD><TD>
         <INPUT NAME=status TYPE=text ></TD></TR>
	 <TR><TD>
        
         <b>Temporary Address :</b></TD><TD>
         <INPUT NAME=temporary_address TYPE=text></TD></TR>
	 <TR><TD>
         Permanent Address :</TD><TD>
         <INPUT NAME=permanant_address TYPE=text></TD></TR>
	 <TR><TD>
         Phone :</TD><TD>
         <INPUT NAME=phone TYPE=text VALUE=0></TD></TR>
	 <TR><TD>
         E-mail :</TD><TD>
         <INPUT NAME=email TYPE=text ><BR><BR></TD></TR>
	 <TR><TD>
         <b>Date Of Joining :</b></TD><TD>
         <SELECT NAME=date_of_registration_mm >
	 <OPTION><None>	 <OPTION VALUE='1'>Jan <OPTION VALUE='2'>Feb <OPTION VALUE='3'>Mar <OPTION VALUE='4'>Apr <OPTION VALUE='5'>May <OPTION VALUE='6'>Jun <OPTION VALUE='7'>Jul <OPTION VALUE='8'>Aug <OPTION VALUE='9'>Sep <OPTION VALUE='10'>Oct <OPTION VALUE='11'>Nov <OPTION VALUE='12'>Dec
	 </SELECT>             
         <SELECT NAME=date_of_registration_dd >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
         <SELECT NAME=date_of_registration_yy >
	 <OPTION><None>	 <OPTION>1990 <OPTION>1991 <OPTION>1992 <OPTION>1993 <OPTION>1994 <OPTION>1995 <OPTION>1996 <OPTION>1997 <OPTION>1998 <OPTION>1999 <OPTION>2000 <OPTION>2001 <OPTION>2002<OPTION>2003<OPTION>2004<OPTION>2005<OPTION>2006<OPTION>2007<OPTION>2008<OPTION>2009<OPTION>2010<OPTION>2011<OPTION>2012<OPTION>2013<OPTION>2014<OPTION>2015<OPTION>2016<OPTION>2017<OPTION>2018<OPTION>2019
	 </SELECT></TD></TR></TABLE><BR>

	 <DIV ALIGN=CENTER>

         <BR><HR><BR>
         <INPUT NAME=display TYPE=submit VALUE=Display>
	 </DIV>
         </FORM> <BR>
	  <?
      echo("<FORM ACTION=acqclerk.php>"); 
	  echo("<DIV ALIGN=CENTER>");
      echo("<INPUT NAME=reset TYPE=SUBMIT VALUE=Reset>");
	  echo("</DIV>");
      echo("</FORM> <BR><HR>");

	  echo("<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>");
	  echo("<A HREF=admin.php>Return to home page</A></TD><TD>");
	  echo("<A HREF=logout.php>Sign Out</A></TD></TR>");
	  echo("</TABLE>");


	}else{
	echo("<BR><HR>");
	echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
	echo("<FORM ACTION=login.html>"); 
	      echo("<DIV ALIGN=RIGHT>");
	      echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
	      echo("</DIV>");
	echo("</FORM>");
	}
?>
</BODY>
</HTML> 







