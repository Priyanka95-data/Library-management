<HTML>
         <HEAD><TITLE>Making entry for a Book.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
	require("header.inc");
if($acq_clerk){
       echo("<IMG ALIGN=LEFT SRC=bookworm.gif> <BR>");
         echo("<DIV ALIGN = CENTER> <H1>Enter Into Acquisition Database </H1></DIV>");
         echo("<HR><DIV ALIGN=CENTER>");
	 echo("<H3>");
         echo("Use '#' sign to separate the names where ever multiple entries are required");
         echo("</H3></DIV>");
	 echo("<HR>");
         echo("<BR>");

$database = pg_connect("dbname=lms user=postgres");

if($Display)
{
    	$result2 = pg_Exec($database,
        "INSERT INTO acquisition VALUES ('$orderno','$acq_clerk','$date_of_arival','$invoiceno')");
}
        	$result = pg_Exec($database,
        	"begin work;");

     	$result = pg_Exec($database,
     " SELECT order_now.vendor_id,book_details.title_bk_details,book_details.author_bk_details,book_details.isbn_bk_details,book_details.edition_bk_details,book_details.publisher_bk_details,book_details.no_of_copies,book_details.book_details from book_details,order_now where book_details.books_details=order_now.book_details and order_now.order_no='$orderno' ");


        $k=pg_NumRows($result);

if($j >= $k)
{
       echo("<FORM ACTION=acquisition.php METHOD=POST>");
   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");


     	$result1 = pg_Exec($database,
        "UPDATE invoice_details set amt_paid='$amt' where invoice_no='$invoiceno' ");



         echo("<INPUT NAME=acq_clerk TYPE=HIDDEN VALUE='$acq_clerk'>");
         echo("<INPUT NAME=temp TYPE=HIDDEN VALUE=1>");
         echo("<INPUT NAME=orderno TYPE=HIDDEN VALUE='$orderno'>");
         echo("<DIV ALIGN = CENTER>");
         echo("<INPUT NAME=Acquisition TYPE=SUBMIT VALUE='Acquisition'>");
         echo("</DIV>");
         echo("</FORM>");

       echo("<FORM ACTION=invoice.php METHOD=POST>");
         echo("<INPUT NAME=acq_clerk TYPE=HIDDEN VALUE='$acq_clerk'>");
         echo("<DIV ALIGN = CENTER>");
         echo("<INPUT NAME=Invoice TYPE=SUBMIT VALUE='Invoice'>");
         echo("<INPUT NAME=temp TYPE=HIDDEN VALUE=1>");
         echo("</DIV>");
         echo("</FORM>");

}
else
{
 for($i=0; $i<pg_NumRows($result);$i++) {
if($i == $l){
       echo("<FORM ACTION=acquisitionbookdisplay.php METHOD=POST>");
         echo("<BR>");

                $vendor=pg_Result($result,$i,0);
                $title=pg_Result($result,$i,1);
                $author=pg_Result($result,$i,2);
                $isbn=pg_Result($result,$i,3);
                $edition=pg_Result($result,$i,4);
                $publisher=pg_Result($result,$i,5);
                $copies=pg_Result($result,$i,6);
                $book=pg_Result($result,$i,7);
         $titleb=$title;

   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");
         echo("<INPUT NAME=book TYPE=HIDDEN VALUE='$book'>");
         echo("<INPUT NAME=j TYPE=HIDDEN VALUE='$j'>");
         echo("<INPUT NAME=l TYPE=HIDDEN VALUE='$l'>");
         echo("<INPUT NAME=titleb TYPE=HIDDEN VALUE='$titleb'>");
         echo("<INPUT NAME=orderno TYPE=HIDDEN VALUE='$orderno'>");
         echo("<INPUT NAME=acq_clerk TYPE=HIDDEN VALUE='$acq_clerk'>");
         echo("<INPUT NAME=amt TYPE=HIDDEN VALUE='$amt'>");
         echo("<TABLE>");
         echo("<TD></TD><b><TD>Title Of A Book * :</b></TD>");
         echo("<TD><INPUT NAME=title TYPE=TEXT VALUE='$title'></TD><TR> ");
         echo("<TD></TD><b><TD>Author Of A Book * :</b></TD>");
         echo("<TD><INPUT NAME=author TYPE=TEXT VALUE='$author'></TD><TR> ");
         echo("<TD></TD><b><TD>ISBN Of A Book :</b></TD>");
         echo("<TD><INPUT NAME=isbn TYPE=TEXT VALUE='$isbn'></TD><TR> ");
         echo("<TD></TD><b><TD>Edition No. Of A Book  :</b></TD>");
         echo("<TD><INPUT NAME=edition TYPE=TEXT VALUE='$edition'></TD><TR> ");
         echo("<TD></TD><b><TD>Publisher Of A Book  :</b></TD>");
         echo("<TD><INPUT NAME=publisher TYPE=TEXT VALUE='$publisher'></TD><TR> ");
         echo("<TD></TD><b><TD>No. Of Copies * :</b></TD>");
         echo("<TD><INPUT NAME=copies TYPE=TEXT VALUE='$copies'></TD><TR> ");
         echo("<TD></TD><b><TD>Price Per Book. * :</b></TD>");
         echo("<TD><INPUT NAME=price_per_book TYPE=TEXT ></TD><TR> ");
         echo("<TD></TD><b><TD>Discount * :</b></TD>");
         echo("<TD><INPUT NAME=discount TYPE=TEXT ></TD><TR></TABLE><BR><HR><BR><DIV ALIGN=CENTER> ");
         echo("<INPUT NAME=Display TYPE=SUBMIT VALUE='Display'><BR><BR></DIV>");

         echo("</FORM>");

       echo("<FORM ACTION=acquisitiondatabase.php METHOD=POST>");
         echo("<BR>");
         echo("<INPUT NAME=title TYPE=HIDDEN VALUE='$title'>");
         echo("<INPUT NAME=author TYPE=HIDDEN VALUE='$author'>");
         echo("<INPUT NAME=publisher TYPE=HIDDEN VALUE='$publisher'>");
         echo("<INPUT NAME=edition TYPE=HIDDEN VALUE='$edition'>");
         echo("<INPUT NAME=isbn TYPE=HIDDEN VALUE='$isbn'>");
         echo("<INPUT NAME=copies TYPE=HIDDEN VALUE='$copies'>");

         echo("<INPUT NAME=amt TYPE=HIDDEN VALUE='$amt'>");
         echo("<INPUT NAME=book TYPE=HIDDEN VALUE='$book'>");
         echo("<INPUT NAME=acq_clerk TYPE=HIDDEN VALUE='$acq_clerk'>");
         echo("<INPUT NAME=titleb TYPE=HIDDEN VALUE='$titleb'>");
          $j=$j+1;
         echo("<INPUT NAME=j TYPE=HIDDEN VALUE='$j'>");
         echo("<INPUT NAME=l TYPE=HIDDEN VALUE='$l'>");
         echo("<INPUT NAME=titleb TYPE=HIDDEN VALUE='$titleb'>");

          echo("<INPUT NAME=orderno TYPE=HIDDEN VALUE='$orderno'>");

   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival ><DIV ALIGN=CENTER>");

   echo("<INPUT NAME=Next TYPE=SUBMIT VALUE='Next'><BR><BR>");
               echo("</DIV>");
         echo("</FORM>");

}
}
}
  }
?>
</body>
</html>






