<HTML>
<HEAD><TITLE>Clerk Password Updated Sucessfully</TITLE></HEAD>
<BODY BGCOLOR="#18097F" TEXT="#F97235">
<?php
	require("header.inc"); 
	if($acq_clerk){
		if($mpasswd==$mvpasswd){
		$mpasswd1=md5($mpasswd);
		$database=pg_connect("dbname=lms user=pro");
		$result=pg_Exec($database,"UPDATE clerk ".
		"SET clerk_passwd= '$mpasswd1' WHERE clerk='$acq_clerk'");
		echo("<BR><BR><HR>");
		echo("<BR><H2 ALIGN=CENTER>Updated Password Sucessfully</H2>");
		}
		else{
		echo("<H2 ALIGN=CENTER>Couldn't Update Password </H2>");
		}
	echo("<DIV ALIGN=RIGHT>");
	echo("<A HREF=login.html>Logout</A>");
	echo("</DIV>");
	}
	else{
	header("Location:http://$HTTP_HOST/~pro/error3.html");
	}
?>
</BODY>
</HTML>
