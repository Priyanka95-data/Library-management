<HTML>
<HEAD><TITLE>Add new serials</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">
<hr><br>
         <DIV ALIGN = CENTER><H1>Add new serials to database </H1></DIV>
         <FORM ACTION=serialdisplay5.php METHOD=POST>
         <HR><BR>
<?php
        $database=pg_connect("dbname=lms user=pro password=pro");
?>
   <TABLE>
    <TR><TD>
         <b>Bibliographic Level :</b>
            <TD><SELECT NAME="bibliographic_level_desc1">
             <OPTION value=Monograph>Monograph
             <OPTION value=Serial>Serial
             <OPTION value='Component part'>Component Part
             <OPTION value=Multivolume>Multivolume
             <OPTION value='Made-up Collection'>Made-up Collection
            </SELECT></TD></TR><TR><TD>
         <b>Location :</b></TD>
            <TD><INPUT NAME="location1" TYPE="text" SIZE="15" MAXLENGTH = "15">
</TD></TR>
          <TR><TD><b>Date Of Entry :</b></TD>
          <TD><SELECT NAME="date_of_entry_mm1" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>
          <SELECT NAME="date_of_entry_dd1" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="date_of_entry_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ></TD></TR><TR><TD>
          <b>Language :</b></TD>
             <TD><INPUT NAME="language_code1" TYPE="text" SIZE="50" VALUE="English" >
                          </TD></TR><TR><TD>
          <b>Script :</b></TD>
            <TD><SELECT NAME="script1">
               <OPTION value=Roman>Roman
               <OPTION  value=Cyrillic>Cyrillic
               <OPTION value=Japanese-script unspecified>Japanese-script unspecified
               <OPTION value=Japanese-kanji>Japanese-kanji
               <OPTION value=Chinese>Chinese
               <OPTION value=Arabic>Arabic
               <OPTION value=Greek>Greek
               <OPTION value=Hebrew>Hebrew
               <OPTION value=Thai>Thai
               <OPTION value=Devanagari>Devanagari
               <OPTION value=Korean>Korean
               <OPTION value=Tamil>Tamil
               <OPTION value=Other>Other
               </SELECT></TD></TR><TR><TD>

           <b>Translation :</b></TD>
             <TD><INPUT NAME="translation_code1" TYPE="text" SIZE="20" VALUE="English"> </TD></TR><TR><TD>
    <b>Physical Medium :</b></TD>
    <TD>          <UL>
                <LI><INPUT TYPE="checkbox" NAME="paper1" VALUE="paper" CHECKED> Paper
                <LI><INPUT TYPE="checkbox" NAME="magnetic1" VALUE="magnetic"> Magnetic
                <LI><INPUT TYPE="checkbox" NAME="film1" VALUE="film"> Film
                <LI><INPUT TYPE="checkbox" NAME="laser1" VALUE="laser/optical"> Laser/Optical
                <LI><INPUT TYPE="checkbox" NAME="braille1" VALUE="braille"> Braille
                <LI><INPUT TYPE="checkbox" NAME="other1" VALUE="other"> Other
              </UL></TD></TR><TR><TD>

            <b>ISSN :</b></TD>
             <TD><INPUT NAME="issn1" TYPE="text" SIZE="20" > </TD></TR><TR><TD>
            <b> Code :</b></TD>
             <TD><INPUT NAME="coden1" TYPE="text" SIZE="20" > </TD></TR><TR><TD>
            <b>Title :</b></TD>
                <TD><INPUT NAME="title_sr1" TYPE="text" SIZE="50"></TD></TR><TR>
<TD>            <b>Abbreviated Title :</b></TD>
                <TD><INPUT NAME="abbreviated_title_sr1" TYPE="text" SIZE="50"></TD></TR>
<TR><TD>            <b>Language :</b></TD>
                <TD><INPUT NAME="language_code_title_sr1" TYPE="text" SIZE="30" VALUE="English" ></TD></TR><TR><TD>
            <b> Key Title :</b></TD>
                <TD><INPUT NAME="key_title1" TYPE="text" SIZE="50"></TD></TR>
		<TR><TD>
            <b>Abbreviated Title :</b></TD>
                <TD><INPUT NAME="abbreviated_title_kt1" TYPE="text" SIZE="50"></TD></TR><TR><TD>
            <b>Language :</b></TD>
                <TD><INPUT NAME="language_code_title_kt1" TYPE="text" SIZE="30" VALUE="English" ></TD></TR><TR><TD>
               <b> Edition Statement :</b></TD>
                <TD><INPUT NAME="edition_statt_sr1" TYPE="text" SIZE="30" > </TD></TR><TR><TD>
               <b>Language :</b></TD>
                <TD><INPUT NAME="language_code_edition_statt_sr1" TYPE="text" SIZE="30" VALUE="English" > </TD></TR><TR><TD>

            <b>Date Of Publication :</b></TD>
            <TD><SELECT NAME="date_of_publication_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>
         <SELECT NAME="date_of_publication_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	  <INPUT NAME="date_of_publication_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ></TD></TR><TR><TD>
             <b>Subject Descriptor :</b></TD>
                  <TD><INPUT NAME="subject_desc1" TYPE="text" SIZE="50"></TD></TR><TR><TD>
             <b>Accession No. :</b></TD>
                  <TD><INPUT NAME="acc_no1" TYPE="text" SIZE="50"></TD></TR>
 <TR><TD>
             <b>Accession No. Of Reference Book  :</b></TD>
                  <TD><INPUT NAME="reference" TYPE="text" SIZE="50"></TD></TR>
 <TR><TD>
             <b>Accession No. Of Study Room Book  :</b></TD>
                  <TD><INPUT NAME="study" TYPE="text" SIZE="50"></TD></TR>
<TR><TD>


             <b>   Parallel Title : </b></TD>
               <TD><INPUT NAME="parallel_title1" TYPE="text" SIZE="50" ></TD></TR><TR><TD>
              <b> Language :</b></TD>
                <TD><INPUT NAME="language_code_parallel_title1" TYPE="text" SIZE="30" ></TD></TR><TR><TD>

             <b>  Other Title :</b></TD>
                <TD><INPUT NAME="other_title1" TYPE="text" SIZE="50" ></TD></TR><TR><TD>
              <b> Uniform Title :</b></TD>
                <TD><INPUT NAME="uniform_title1" TYPE="text" SIZE="50" > </TD></TR><TR><TD>
               <b>Language :</b></TD>
                <TD><INPUT NAME="language_code_uniform_title1" TYPE="text" SIZE="30" > </TD></TR><TR><TD>


            <b>   PLACE AND NAME OF PUBLISHER :
                  </TD></TR>
 <TR><TD>
                Name :
                  <TD><INPUT NAME="publisher_name1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT publisher_name from place_and_publisher");
        echo("<SELECT NAME=publisher_name2 value='$publisher_name2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>  <TR><TD>
                Place :</TD>
                  <TD><INPUT NAME="place_of_publisher1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT place from place_and_publisher");
        echo("<SELECT NAME=place_of_publisher2 value='$place_of_publisher2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR>  <TR><TD>

                Address :</TD>
                  <TD><INPUT NAME="address_of_publisher1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT address from place_and_publisher");
        echo("<SELECT NAME=address_of_publisher2 value='$address_of_publisher2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> <TR>

<TD>
                Country :</TD>
                  <TD><INPUT NAME="country_of_publisher1" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT country_desc from country");
        echo("<SELECT NAME=country_of_publisher2 value='$country_of_publisher2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> <TR><TD>

                PLACE AND NAME OF DISTRIBUTOR :</TD></TR>
                  
 <TR><TD>
                Name :</TD>
                  <TD><INPUT NAME="name_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT name_of_distributor from place_and_distribution");
        echo("<SELECT NAME=name_of_distributor2 value='$name_of_distributor2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> 

 <TR><TD>
                Place :
             </TD><TD><INPUT NAME="place_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT place_of_distributor from place_and_distribution");
        echo("<SELECT NAME=place_of_distributor2 value='$place_of_distributor2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> 

 <TR><TD>
                Address :
              </TD><TD><INPUT NAME="address_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT address_of_distributor from place_and_distribution");
        echo("<SELECT NAME=address_of_distributor2 value='$address_of_distributor2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> 

 <TR><TD>
                Country :
             </TD><TD><INPUT NAME="country_of_distributor1" TYPE="text" SIZE="50" >
</TD><TD><?php
        $result=pg_Exec($database,"SELECT country_desc from country");
        echo("<SELECT NAME=country_of_distributor2 value='$country_of_distributor2'>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> 


      <TR><TD> <b>INVOICE DETAILS :</TD></TR>
               <TR><TD> <b>Invoice No. : </b></TD>
               <TD><INPUT NAME="invoice_no1" TYPE="text" SIZE="30"></TD></TR>

              <TR><TD>  <b>Frequency :</b></TD>
            <TD><SELECT NAME="frequency1">
               <OPTION value=Annual>Annual
               <OPTION value=Every two months>Every two months
               <OPTION value=Biweekly>Biweekly
               <OPTION value=Daily>Daily
               <OPTION value=Fortnightly>Fortnightly
               <OPTION value=Irregularly>Irregularly
               <OPTION value=Weekly>Weekly
               <OPTION value=Monthly>Monthly
               <OPTION value=Quarterly>Quarterly
               <OPTION value='Twice annually'>Twice annually
               <OPTION value='Twice monthly'>Twice monthly
               <OPTION value='Twice weekly'>Twice weekly
               <OPTION value='3 times a month'>3 times a month
               <OPTION value='3 times a year'>3 times a year
               </SELECT></TD></TR><TR><TD>
              <b>Date Of Frequency : </b></TD>
                <TD><SELECT NAME="date_of_fre_mm1" >
	 <OPTION><None>	 <OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	 </SELECT>
         <SELECT NAME="date_of_fre_dd1" >
	 <OPTION><None>	 <OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	 </SELECT>
	  <INPUT NAME="date_of_fre_yy1" TYPE="text" SIZE="4" MAXLENGTH="4" ></TD></TR>
<TR><TD>





                <b>CLASSIFICATION SCHEME NOTATION </TD></TR><TR><TD>
                Notation :</b></TD>
                  <TD><INPUT NAME="notation1" TYPE="text" SIZE="30"></TD></TR>
		  <TR><TD>
                <b>Edition_no : </b></TD>
     <TD><INPUT NAME="edition_no1" TYPE="text" SIZE="50"></TD></TR><TR><TD>
               <b> Identification Of Classification Code ;</b></TD>
        <TD><INPUT NAME="identification1" TYPE="text" SIZE="50"></TD></TR>
<TR><TD>                <b>Classification Scheme Code :</b></TD>
                  <TD><SELECT NAME="c_s_c_desc1">
                   <OPTION value='D'>Dewey Decimal
                   <OPTION value='C'>Colon Classification
                   <OPTION value='L'>Library Of Congress
                   <OPTION value='U'>Universal Decimal
                  </SELECT></TD></TR>
               <BR>
                <TR><TD>Keywords :</TD> 
                  <TD><INPUT NAME="note1" TYPE="text" SIZE="50"></TD></TR>
                <TR><TD>Note On Bibliography :</TD>
                  <TD><INPUT NAME="bibliographic_note1" TYPE="text" SIZE="50">
              </TD></TR> 
   </TABLE>

          <BR><HR><BR> 
		  <DIV ALIGN=CENTER>
                    <TD><INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>
    </FORM>
		  <BR>

     <FORM ACTION=serial.php>
       <DIV ALIGN=CENTER>
		<INPUT NAME="reset" TYPE="submit" VALUE="Reset">
	     </DIV>
  </FORM>

      <BR><HR><BR> 
<TABLE ALIGN=CENTER WIDTH=100%><TR><TD>
    <DIV ALIGN=LEFT>
    <A HREF='acqclerkentry.php'><b><FONT COLOR=red>
    	Return to home page</FONT></b></A>
    </DIV></TD><TD>
    <DIV ALIGN=right>
    <A HREF=logout.php><b><FONT COLOR=red>Logout</FONT></B></A>
    </DIV></TD></TR></TABLE>

</BODY>
</HTML>






