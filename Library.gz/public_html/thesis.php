<HTML>
<HEAD><TITLE>Making entry for Book.</TITLE></HEAD>
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?php
include("header.inc");
include("common.php");
 if(authenticate_user($name,$password,$option)){
          
        include("thesis1.php");
     
	}
	else{
	Header("Location:http://$HTTP_HOST/~pro/authfail.html");
	}
?>
</BODY>
</HTML> 







