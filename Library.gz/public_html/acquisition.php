<HTML>
<HEAD><TITLE>Acquisition of a book.</TITLE></HEAD>
<BODY BGCOLOR="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">
<?  
if ($acq_clerk){

 if($temp == 0)
{
include("acquisitiondetails.php");
}

         echo("<DIV ALIGN = CENTER> <H1>Acquisitiion of a book </H1>");
         echo("<FORM ACTION=acquisitiondisplay.php METHOD=POST><BR>"); 

        echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");


	$database = pg_connect("dbname=lms user=postgres");
        $result = pg_Exec($database,
        "SELECT amt_paid from invoice_details where invoice_no='$invoiceno' ");
   for($i=0; $i<pg_NumRows($result);$i++) {
                $amt=pg_Result($result,$i,0);
        
        }
	   echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt >"); 
         echo("<b> Order No. :</b>");
         echo("<INPUT NAME=orderno TYPE=text SIZE=15 MAXLENGTH = 15><BR>");
	   echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); 
	   echo("<INPUT TYPE=hidden VALUE='0' NAME=j >"); 
         echo("<INPUT TYPE=hidden VALUE='0' NAME=l >"); 
	 echo("</DIV><HR>");
	 echo("<DIV ALIGN=CENTER>");
         echo("<INPUT NAME=display TYPE=submit VALUE=Display>");
	 echo("</DIV>");
         echo("</FORM> <BR>");
	 echo("<FORM ACTION=acquisition.php>"); 
	 echo("<DIV ALIGN=CENTER>");
	   echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk >"); 
         echo("<INPUT NAME=reset TYPE=submit VALUE=Reset>");
	 echo("</DIV>");
	 echo("</FORM>");
	}else{
	echo("<BR><HR>");
	echo("<h1 ALIGN=CENTER> Please Enter Through The Login Form</h1><HR>");
	echo("<FORM ACTION=login.html>"); 
	      echo("<DIV ALIGN=RIGHT>");
	      echo("<INPUT NAME=Login TYPE=SUBMIT VALUE=Login>");
	      echo("</DIV>");
	echo("</FORM>");
	}
?>
</BODY>
</HTML> 
 
