<HTML>
<HEAD><TITLE>Orders</TITLE></HEAD>
<BODY bgcolor="#8AFF90" text="#316431">


<?php
include("header.inc");
include("common.php");
if(authenticate_user($name, $password, $option)){	
//if($clerk_id){
//       echo("<IMG ALIGN=LEFT SRC=bookworm.gif> <BR>");
         echo("<DIV ALIGN = CENTER> <H1>Orders</H1></DIV>");
   $database=pg_connect("dbname=lms user=pro password=pro");

	 echo("<HR>");
         echo("<BR>");
       echo("<FORM ACTION=orderdisplay.php METHOD=POST>");
         echo("<BR>");
          echo("<TABLE WIDTH=80% ALIGN=CENTER><TR>");
  echo("<TD><b>Order no. :</b></TD>");
         echo("<TD><INPUT NAME=orderno TYPE=TEXT></TD></TR><TR>");
?>
<TD>

               <b> Name of vendor :</b></TD>
                  <TD><INPUT NAME="name_of_vendor" TYPE="text" SIZE="50">
</TD><TD><?php

        $result=pg_Exec($database,"SELECT vendor_name from vendor");
        echo("<SELECT NAME=name_of_vendor1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> <BR>

 <TR><TD>
               <b> City  :</b></TD>
                  <TD><INPUT NAME="city" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT vendor_city from vendor");
        echo("<SELECT NAME=city1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> <BR>

 <TR><TD>
                Phone no. :</TD>
                  <TD><INPUT NAME="phone" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT vendor_ph_no from vendor");
        echo("<SELECT NAME=phone1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?></TD></TR> <BR>

 <TR><TD>
                E-mail :</TD>
                  <TD><INPUT NAME="email" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT vendor_email from vendor");
        echo("<SELECT NAME=email1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> <BR>


 <TR><TD>
                Reliability of vendor :
               </TD> <TD><INPUT NAME="priority" TYPE="text" SIZE="50">
</TD><TD><?php
        $result=pg_Exec($database,"SELECT priority from vendor");
        echo("<SELECT NAME=priority1>");
        for($i=0; $i<pg_NumRows($result);$i++) {
                $result1=pg_Result($result,$i,0);
                echo("<OPTION> $result1");
        }
        echo("</SELECT>");
?> </TD></TR> <BR>
<TR><TD>
  <b>Order date :</b>
        </TD>  <TD><SELECT NAME="date_of_entry_mm" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>
          <SELECT NAME="date_of_entry_dd" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="date_of_entry_yy" TYPE="text" SIZE="4" MAXLENGTH="4" ></TD></TR>

<TR><TD>

 <b>Estimated arrival date :</b>
        </TD>  <TD><SELECT NAME="date_of_arival_mm" >
	  <OPTION><None><OPTION VALUE="1">Jan <OPTION VALUE="2">Feb <OPTION VALUE="3">Mar <OPTION VALUE="4">Apr <OPTION VALUE="5">May <OPTION VALUE="6">Jun <OPTION VALUE="7">Jul <OPTION VALUE="8">Aug <OPTION VALUE="9">Sep <OPTION VALUE="10">Oct <OPTION VALUE="11">Nov <OPTION VALUE="12">Dec
	  </SELECT>
          <SELECT NAME="date_of_arival_dd" >
	  <OPTION><None><OPTION>1 <OPTION>2 <OPTION>3 <OPTION>4 <OPTION>5 <OPTION>6 <OPTION>7 <OPTION>8 <OPTION>9 <OPTION>10 <OPTION>11 <OPTION>12<OPTION>13<OPTION>14<OPTION>15<OPTION>16<OPTION>17<OPTION>18<OPTION>19<OPTION>20<OPTION>21<OPTION>22<OPTION>23<OPTION>24<OPTION>25<OPTION>26<OPTION>27<OPTION>28<OPTION>29<OPTION>30<OPTION>31
	  </SELECT>
	  <INPUT NAME="date_of_arival_yy" TYPE="text" SIZE="4" MAXLENGTH="4" ></TD></TR>
<TR><TD>
<?php

  echo("Cheque no./Draft no. :");
         echo("</TD><TD><INPUT NAME=draft TYPE=TEXT></TD></TR>");
?>
<TR><TD>


<?php	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id>");

 ?>
</TD></TR>
                  </TABLE>      <HR>
		  <DIV ALIGN=CENTER>
                    <INPUT NAME="display" TYPE="submit" VALUE="Display">
		  </DIV>

                  </FORM> <BR>
 		  <FORM ACTION=order.php>

<?php	echo("<INPUT TYPE=hidden VALUE='$clerk_id' NAME=clerk_id>");

 ?>

		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>

    <BR><HR>
    <DIV ALIGN=RIGHT>
    <A HREF='acqclerkentry.php'>Return to home page</A>
    </DIV>


 <?php
 }
  else
 {
  echo("  <H2>Sorry You Are Not Allowed To Order</H2>");
 }
 ?>
      </BODY>
</HTML>






