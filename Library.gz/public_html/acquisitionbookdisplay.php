<HTML>
  
<body bgcolor="#C5A9FF" text="#393939" link="#8173FF" vlink="#F428FF" alink="#2F9424">


	<HR>
	<BR>
	<DIV ALIGN=CENTER>
	<H1>Please Verify The Information. <H1>
	</DIV>

<?php

  if( $price_per_book && $title && $author && $copies)
 { 
            echo("<FORM ACTION=acquisitionbookdatabase.php>");
   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");
    echo("<INPUT NAME=book TYPE=HIDDEN VALUE='$book'><BR><BR>");
    echo("<INPUT TYPE=hidden VALUE='$orderno ' NAME=orderno >");
    echo("<INPUT TYPE=hidden VALUE='$titleb ' NAME=titleb >");
    echo("<INPUT TYPE=hidden VALUE='$title ' NAME=title >");
    echo("<INPUT TYPE=hidden VALUE='$isbn ' NAME=isbn >");
    echo("<INPUT TYPE=hidden VALUE='$author ' NAME=author >");
    echo("<INPUT TYPE=hidden VALUE='$copies ' NAME=copies >");
    echo("<INPUT TYPE=hidden VALUE='$edition ' NAME=edition >");
    echo("<INPUT TYPE=hidden VALUE='$publisher ' NAME=publisher >");
    echo("<INPUT TYPE=hidden VALUE='$book' NAME=book>");
    echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk>");
    echo("<INPUT TYPE=hidden VALUE='$price_per_book' NAME=price_per_book>");
    echo("<INPUT TYPE=hidden VALUE='$discount' NAME=discount>");
    echo("<INPUT NAME=j TYPE=HIDDEN VALUE='$j'><BR><BR>"); 
    echo("<INPUT NAME=l TYPE=HIDDEN VALUE='$l'><BR><BR>"); 

   echo("<TABLE width='70%' border='2' cellpadding='5' ALIGN=CENTER><TR><TD>");
   echo("<b>Title Of Book :</TD><TD>$title</TR></b>");
   echo("<b>Author Of Book :</TD><TD>$author</TR></b>");
   echo("<b>ISBN :</TD><TD>$isbn</TR></b>");
   echo("<b>Publisher Of Book :</TD><TD>$publisher</TR></b>");
   echo("<b>Edition Of Book :</TD><TD>$edition</TR></b>");
   echo("<b>No. Of Copies :</TD><TD>$copies</TR></b>");
   echo("<b>Price Per Book :</TD><TD>$price_per_book</TR></b>");
   echo("<b>Discount :</TD><TD>$discount</TR></b>");
   $total=$copies*$price_per_book;
   $net=$total-$discount;
   $amt=$amt+$net;
   echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt>");
   echo("<INPUT TYPE=hidden VALUE='$total' NAME=total>");
   echo("<INPUT TYPE=hidden VALUE='$net' NAME=net>");
   echo("<b>Total Price :</TD><TD>$total</TR></b>");
   echo("<b>Net Price :</TD><TD>$net</TR></b>"); 
   echo("<b>Grand Total :</TD><TD>$amt</TR></b>"); 

 ?>
		  <DIV ALIGN=CENTER>
		        <INPUT NAME="Enter" TYPE="submit" VALUE="Enter">
		  </DIV>


  </FORM> <BR>
  <FORM ACTION=acquisitionbookdisplay.php> 
  
<?php	
   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");
    echo("<INPUT NAME=book TYPE=HIDDEN VALUE='$book'><BR><BR>");
    echo("<INPUT NAME=j TYPE=HIDDEN VALUE='$j'><BR><BR>"); 
    echo("<INPUT NAME=l TYPE=HIDDEN VALUE='$l'><BR><BR>"); 
    echo("<INPUT TYPE=hidden VALUE='$titleb ' NAME=titleb >");
    echo("<INPUT TYPE=hidden VALUE='$title ' NAME=title >");
    echo("<INPUT TYPE=hidden VALUE='$isbn ' NAME=isbn >");
    echo("<INPUT TYPE=hidden VALUE='$author ' NAME=author >");
    echo("<INPUT TYPE=hidden VALUE='$copies ' NAME=copies >");
    echo("<INPUT TYPE=hidden VALUE='$edition ' NAME=edition >");
    echo("<INPUT TYPE=hidden VALUE='$publisher ' NAME=publisher >");
    echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk>");
    echo("<INPUT TYPE=hidden VALUE='$price_per_book' NAME=price_per_book>");
    echo("<INPUT TYPE=hidden VALUE='$discount' NAME=discount>");
    echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt>");
    echo("<INPUT TYPE=hidden VALUE='$total' NAME=total>");
    echo("<INPUT TYPE=hidden VALUE='$net' NAME=net>");
    echo("<INPUT TYPE=hidden VALUE='$orderno ' NAME=orderno >");


 ?>

		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>
<?php
}
else
{
 
 echo("<H2> Invalid Data </H2>");
?>
  <FORM ACTION=acquisitiondisplay.php> 
  
<?php
   echo("<INPUT TYPE=hidden VALUE='$invoiceno ' NAME=invoiceno >");
        echo("<INPUT TYPE=hidden VALUE='$date_of_arival ' NAME=date_of_arival >");
    echo("<INPUT NAME=book TYPE=HIDDEN VALUE='$book'><BR><BR>");
    echo("<INPUT NAME=j TYPE=HIDDEN VALUE='$j'><BR><BR>"); 
    echo("<INPUT NAME=l TYPE=HIDDEN VALUE='$l'><BR><BR>"); 
    echo("<INPUT TYPE=hidden VALUE='$titleb ' NAME=titleb >");
    echo("<INPUT TYPE=hidden VALUE='$title ' NAME=title >");
    echo("<INPUT TYPE=hidden VALUE='$isbn ' NAME=isbn >");
    echo("<INPUT TYPE=hidden VALUE='$author ' NAME=author >");
    echo("<INPUT TYPE=hidden VALUE='$copies ' NAME=copies >");
    echo("<INPUT TYPE=hidden VALUE='$edition ' NAME=edition >");
    echo("<INPUT TYPE=hidden VALUE='$publisher ' NAME=publisher >");
    echo("<INPUT TYPE=hidden VALUE='$book' NAME=book>");
    echo("<INPUT TYPE=hidden VALUE='$acq_clerk' NAME=acq_clerk>");
    echo("<INPUT TYPE=hidden VALUE='$price_per_book' NAME=price_per_book>");
    echo("<INPUT TYPE=hidden VALUE='$discount' NAME=discount>");
    echo("<INPUT TYPE=hidden VALUE='$amt' NAME=amt>");
    echo("<INPUT TYPE=hidden VALUE='$total' NAME=total>");
    echo("<INPUT TYPE=hidden VALUE='$net' NAME=net>");
    echo("<INPUT TYPE=hidden VALUE='$orderno ' NAME=orderno >");

 ?>

		  <DIV ALIGN=CENTER>
		        <INPUT NAME="reset" TYPE="submit" VALUE="Reset">
		  </DIV>
		  </FORM>
<?php
}
?>


</body>
</html>






